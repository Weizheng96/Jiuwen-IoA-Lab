"""
SDK LLM Core - 部署配置

Deployment: 一个API端点
DeploymentStatus: 状态枚举
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Any
from datetime import datetime
import uuid

class DeploymentStatus(Enum):
    """部署状态枚举"""
    HEALTHY = "healthy"
    COOLDOWN = "cooldown"

@dataclass
class Deployment:
    """
    部署配罫 - 一个API端点

    Attributes:
        model_name: str             型号名
        api_key: str API密钥
        api_base: str API端点URL
    id: str 部署ID (自动生成)
    status: DeploymentStatus 状态
    consecutive_failures: int 连续失败次数
    cooldown_until: Optional[float] 冷却时间戳
    tags: List[str] 标签列表
    """
    model_name: str
    api_key: str
    api_base: str

    # 以下字段有默认值
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    model_id: Optional[str] = None
    status: DeploymentStatus = DeploymentStatus.HEALTHY
    consecutive_failures: int = 0
    cooldown_until: Optional[float] = None
    tags: List[str] = field(default_factory=list)


    # 模型信息
    tpm: Optional[int] = None
    rpm: Optional[int] = None
    timeout: Optional[float] = None

    provider: str = "openai"
    verify_ssl: bool = True
    request_defaults: Dict[str, Any] = field(default_factory=dict)
    endpoint_profile: Optional[str] = None
    custom_headers: Optional[Dict[str, str]] = None
    fallback_tag: Optional[str] = None
    model_description: Optional[str] = None

    def __post_init__(self):
        """字段类型与数值校验"""
        for name in ("model_name", "api_key", "api_base", "provider"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value:
                raise ValueError(
                    f"Deployment.{name} must be a non-empty string, got {value!r}"
                )

        for name in ("tpm", "rpm"):
            value = getattr(self, name)
            if value is None:
                continue
            # bool 是 int 的子类，需显式排除
            if isinstance(value, bool) or not isinstance(value, int):
                raise TypeError(
                    f"Deployment.{name} must be an int or None, got {type(value).__name__}"
                )
            if value <= 0:
                raise ValueError(
                    f"Deployment.{name} must be a positive int, got {value}"
                )

        if not isinstance(self.consecutive_failures, int) or isinstance(
            self.consecutive_failures, bool
        ):
            raise TypeError(
                "Deployment.consecutive_failures must be an int, got "
                f"{type(self.consecutive_failures).__name__}"
            )
        if self.consecutive_failures < 0:
            raise ValueError(
                f"Deployment.consecutive_failures must be >= 0, got {self.consecutive_failures}"
            )

        if self.timeout is not None:
            if isinstance(self.timeout, bool) or not isinstance(self.timeout, (int, float)):
                raise TypeError(
                    f"Deployment.timeout must be a number or None, got {type(self.timeout).__name__}"
                )
            if self.timeout <= 0:
                raise ValueError(
                    f"Deployment.timeout must be a positive number, got {self.timeout}"
                )

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典"""
        return {
            "id": self.id,
            "model_id": self.model_id,
            "model_name": self.model_name,
            "api_key": self.api_key,
            "api_base": self.api_base,
            "status": self.status.value,
            "consecutive_failures": self.consecutive_failures,
            "cooldown_until": self.cooldown_until,
            "tags": self.tags,
            "tpm": self.tpm,
            "rpm": self.rpm,
            "timeout": self.timeout,
            "provider": self.provider,
            "verify_ssl": self.verify_ssl,
            "request_defaults": self.request_defaults,
            "endpoint_profile": self.endpoint_profile,
            "custom_headers": self.custom_headers,
            "fallback_tag": self.fallback_tag,
            "model_description": self.model_description,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Deployment":
        """从字典反序列化"""
        data["status"] = DeploymentStatus(data.get("status", "healthy"))
        return cls(**data)

    def is_available(self, now: float) -> bool:
        """检查部署是否可用"""
        if self.status == DeploymentStatus.COOLDOWN:
            if self.cooldown_until and now < self.cooldown_until:
                return False
        return True
