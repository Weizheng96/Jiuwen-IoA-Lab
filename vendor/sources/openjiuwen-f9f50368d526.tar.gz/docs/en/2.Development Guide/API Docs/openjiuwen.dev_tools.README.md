# openjiuwen.dev_tools

`openjiuwen.dev_tools` provides openJiuwen's **Development Tools (DevTools)** module, targeting "development/debugging/iteration" scenarios, mainly covering two types of capabilities:
- **Prompt Building and Optimization (prompt_builder)**:
  - Used to convert "task descriptions/requirements/feedback/bad cases" into more robust prompt templates.
  - Suitable for quickly converging quality in prompt engineering phase, reducing manual repeated trial and error.
- **Agent Tuning (tune)**:
  - Used to combine `Optimizer + Evaluator + Trainer` into a repeatable training process.
  - Suitable for automated evaluation and iteration of prompt parameters (system/user prompt, etc.) when there is a case dataset.
- **Agent reinforcement learning (`agent_rl`)**:
  - Implemented under [`openjiuwen.agent_evolving.agent_rl`](./openjiuwen.agent_evolving/agent_rl/agent_rl.README.md) (VERL-based RL training). `dev_tools` only links the documentation entry from the API index.
- **Agent Builder (agent_builder)**:
  - Builds LLM Agents and workflow Agents from natural language (clarification, design, DL/DSL conversion).
  - Module overview: [agent_builder](./openjiuwen.dev_tools/agent_builder.README.md); package API: [agent_builder.md](./openjiuwen.dev_tools/agent_builder/agent_builder.md). Sidebar: [SUMMARY.md](../../SUMMARY.md) → `openjiuwen.dev_tools` → `agent_builder`.

> Note: `dev_tools` targets "development iteration", not recommended for uncontrolled calls in production main path (may bring additional LLM costs and time consumption).
>
> Production side usually uses solidified prompt/agent configurations, tuning process is recommended to run offline or in controlled environments.

**Modules**:

| MODULE | DESCRIPTION |
|--------|-------------|
| [prompt_builder](./openjiuwen.dev_tools/prompt_builder.README.md) | Prompt building and optimization tools. |
| [tune](./openjiuwen.dev_tools/tune.README.md) | Agent tuning tools. |
| [agent_rl](./openjiuwen.agent_evolving/agent_rl/agent_rl.README.md) | RL training extension based on verl (package: `openjiuwen.agent_evolving.agent_rl`). |
| [agent_builder](./openjiuwen.dev_tools/agent_builder.README.md) | Agent Builder (NL → LLM Agent / workflow) development toolkit. |
