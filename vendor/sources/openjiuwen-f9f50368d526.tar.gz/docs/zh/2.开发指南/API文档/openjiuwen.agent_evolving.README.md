# openjiuwen.agent_evolving

`openjiuwen.agent_evolving` 是 openJiuwen 中的自演进训练与评估框架。

**文档索引**：

| 模块 | 说明 |
|------|------|
| [constant](openjiuwen.agent_evolving/constant.md) | 超参默认值与取值范围（TuneConstant） |
| [dataset](openjiuwen.agent_evolving/dataset.md) | 样本与加载（Case、EvaluatedCase、CaseLoader、shuffle_cases、split_cases） |
| [experience](openjiuwen.agent_evolving/experience.md) | 在线经验生命周期编排（OnlineEvolutionOrchestrator、ExperienceManager、ExperienceTracker、ExperienceScorer） |
| [signal](openjiuwen.agent_evolving/signal.md) | 演进信号检测与 fingerprint 工具（EvolutionSignal、SignalDetector、TeamSignalDetector） |
| [trainer](openjiuwen.agent_evolving/trainer.md) | 训练编排（Trainer、Progress、Callbacks） |
| [trajectory](openjiuwen.agent_evolving/trajectory.md) | Canonical OTLP 轨迹值、进程内 span 采集、同步存储、无状态 accessor 和离线转换工具。 |
| [updater](openjiuwen.agent_evolving/updater.md) | 更新器（`Updater`、`SingleDimUpdater`、`MultiDimUpdater`） |
| [checkpointing](openjiuwen.agent_evolving/checkpointing.md) | 检查点与恢复（`EvolveCheckpoint`、`FileCheckpointStore`、`CheckpointManager`） |
| [optimizer](openjiuwen.agent_evolving/optimizer/optimizer.md) | 优化器基类（BaseOptimizer、TextualParameter、InstructionOptimizer） |
| [optimizer/skill_call/experience_optimizer](openjiuwen.agent_evolving/optimizer/skill_call/experience_optimizer.md) | 普通/团队 Skill 共用的经验优化器（`SkillExperienceOptimizer`） |
| [evaluator](openjiuwen.agent_evolving/evaluator/evaluator.md) | 评估接口与指标（BaseEvaluator、DefaultEvaluator、MetricEvaluator、Metric） |
| [evaluator/evaluator_pipeline](openjiuwen.agent_evolving/evaluator/evaluator_pipeline/README.md) | 技能评估与进化流水线（EvolutionPipeline、BaseAgentAdapter、BaseBenchAdapter、SkillManager） |
| [agent_rl](openjiuwen.agent_evolving/agent_rl/agent_rl.README.md) | 基于 VERL 的 RL 训练（`RLConfig`、`OfflineRLOptimizer`、rollout 编排、奖励注册等） |

与自演进配合使用的原子算子见 [openjiuwen.core.operator](openjiuwen.core/operator.README.md)。
