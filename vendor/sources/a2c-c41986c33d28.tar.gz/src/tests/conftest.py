import os
import tempfile

import pytest

# Keep the unpacked runtime out of the user's cache when the tests run.
os.environ.setdefault("A2C_CACHE_DIR", os.path.join(tempfile.gettempdir(), "a2c-test-cache"))


@pytest.fixture
def world():
    from tests.support import World
    return World()


@pytest.fixture(autouse=True)
def _close_transports():
    yield
    from a2c.binding import A2ATransport
    A2ATransport.close_all()
