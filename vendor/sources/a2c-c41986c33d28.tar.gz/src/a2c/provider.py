"""Provider SDK (design: 设计/合同协议.md, 设计/线上编码.md §5).

The SDK checks, signs and stores; business decisions — whether to countersign, how to draft
a proposal, what a termination costs, when work starts — are the ``policy`` callbacks of
the provider agent.
"""
from __future__ import annotations

import base64
import copy
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Callable, Mapping, Protocol

from . import objects
from .card import build_proposal_card, card_digest, request_digest, validate_card, validate_request, verify_request
from .codec import digest_bytes, parse_duration, parse_time
from .common import Clock, Directory, Endpoint, Reply, Store, Transport, now_or
from .errors import (CARD_INVALID, DEADLINE_PASSED, INVALID_OBJECT, OUT_OF_ORDER, TEMPLATE_EXPIRED, UNKNOWN_CARD,
                     fail)
from .jws import Signer, check_fresh, header_of, ts_of
from .payment import verify_voucher
from .slots import sign_slot, sign_template, verify_card, verify_template
from .template import deliverable_names, material, template_digest, validate
from .verifier.acceptance import ModelPort, report, run_target


@dataclass
class Proposal:
    """What the provider agent fills in when it drafts a card from a Request Card."""

    acceptance: Mapping[str, Any]
    accept_within: Mapping[str, str]
    line_items: Mapping[str, Any]
    card_id: str | None = None


class ProviderPolicy(Protocol):
    def review(self, template: Mapping, card: Mapping, materials: Mapping[str, bytes]) -> str | None:
        """Countersign? ``None`` accepts, a string declines with that reason."""

    def draft(self, template: Mapping, request: Mapping, materials: Mapping[str, bytes]) -> Proposal | str:
        """Draft a card from a Request Card, or decline with a reason."""

    def termination_fee(self, template: Mapping, card: Mapping, period: int) -> Any:
        """The fee quoted when the Client asks to terminate."""

    def on_start(self, template: Mapping, card: Mapping, materials: Mapping[str, bytes]) -> None:
        """Work may start: the card is effective and the receipt is issued."""


class DefaultPolicy:
    def review(self, template, card, materials):
        return None

    def draft(self, template, request, materials):
        return "this provider does not draft proposals"

    def termination_fee(self, template, card, period):
        return card["derived"]["periods"][period - 1]["amount"]

    def on_start(self, template, card, materials):
        return None


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode()


def _unb64(text: str) -> bytes:
    return base64.b64decode(text)


class Provider(Endpoint):
    OPS = ("template.get", "request.submit", "card.countersign", "work.start", "step.authorize", "delivery.fetch",
           "acceptance.notify", "payment.notify", "termination.quote", "termination.notify",
           "ap2.checkout")   # the last one is the AP2 payee role, outside A2C

    def __init__(self, signer: Signer, *, market: str, keys: Directory, transport: Transport,
                 fetch: Callable[[str], bytes], clock: Clock | None = None, store: Store | None = None,
                 policy: ProviderPolicy | None = None, model: ModelPort | None = None,
                 ap2_key: Any = None, name: str = "") -> None:
        super().__init__()
        self.signer = signer
        self.market = market
        self.keys = keys
        self.transport = transport
        self.fetch = fetch
        self.now = now_or(clock)
        self.store = store or Store()
        self.policy = policy or DefaultPolicy()
        self.model = model
        self.ap2_key = ap2_key
        self.name = name or signer.id

    @property
    def id(self) -> str:
        return self.signer.id

    # ── templates ───────────────────────────────────────────────────────

    def publish(self, draft: Mapping[str, Any]) -> dict:
        """Sign a template and have the Market endorse it."""
        t = {k: v for k, v in copy.deepcopy(dict(draft)).items() if k != "signatures"}
        t["provider"] = self.id
        t["templateDigest"] = template_digest(t)
        t["signatures"] = {}
        t = sign_template(t, self.signer, "provider", self.now())
        validate(t, endorsed=False)
        endorsed = self.transport.send(self.market, "template.endorse", {"template": t}).body["template"]
        validate(endorsed)
        verify_template(endorsed, self.keys)
        self.store.put("templates", endorsed["templateDigest"], endorsed)
        return endorsed

    def template(self, digest: str) -> dict:
        t = self.store.get("templates", digest)
        if t is None:
            fail(UNKNOWN_CARD, "unknown template")
        return t

    def op_template_get(self, body, files, task_id) -> Reply:
        templates = list(self.store.all("templates").values())
        if body.get("templateDigest"):
            templates = [t for t in templates if t["templateDigest"] == body["templateDigest"]]
        return Reply({"op": "template.get", "templates": templates})

    # ── helpers ─────────────────────────────────────────────────────────

    def _record(self, cd: str) -> dict:
        rec = self.store.get("cards", cd)
        if rec is None:
            fail(UNKNOWN_CARD, "unknown card")
        return rec

    def _save(self, rec: dict) -> None:
        self.store.put("cards", card_digest(rec["card"]), rec)

    def _materials(self, template, decl: Mapping[str, Any], files: Mapping[str, bytes], names: list[str], *,
                   auth: Mapping[str, Any] | None, bound: tuple[str, str], card_like: Mapping[str, Any]):
        """Check the materials sent now: authorization, digests, declarations. Returns
        (rejection reason, failing names, input report) or None when they all fit."""
        if not names:
            return None
        if auth is None:
            fail(INVALID_OBJECT, "materials need an information authorization")
        objects.verify_signed(auth, auth["jwk"])
        if auth.get(bound[0]) != bound[1] or not set(names) <= set(auth["inputs"]):
            fail(INVALID_OBJECT, "information authorization does not cover these materials")
        wrong = [n for n in names if n not in files or digest_bytes(files[n]) != decl[n]["digest"]]
        if wrong:
            return "digest-mismatch", wrong, None
        for n in names:
            refs = material(template, n).get("verifiers")
            if not refs:
                continue
            result = run_target(refs, fetch=self.fetch, template=template, card=card_like, target=n,
                                files={n: files[n]}, model=self.model)
            if result.status != "pass":
                return "declaration-mismatch", [n], report(bound[1], result, input=n)
        return None

    def _sign(self, kind: str, **body) -> dict:
        return objects.signed(objects.new(kind, **body), self.signer, self.now())

    # ── formation ───────────────────────────────────────────────────────

    def op_request_submit(self, body, files, task_id) -> Reply:
        request = body["request"]
        template = self.template(request["templateDigest"])
        validate_request(template, request)
        h = verify_request(request)
        check_fresh(h, self.now())
        key = f"{request['client']['id']} {request['requestId']}"
        last = self.store.get("requests", key)
        if last is not None and request["version"] <= last["version"]:
            fail(OUT_OF_ORDER, "a revised Request Card needs a higher version")
        rd = request_digest(request)
        fee = template["pricing"].get("proposalFee", 0)
        if fee:
            verify_voucher(body.get("voucher") or fail(CARD_INVALID, "a proposal fee voucher is required"), self.keys,
                           payment_provider=request["paymentProvider"], purpose="proposal-fee", amount=fee,
                           currency=template["pricing"]["currency"], request_digest=rd)
        self.store.put("requests", key, {"version": request["version"]})
        task = self.new_task("request.submit")
        review = [n for n in request["inputs"] if material(template, n).get("reviewBeforeSigning")]

        def finish() -> Reply:                      # drafting may take long: runs after the task is returned
            problem = self._materials(template, request["inputs"], files, review, auth=body.get("informationAuthorization"),
                                      bound=("requestDigest", rd), card_like=request)
            decision = (f"materials do not fit: {problem[0]} {problem[1]}" if problem
                        else self.policy.draft(template, request, {n: files[n] for n in review}))
            if isinstance(decision, str):
                task.state = "completed"
                task.artifacts.append({"reason": decision})
                return Reply({"op": "request.submit", "reason": decision}, task_id=task.id, state=task.state)
            card = build_proposal_card(template, request, card_id=decision.card_id or f"{request['requestId']}-v{request['version']}",
                                       acceptance=decision.acceptance, accept_within=decision.accept_within,
                                       line_items=decision.line_items)
            validate_card(template, card, request=request)
            card = sign_slot(card, 2, self.signer, self.now())
            card = self.transport.send(self.market, "card.endorse", {"card": card}).body["card"]
            verify_card(template, card, self.keys, request_ts=ts_of(request["signature"]))   # slot 3 in time
            check_fresh(header_of(card["signatures"]["3"]), self.now())
            self._save({"card": card, "request": request, "review": {n: _b64(files[n]) for n in review},
                        "state": "offered", "task": task.id})
            task.state = "completed"
            task.artifacts.append({"card": card})
            return Reply({"op": "request.submit", "card": card}, task_id=task.id, state=task.state)
        return Reply({"op": "request.submit"}, task_id=task.id, state=task.state, then=finish)

    def op_card_countersign(self, body, files, task_id) -> Reply:
        card = body["card"]
        template = self.template(card["templateDigest"])
        if template["formation"] != "countersign":
            fail(CARD_INVALID, "countersign is for countersign templates")
        validate_card(template, card)
        if card["signatures"]["1"] is None or card["signatures"]["2"] is not None:
            fail(OUT_OF_ORDER, "countersign needs slot 1 and no slot 2")
        verify_card(template, card, self.keys)
        h1 = header_of(card["signatures"]["1"])
        check_fresh(h1, self.now())
        if self.now() > parse_time(h1["a2c-ts"]) + parse_duration(template["deadlines"]["respondWithin"]):
            fail(DEADLINE_PASSED, "respondWithin passed")
        if self.now() > parse_time(template["validUntil"]):
            fail(TEMPLATE_EXPIRED, "template expired")
        cd = card_digest(card)
        task = self.new_task("card.countersign")
        review = [n for n in card["inputs"] if material(template, n).get("reviewBeforeSigning")]

        def finish() -> Reply:                      # the review may take long: runs after the task is returned
            problem = self._materials(template, card["inputs"], files, review, auth=body.get("informationAuthorization"),
                                      bound=("cardDigest", cd), card_like=card)
            reason = (f"materials do not fit: {problem[0]} {problem[1]}" if problem
                      else self.policy.review(template, card, {n: files[n] for n in review}))
            if reason is not None:
                task.state = "completed"
                task.artifacts.append({"reason": reason})
                return Reply({"op": "card.countersign", "reason": reason}, task_id=task.id, state=task.state)
            signed = sign_slot(card, 2, self.signer, self.now())
            self._save({"card": signed, "review": {n: _b64(files[n]) for n in review}, "state": "formed", "task": task.id})
            task.state = "completed"
            task.artifacts.append({"card": signed})
            return Reply({"op": "card.countersign", "card": signed}, task_id=task.id, state=task.state)
        return Reply({"op": "card.countersign"}, task_id=task.id, state=task.state, then=finish)

    def op_work_start(self, body, files, task_id) -> Reply:
        card = body["card"]
        template = self.template(card["templateDigest"])
        validate_card(template, card)
        cd = card_digest(card)
        rec = self.store.get("cards", cd) or {"card": card, "review": {}}
        if rec.get("state") in ("started", "lapsed", "terminated", "closed") or card["fulfillment"].get("receipt"):
            fail(OUT_OF_ORDER, f"card is {rec.get('state', 'started')}")
        if template["formation"] == "proposal" and "request" not in rec:
            fail(UNKNOWN_CARD, "this provider did not draft that card")
        chain = verify_card(template, card, self.keys)
        if chain.effective is None:
            fail(OUT_OF_ORDER, "card is not effective")
        if chain.effective > parse_time(template["validUntil"]):
            fail(TEMPLATE_EXPIRED, "template expired before the card took effect")
        if self.now() > chain.effective + parse_duration(template["deadlines"]["startWithin"]):
            rec.update(card=card, state="lapsed")
            self._save(rec)
            fail(DEADLINE_PASSED, "startWithin passed; the card has lapsed")
        derived = card["derived"]
        if Decimal(str(derived["deposit"])) > 0:
            verify_voucher(body.get("voucher") or fail(CARD_INVALID, "a deposit voucher is required"), self.keys,
                           payment_provider=card["paymentProvider"], purpose="deposit", amount=derived["deposit"],
                           currency=template["pricing"]["currency"], card_digest=cd)
            rec["depositVoucher"] = body["voucher"]
        names = [n for n in card["inputs"] if not material(template, n).get("reviewBeforeSigning")]
        task = self.new_task("work.start")

        def finish() -> Reply:                      # material checks run verifiers: after the task is returned
            problem = self._materials(template, card["inputs"], files, names, auth=body.get("informationAuthorization"),
                                      bound=("cardDigest", cd), card_like=card)
            if problem:
                reason, wrong, rep = problem
                rejection = self._sign("rejection", cardDigest=cd, reason=reason, inputs=wrong, report=rep)
                if reason == "declaration-mismatch":
                    rec.update(card=card, state="lapsed")
                self._save({**rec, "card": card, "rejection": rejection})
                task.state = "rejected"
                task.artifacts.append({"rejection": rejection})
                return Reply({"op": "work.start", "rejection": rejection}, task_id=task.id, state=task.state)
            receipt = self._sign("receipt", cardDigest=cd)
            started = copy.deepcopy(card)
            started["fulfillment"]["receipt"] = receipt
            materials = {**{n: _unb64(v) for n, v in rec.get("review", {}).items()}, **{n: files[n] for n in names}}
            rec.update(card=started, state="started", task=task.id, materials={n: _b64(b) for n, b in materials.items()},
                       deliveries={}, steps=[], quotes={})
            self._save(rec)
            task.artifacts.append({"receipt": receipt})
            self.policy.on_start(template, started, materials)
            return Reply({"op": "work.start", "receipt": receipt}, task_id=task.id, state=task.state)
        return Reply({"op": "work.start"}, task_id=task.id, state=task.state, then=finish)

    # ── delivery ────────────────────────────────────────────────────────

    def card(self, cd: str) -> dict:
        return self._record(cd)["card"]

    def materials(self, cd: str) -> dict[str, bytes]:
        return {n: _unb64(v) for n, v in self._record(cd).get("materials", {}).items()}

    def request_step(self, cd: str, step: str) -> dict:
        """Ask the Client's user to authorize a declared step; pauses the delivery clock."""
        with self._lock:
            return self._request_step(cd, step)

    def _request_step(self, cd: str, step: str) -> dict:
        rec = self._record(cd)
        template = self.template(rec["card"]["templateDigest"])
        if step not in [s["name"] for s in template.get("authorizableSteps", [])]:
            fail(CARD_INVALID, f"{step} is not an authorizable step of the template")
        if rec.get("state") != "started":
            fail(OUT_OF_ORDER, "no work in progress")
        task = self.task(rec["task"])
        if task.state == "auth-required":
            fail(OUT_OF_ORDER, "a step request is already waiting for an answer")
        period = len(rec["card"]["signatures"]["7"]) + 1
        sr = self._sign("step-request", cardDigest=cd, period=period, step=step)
        task.state, task.status = "auth-required", {"stepRequest": sr}
        rec["steps"].append({"request": sr, "answer": None})
        self._save(rec)
        return sr

    def op_step_authorize(self, body, files, task_id) -> Reply:
        task = self.task(task_id or fail(INVALID_OBJECT, "answer on the delivery task"))
        if task.state != "auth-required":
            fail(OUT_OF_ORDER, "no step request is waiting")
        sr = task.status["stepRequest"]
        rec = self._record(sr["cardDigest"])
        sa = body["stepAuthorization"]
        h = objects.verify_signed(sa, sa["jwk"])
        check_fresh(h, self.now())
        if sa["stepRequestDigest"] != objects.object_digest(sr):
            fail(INVALID_OBJECT, "answer is for another step request")
        rec["steps"][-1]["answer"] = sa
        self._save(rec)
        task.state, task.status = "working", None
        return Reply({"op": "step.authorize", "ok": True}, task_id=task.id, state=task.state)

    def deliver(self, cd: str, files: Mapping[str, tuple[bytes, str]]) -> dict:
        """Sign slot 4(i) over this period's manifest and have the Market sign slot 5(i)."""
        with self._lock:
            return self._deliver(cd, files)

    def _deliver(self, cd: str, files: Mapping[str, tuple[bytes, str]]) -> dict:
        rec = self._record(cd)
        if rec.get("state") != "started":
            fail(OUT_OF_ORDER, f"card is {rec.get('state')}")
        card = copy.deepcopy(rec["card"])
        template = self.template(card["templateDigest"])
        period = len(card["signatures"]["4"]) + 1
        if period > len(deliverable_names(template)):
            fail(OUT_OF_ORDER, "all periods delivered")
        manifest = objects.new("manifest", cardDigest=cd, period=period,
                               files=[{"name": n, "digest": digest_bytes(b), "mediaType": t} for n, (b, t) in files.items()])
        periods = card["fulfillment"].setdefault("periods", [])
        periods.append({"manifest": manifest})
        card = sign_slot(card, 4, self.signer, self.now(), period=period)
        card = self.transport.send(self.market, "delivery.anchor", {"card": card}).body["card"]
        verify_card(template, card, self.keys)
        check_fresh(header_of(card["signatures"]["5"][period - 1]), self.now())
        rec["card"] = card
        rec["deliveries"][str(period)] = {n: _b64(b) for n, (b, _t) in files.items()}
        self._save(rec)
        return card

    def op_delivery_fetch(self, body, files, task_id) -> Reply:
        rec = self._record(body["cardDigest"])
        if task_id is None or task_id != rec.get("task"):
            fail(INVALID_OBJECT, "delivery.fetch is sent on the card's Delivery Task")
        period = body["period"]
        if str(period) not in rec.get("deliveries", {}):
            fail(OUT_OF_ORDER, f"period {period} is not anchored")
        return Reply({"op": "delivery.fetch", "card": rec["card"]},
                     files={n: _unb64(v) for n, v in rec["deliveries"][str(period)].items()})

    def op_acceptance_notify(self, body, files, task_id) -> Reply:
        incoming = body["card"]
        cd = card_digest(incoming)
        rec = self._record(cd)
        if rec.get("state") != "started":
            fail(OUT_OF_ORDER, f"card is {rec.get('state')}")
        template = self.template(incoming["templateDigest"])
        validate_card(template, incoming)
        card = self._merge_client_slots(rec["card"], incoming)
        verify_card(template, card, self.keys)
        old = rec["card"]["signatures"]
        for slot in ("6", "7"):
            for i, sig in enumerate(card["signatures"][slot]):
                if i >= len(old[slot]) or sig != old[slot][i]:
                    check_fresh(header_of(sig), self.now())
        for i, p in enumerate(card["fulfillment"].get("periods", []), start=1):
            rep = p.get("report")
            if rep is not None:
                h = objects.verify_signed(rep, card["client"]["jwk"], signer=card["client"]["id"])
                if rep["cardDigest"] != cd or rep.get("period") != i:
                    fail(INVALID_OBJECT, "report is for another card or period")
                known = (rec["card"]["fulfillment"].get("periods") or [{}] * i)
                if len(known) < i or known[i - 1].get("report") != rep:
                    check_fresh(h, self.now())
        rec["card"] = card
        if body.get("provenance"):
            rec.setdefault("provenance", []).append(body["provenance"])
        self._save(rec)
        return Reply({"op": "acceptance.notify", "ok": True})

    @staticmethod
    def _merge_client_slots(mine: Mapping[str, Any], theirs: Mapping[str, Any]) -> dict:
        """Take only what the Client adds (slots 6 and 7, reports, attestations); everything the
        Provider holds must already be on the incoming card, unchanged."""
        card = copy.deepcopy(dict(mine))
        for slot in ("1", "2", "3"):
            if theirs["signatures"][slot] != mine["signatures"][slot]:
                fail(OUT_OF_ORDER, f"slot {slot} differs from the Provider's copy")
        for slot in ("4", "5"):
            if theirs["signatures"][slot] != mine["signatures"][slot]:
                fail(OUT_OF_ORDER, f"slot {slot} differs from the Provider's copy")
        for slot in ("6", "7"):
            have, got = mine["signatures"][slot], theirs["signatures"][slot]
            if got[:len(have)] != have:
                fail(OUT_OF_ORDER, f"slot {slot} drops signatures the Provider holds")
            card["signatures"][slot] = list(got)
        mp, tp = card["fulfillment"].get("periods", []), theirs["fulfillment"].get("periods", [])
        if len(tp) != len(mp):
            fail(OUT_OF_ORDER, "periods differ from the Provider's copy")
        for a, b in zip(mp, tp):
            if b.get("manifest") != a.get("manifest"):
                fail(OUT_OF_ORDER, "a manifest differs from the Provider's copy")
            for k in ("report", "attestations"):
                if k in b:
                    a[k] = b[k]
        return card

    def op_payment_notify(self, body, files, task_id) -> Reply:
        voucher = body["voucher"]
        rec = self._record(voucher.get("cardDigest", ""))
        card = rec["card"]
        template = self.template(card["templateDigest"])
        currency = template["pricing"]["currency"]
        if voucher.get("purpose") == "installment":
            i = voucher.get("period")
            if not isinstance(i, int) or not 1 <= i <= len(card["signatures"]["7"]):
                fail(OUT_OF_ORDER, "installment for a period without slot 7")
            verify_voucher(voucher, self.keys, payment_provider=card["paymentProvider"], purpose="installment",
                           amount=card["derived"]["periods"][i - 1]["amount"], currency=currency,
                           card_digest=card_digest(card), period=i)
        elif voucher.get("purpose") == "termination":
            balance = self.balance(rec)
            verify_voucher(voucher, self.keys, payment_provider=card["paymentProvider"], purpose="termination",
                           amount=balance, currency=currency, card_digest=card_digest(card))
        else:
            fail(INVALID_OBJECT, "payment.notify carries installment or termination vouchers")
        rec.setdefault("vouchers", []).append(voucher)
        self._save(rec)
        return Reply({"op": "payment.notify", "ok": True})

    # ── termination ─────────────────────────────────────────────────────

    def op_termination_quote(self, body, files, task_id) -> Reply:
        rec = self._record(body["cardDigest"])
        card = rec["card"]
        if rec.get("state") in ("terminated", "closed"):
            fail(OUT_OF_ORDER, f"card is {rec['state']}")
        template = self.template(card["templateDigest"])
        if len(card["signatures"]["7"]) >= len(deliverable_names(template)):
            fail(OUT_OF_ORDER, "every period is accepted; there is nothing to terminate")
        period = len(card["signatures"]["7"]) + 1
        fee = self.policy.termination_fee(template, card, period)
        if Decimal(str(fee)) > Decimal(str(card["derived"]["periods"][period - 1]["amount"])) or Decimal(str(fee)) < 0:
            fail(CARD_INVALID, "a termination fee cannot exceed the current period's amount")
        quote = self._sign("termination-quote", cardDigest=body["cardDigest"], period=period, fee=fee)
        rec.setdefault("quotes", {})[objects.object_digest(quote)] = quote
        self._save(rec)
        return Reply({"op": "termination.quote", "terminationQuote": quote})

    def balance(self, rec: Mapping[str, Any]) -> Any:
        """Termination balance = fee − deposit (positive: the Client pays; negative: the Provider refunds)."""
        term = rec["card"]["fulfillment"]["termination"]
        quote = term.get("quote")
        if quote is None:
            fail(OUT_OF_ORDER, "a unilateral termination has no agreed balance")
        paid = Decimal(str(rec["card"]["derived"]["deposit"])) if rec.get("depositVoucher") else Decimal(0)
        b = Decimal(str(quote["fee"])) - paid
        return int(b) if b == b.to_integral_value() else float(b)

    def op_termination_notify(self, body, files, task_id) -> Reply:
        term = body["termination"]
        rec = self._record(term.get("cardDigest", ""))
        card = copy.deepcopy(rec["card"])
        if rec.get("state") in ("terminated", "closed"):
            fail(OUT_OF_ORDER, f"card is {rec['state']}")
        h = objects.verify_signed(term, card["client"]["jwk"], signer=card["client"]["id"])
        check_fresh(h, self.now())
        record: dict[str, Any] = {"termination": term}
        if "terminationQuoteDigest" in term:
            quote = rec.get("quotes", {}).get(term["terminationQuoteDigest"])
            if quote is None:
                fail(OUT_OF_ORDER, "unknown termination quote")
            template = self.template(card["templateDigest"])
            if self.now() > ts_of(quote["signature"]) + parse_duration(template["deadlines"]["respondWithin"]):
                fail(DEADLINE_PASSED, "the quote expired")
            record["quote"] = quote
        card["fulfillment"]["termination"] = record
        rec.update(card=card, state="terminated")
        self._save(rec)
        if rec.get("task") in self.tasks:
            self.tasks[rec["task"]].state = "canceled"
        return Reply({"op": "termination.notify", "ok": True})

    # ── AP2 payee role ──────────────────────────────────────────────────

    def op_ap2_checkout(self, body, files, task_id) -> Reply:
        """Issue the Checkout JWT for an A2C amount this provider is to be paid."""
        from .payment.ap2 import checkout
        if self.ap2_key is None:
            fail(INVALID_OBJECT, "this provider has no AP2 merchant key")
        purpose, period = body.get("purpose"), body.get("period")
        if purpose == "proposal-fee":
            template = self.template(body["templateDigest"])
            ref, amount = {"requestDigest": body["requestDigest"]}, template["pricing"].get("proposalFee", 0)
        elif purpose == "termination":
            rec = self._record(body["cardDigest"])
            template = self.template(rec["card"]["templateDigest"])
            ref, amount = {"cardDigest": body["cardDigest"]}, self.balance(rec)
        elif purpose in ("deposit", "installment"):
            card = body["card"]
            template = self.template(card["templateDigest"])
            validate_card(template, card)
            verify_card(template, card, self.keys)
            ref = {"cardDigest": card_digest(card)}
            amount = card["derived"]["deposit"] if purpose == "deposit" else card["derived"]["periods"][period - 1]["amount"]
        else:
            fail(INVALID_OBJECT, f"unknown purpose {purpose!r}")
        jwt = checkout({"id": self.id, "name": self.name}, self.ap2_key, purpose=purpose, digest_ref=ref,
                       period=period if purpose == "installment" else None, amount=amount,
                       currency=template["pricing"]["currency"], now=int(self.now().timestamp()))
        return Reply({"op": "ap2.checkout", "checkoutJwt": jwt})

    # ── closing ─────────────────────────────────────────────────────────

    def close(self, cd: str) -> None:
        with self._lock:
            self._close(cd)

    def _close(self, cd: str) -> None:
        rec = self._record(cd)
        self.transport.send(self.market, "card.close", {"card": rec["card"]})
        rec["state"] = "closed"
        self._save(rec)
        if rec.get("task") in self.tasks:
            self.tasks[rec["task"]].state = "completed"

    def purge_lapsed(self) -> list[str]:
        """Drop offers that lapsed before work started, with their tasks and materials (合同协议 §十二):
        a countersigned card after slot 2 + startWithin, a drafted card after slot 3 + respondWithin + startWithin."""
        with self._lock:
            gone = []
            for cd, rec in self.store.all("cards").items():
                if rec.get("state") not in ("offered", "formed"):
                    continue
                template = self.template(rec["card"]["templateDigest"])
                d, sigs = template["deadlines"], rec["card"]["signatures"]
                last = ts_of(sigs["3"]) + parse_duration(d["respondWithin"]) if rec["state"] == "offered" else ts_of(sigs["2"])
                if self.now() > last + parse_duration(d["startWithin"]):
                    self.store.delete("cards", cd)
                    self.tasks.pop(rec.get("task", ""), None)
                    gone.append(cd)
            return gone

    def endorse_provenance(self, cd: str) -> list[dict]:
        """Have the Market countersign the provenance statements the Client signed."""
        with self._lock:
            return self._endorse_provenance(cd)

    def _endorse_provenance(self, cd: str) -> list[dict]:
        rec = self._record(cd)
        out = [self.transport.send(self.market, "provenance.endorse", {"provenance": p, "card": rec["card"]}).body["provenance"]
               for p in rec.get("provenance", [])]
        rec["provenance"] = out
        self._save(rec)
        return out


__all__ = ["Provider", "ProviderPolicy", "DefaultPolicy", "Proposal"]
