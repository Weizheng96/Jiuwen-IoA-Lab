"""A reference Payment Provider that reads the card (for tests and demos; a real one is a licensed institution).

It verifies the AP2 mandates and the payee's Checkout JWT, then reads the card exactly as
设计/合同协议.md §7 says — template signatures, formation slots, slot 5(i) and 7(i), or the
termination record — before it "transfers" and signs the A2C voucher. It never holds funds
and has no operation that moves money on the basis of a ruling.
"""
from __future__ import annotations

import itertools
from decimal import Decimal
from typing import Any, Callable, Mapping

from .. import objects
from ..card import card_digest, request_digest, validate_card, validate_request
from ..common import Clock, Directory, Endpoint, Reply, now_or
from ..errors import BAD_SIGNATURE, CARD_INVALID, OUT_OF_ORDER, fail
from ..jws import Signer, header_of
from ..slots import verify_card, verify_template
from ..template import validate
from .ap2 import EcKey, jwt_decode, jwt_verify, receipt, sha256_b64url, to_minor


class PaymentProvider(Endpoint):
    OPS = ("ap2.pay",)
    _ids = itertools.count(1)

    def __init__(self, signer: Signer, *, keys: Directory, ap2_key: EcKey, payee_keys: Callable[[str], Mapping],
                 clock: Clock | None = None) -> None:
        super().__init__()
        self.signer = signer
        self.keys = keys
        self.ap2_key = ap2_key
        self.payee_keys = payee_keys          # payee id → its AP2 (ES256) JWK
        self.now = now_or(clock)
        self.paid: set[tuple] = set()
        self.ledger: list[dict] = []          # transfers made (amount, payer, payee) — the double's "bank"

    def _amount(self, purpose: str, body: Mapping[str, Any], period: int | None):
        template = validate(body["template"])
        verify_template(template, self.keys)
        if self.signer.id not in [pp["id"] for pp in template["pricing"]["paymentProviders"]]:
            fail(CARD_INVALID, "this payment provider is not listed by the template")
        if purpose == "proposal-fee":
            # the fee is paid before the Request Card is signed: its digest excludes the signature
            request = validate_request(template, {**body["request"], "signature": body["request"].get("signature", {})})
            return template, request_digest(request), template["pricing"].get("proposalFee", 0)
        card = validate_card(template, body["card"])
        chain = verify_card(template, card, self.keys)
        cd = card_digest(card)
        if purpose == "deposit":
            if chain.effective is None:
                fail(OUT_OF_ORDER, "deposit before the card is effective")
            return template, cd, card["derived"]["deposit"]
        if purpose == "installment":
            if chain.period_ts(5, period) is None or chain.period_ts(7, period) is None:
                fail(OUT_OF_ORDER, f"period {period} needs slot 5 and slot 7")
            return template, cd, card["derived"]["periods"][period - 1]["amount"]
        rec = body.get("termination") or fail(CARD_INVALID, "termination record missing")
        term, quote = rec["termination"], rec.get("quote")
        objects.verify_signed(term, card["client"]["jwk"], signer=card["client"]["id"])
        if quote is None or term.get("terminationQuoteDigest") != objects.object_digest(quote):
            fail(CARD_INVALID, "only an agreed termination has a balance")
        objects.verify_signed(quote, self.keys.jwk(template["provider"], header_of(quote["signature"]).get("kid")),
                              signer=template["provider"], expect_kid=True)
        if term["cardDigest"] != cd or quote["cardDigest"] != cd:
            fail(CARD_INVALID, "termination record belongs to another card")
        i = chain.accepted + 1
        if quote["period"] != i or i > len(template["deliverables"]) or \
                Decimal(str(quote["fee"])) > Decimal(str(card["derived"]["periods"][i - 1]["amount"])):
            fail(CARD_INVALID, "the quote must name the first unaccepted period and not exceed its amount")
        paid = Decimal(str(card["derived"]["deposit"])) if (cd, "deposit", None) in self.paid else Decimal(0)
        balance = Decimal(str(quote["fee"])) - paid
        if balance <= 0:
            fail(CARD_INVALID, "the client owes nothing; the provider refunds")
        return template, cd, int(balance) if balance == balance.to_integral_value() else float(balance)

    def op_ap2_pay(self, body, files, task_id) -> Reply:
        pm_jwt = body["paymentMandate"].rstrip("~")
        cm_jwt = body["checkoutMandate"].rstrip("~")
        pm_head, _ = jwt_decode(pm_jwt)
        payer_jwk = pm_head.get("jwk") or fail(BAD_SIGNATURE, "payment mandate carries no payer key")
        pm = jwt_verify(pm_jwt, payer_jwk)
        cm = jwt_verify(cm_jwt, payer_jwk)
        checkout_jwt = cm["checkout_jwt"]
        if cm["checkout_hash"] != sha256_b64url(checkout_jwt) or pm["transaction_id"] != sha256_b64url(checkout_jwt):
            fail(BAD_SIGNATURE, "mandates are not bound to the checkout")
        _h, claims = jwt_decode(checkout_jwt)
        payee = claims["merchant"]
        jwt_verify(checkout_jwt, self.payee_keys(payee["id"]))
        if pm["payee"] != payee:
            fail(CARD_INVALID, "payment mandate names another payee")
        a2c = claims["a2c"]
        purpose, period = a2c["purpose"], a2c.get("period")
        template, ref, amount = self._amount(purpose, body, period)
        currency = template["pricing"]["currency"]
        if Decimal(str(a2c["amount"])) != Decimal(str(amount)) or pm["payment_amount"] != {
                "amount": to_minor(amount, currency), "currency": currency}:
            fail(CARD_INVALID, "amount differs from the card")
        if payee["id"] != template["provider"]:
            fail(CARD_INVALID, "the payee is the template's provider")
        key = (ref, purpose, period)
        if key in self.paid:
            fail(OUT_OF_ORDER, "already paid")
        self.paid.add(key)
        payment_id = f"pay-{next(self._ids)}"
        self.ledger.append({"payee": payee["id"], "amount": amount, "currency": currency, "purpose": purpose})
        ref_key = "requestDigest" if purpose == "proposal-fee" else "cardDigest"
        voucher = objects.signed(objects.new("voucher", purpose=purpose, period=period, amount=amount, currency=currency,
                                             **{ref_key: ref}), self.signer, self.now())
        rcpt = receipt(body["paymentMandate"], self.ap2_key, issuer=self.signer.id, payment_id=payment_id,
                       now=int(self.now().timestamp()))
        return Reply({"op": "ap2.pay", "voucher": voucher, "paymentReceipt": rcpt})


__all__ = ["PaymentProvider"]
