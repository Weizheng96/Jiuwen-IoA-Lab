"""AP2 v0.2 binding of the payment port (design: 设计/线上编码.md §9; informative, not part of A2C).

The payer's SDK takes a Checkout JWT from the payee (it carries an ``a2c`` member naming
purpose, digest, period and amount), signs a closed Checkout Mandate and Payment Mandate,
and hands them with the template and card to the Payment Provider, which reads the card,
transfers and returns an AP2 Payment Receipt plus the A2C voucher.

AP2 artefacts use ES256 compact JWS; mandates are SD-JWTs without disclosures (``<jwt>~``).
"""
from __future__ import annotations

import hashlib
import json
from decimal import Decimal
from typing import Any, Callable, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature, encode_dss_signature

from ..codec import b64url, b64url_decode
from ..common import Transport
from ..errors import BAD_SIGNATURE, INVALID_OBJECT, fail
from ..pricing import minor_units

AP2_EXTENSION = "https://github.com/google-agentic-commerce/ap2/v1"


# ── ES256 JWT ───────────────────────────────────────────────────────────

class EcKey:
    """An ES256 key pair with a kid (AP2 artefacts are ES256)."""

    def __init__(self, kid: str, key: ec.EllipticCurvePrivateKey | None = None) -> None:
        self.kid = kid
        self.key = key or ec.generate_private_key(ec.SECP256R1())

    @property
    def jwk(self) -> dict:
        nums = self.key.public_key().public_numbers()
        return {"kty": "EC", "crv": "P-256", "kid": self.kid, "x": b64url(nums.x.to_bytes(32, "big")),
                "y": b64url(nums.y.to_bytes(32, "big"))}


def _public(jwk: Mapping[str, Any]) -> ec.EllipticCurvePublicKey:
    if jwk.get("kty") != "EC" or jwk.get("crv") != "P-256":
        fail(BAD_SIGNATURE, "not a P-256 JWK")
    x = int.from_bytes(b64url_decode(jwk["x"]), "big")
    y = int.from_bytes(b64url_decode(jwk["y"]), "big")
    return ec.EllipticCurvePublicNumbers(x, y, ec.SECP256R1()).public_key()


def jwt_sign(payload: Mapping[str, Any], key: EcKey, typ: str = "JWT", jwk_header: bool = False) -> str:
    header = {"alg": "ES256", "typ": typ, "kid": key.kid}
    if jwk_header:
        header["jwk"] = key.jwk
    h = b64url(json.dumps(header, separators=(",", ":")).encode())
    p = b64url(json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode())
    der = key.key.sign(f"{h}.{p}".encode(), ec.ECDSA(hashes.SHA256()))
    r, s = decode_dss_signature(der)
    return f"{h}.{p}.{b64url(r.to_bytes(32, 'big') + s.to_bytes(32, 'big'))}"


def jwt_decode(token: str) -> tuple[dict, dict]:
    try:
        h, p, _s = token.split(".")
        return json.loads(b64url_decode(h)), json.loads(b64url_decode(p))
    except (ValueError, AttributeError):
        fail(INVALID_OBJECT, "malformed JWT")


def jwt_verify(token: str, jwk: Mapping[str, Any]) -> dict:
    header, payload = jwt_decode(token)
    if header.get("alg") != "ES256":
        fail(BAD_SIGNATURE, "AP2 artefacts are ES256")
    h, p, s = token.split(".")
    raw = b64url_decode(s)
    der = encode_dss_signature(int.from_bytes(raw[:32], "big"), int.from_bytes(raw[32:], "big"))
    try:
        _public(jwk).verify(der, f"{h}.{p}".encode(), ec.ECDSA(hashes.SHA256()))
    except InvalidSignature:
        fail(BAD_SIGNATURE, "AP2 signature does not verify")
    return payload


def sha256_b64url(text: str) -> str:
    return b64url(hashlib.sha256(text.encode()).digest())


def to_minor(amount: Any, currency: str) -> int:
    return int(Decimal(str(amount)).scaleb(minor_units(currency)))


# ── artefacts ───────────────────────────────────────────────────────────

def checkout(payee: Mapping[str, str], key: EcKey, *, purpose: str, digest_ref: Mapping[str, str],
             period: int | None, amount: Any, currency: str, now: int) -> str:
    """The payee's Checkout JWT (UCP-shaped, with the A2C binding in ``a2c``)."""
    minor = to_minor(amount, currency)
    a2c = {"purpose": purpose, **digest_ref, "amount": amount, "currency": currency}
    if period is not None:
        a2c["period"] = period
    ref = next(iter(digest_ref.values()))
    return jwt_sign({
        "id": f"{ref}:{purpose}:{period or 0}", "merchant": dict(payee), "status": "ready_for_complete",
        "currency": currency, "links": [],
        "line_items": [{"id": "li_0", "item": {"id": f"a2c.{purpose}", "title": f"A2C {purpose}", "price": minor},
                        "quantity": 1, "totals": [{"type": "total", "amount": minor}]}],
        "totals": [{"type": "total", "amount": minor}], "a2c": a2c, "iat": now, "exp": now + 900}, key)


def checkout_mandate(checkout_jwt: str, payer: EcKey, now: int) -> str:
    return jwt_sign({"vct": "mandate.checkout.1", "checkout_jwt": checkout_jwt,
                     "checkout_hash": sha256_b64url(checkout_jwt), "iat": now, "exp": now + 900},
                    payer, typ="dc+sd-jwt", jwk_header=True) + "~"


def payment_mandate(checkout_jwt: str, payer: EcKey, *, payee: Mapping[str, str], amount: Any, currency: str,
                    instrument: Mapping[str, str], now: int) -> str:
    return jwt_sign({"vct": "mandate.payment.1", "transaction_id": sha256_b64url(checkout_jwt),
                     "payee": dict(payee), "payment_amount": {"amount": to_minor(amount, currency), "currency": currency},
                     "payment_instrument": dict(instrument), "iat": now, "exp": now + 900},
                    payer, typ="dc+sd-jwt", jwk_header=True) + "~"


def receipt(mandate: str, psp: EcKey, *, issuer: str, payment_id: str, now: int) -> str:
    return jwt_sign({"status": "Success", "iss": issuer, "iat": now, "reference": sha256_b64url(mandate.rstrip("~")),
                     "payment_id": payment_id, "psp_confirmation_id": payment_id, "network_confirmation_id": payment_id},
                    psp)


class AP2Payment:
    """The payer side of the payment port over AP2.

    ``payee_endpoint(card or request)`` names where to ask for the Checkout JWT
    (op ``ap2.checkout``); ``psp`` is the Payment Provider's endpoint (op ``ap2.pay``).
    """

    def __init__(self, transport: Transport, *, psp: str, payer: EcKey, instrument: Mapping[str, str],
                 clock: Callable[[], Any]) -> None:
        self.transport = transport
        self.psp = psp
        self.payer = payer
        self.instrument = dict(instrument)
        self.clock = clock

    def pay(self, *, purpose, template, card=None, request=None, period=None, termination=None) -> dict:
        from ..card import card_digest, request_digest
        subject = card if card is not None else request
        ref = {"requestDigest": request_digest(request)} if purpose == "proposal-fee" else {"cardDigest": card_digest(card)}
        now = int(self.clock().timestamp())
        ask: dict[str, Any] = {"purpose": purpose}
        if purpose == "proposal-fee":
            ask.update(templateDigest=request["templateDigest"], requestDigest=ref["requestDigest"])
        elif purpose == "termination":
            ask["cardDigest"] = ref["cardDigest"]
        else:
            ask["card"] = card
            if period:
                ask["period"] = period
        reply = self.transport.send(subject["provider"], "ap2.checkout", ask)
        checkout_jwt = reply.body["checkoutJwt"]
        _h, claims = jwt_decode(checkout_jwt)
        payee = claims["merchant"]
        if claims.get("a2c", {}).get("purpose") != purpose or any(claims["a2c"].get(k) != v for k, v in ref.items()):
            fail(INVALID_OBJECT, "checkout does not match the payment")
        amount, currency = claims["a2c"]["amount"], claims["a2c"]["currency"]
        body = {"checkoutMandate": checkout_mandate(checkout_jwt, self.payer, now),
                "paymentMandate": payment_mandate(checkout_jwt, self.payer, payee=payee, amount=amount,
                                                  currency=currency, instrument=self.instrument, now=now),
                "template": template}
        body["card" if card is not None else "request"] = subject
        if termination is not None:
            body["termination"] = termination
        out = self.transport.send(self.psp, "ap2.pay", body).body
        return out["voucher"]


__all__ = ["AP2_EXTENSION", "EcKey", "jwt_sign", "jwt_decode", "jwt_verify", "sha256_b64url", "to_minor", "checkout",
           "checkout_mandate", "payment_mandate", "receipt", "AP2Payment"]
