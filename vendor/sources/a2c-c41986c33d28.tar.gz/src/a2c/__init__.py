"""A2C: a contract layer over A2A."""
