"""jiuwenswarm as the A2C Client: an MCP server plus a connector package."""
