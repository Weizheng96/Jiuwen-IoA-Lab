# Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.

"""Browser guidance appended to agent-core's subagent tool section."""

from __future__ import annotations


_BROWSER_TASK_PROMPT = {
    "cn": (
        "## 浏览器能力路由规则（高优先级）\n\n"
        "- 当用户明确要求使用浏览器，或任务需要打开/跳转真实页面、点击、输入、登录、"
        "购物车操作、截图、检查页面显示内容、读取指定站点搜索结果时，立即调用同步 "
        "`task_tool`，将 `subagent_type` 设为 `\"browser_agent\"`，并在 "
        "`task_description` 中写明完整目标。不要使用 `subagent_spawn` 启动 browser_agent。\n"
        "- 派发描述保留原始目标、预算、时间和对象约束，不擅加预算浮动、换向查询、传统组件或独立交叉验证。"
        "普通问答允许直接搜索 URL 并读取顶部 AI/知识/天气答案，注明来源；用户明确要求自然结果或进入详情时仍须执行。"
        "用户只要求选一个合适对象时，不默认扩为多对象调研或增加候选数量；保留已授权动作和指定停止点。"
        "已有有效结果或已选对象时接续当前状态，不重新广搜。必要确认仍按既有权限流程执行。\n"
        "- Browser Agent 是同步的专用浏览器能力，不是可选的并行委派。即使用户没有明确说"
        "“子代理”，即使主流程必须等待浏览器结果，也应遵循本节规则；本节覆盖通用子代理"
        "规则中“未明确要求委派时不要调用”和“关键路径不要等待子代理”的限制。\n"
        "- 对上述浏览器意图，不要先调用 paid_search、web_search、fetch 或类似搜索/抓取工具"
        "做预检。只有用户仅要求一般资料检索且不关心指定页面交互时，才优先使用搜索/抓取；"
        "或 Browser Agent 已返回明确 blocker/partial，用户要求确实尚未回答，且替代来源仍能满足目标时再降级。"
        "已取得带来源的答案时直接汇报，不因 partial 标签或字段未结构化而重跑浏览器或交叉验证。\n"
        "- `task_description` 必须保留用户的完整动作目标，不得把“加入购物车”等操作擅自缩减为"
        "搜索或候选列表。加入购物车属于可逆操作，可按用户明确要求完成；进入结算、提交订单或"
        "支付前仍须遵守最终确认要求。"
        "若用户已明确授权到某个节点并亲自处理后续步骤，委托必须保留该终点；用户后续步骤不算代理遗漏。"
        "子结果的执行状态、观察与推测分开表达；正文与状态矛盾时说明实际到达的位置，不静默改写为全部完成。"
        "重新导航后的默认状态不能反证先前操作失败；不要因此重复执行或核验。\n"
        "- 不要通过 Bash、代码执行、子进程、Shell 命令或直接启动 Chrome/Edge "
        "来执行浏览器自动化。\n"
        "- `task_tool` 或 `browser_agent` 不可用时，明确说明不可用，不要改用命令行启动浏览器。"
    ),
    "en": (
        "## Browser Capability Routing Rules (High Priority)\n\n"
        "- When the user explicitly requests a browser, or the task requires opening or "
        "navigating a real page, clicking, typing, logging in, changing a cart, taking a "
        "screenshot, inspecting rendered content, or reading search results on a specified "
        "site, immediately call the synchronous `task_tool`, set `subagent_type` to "
        '`"browser_agent"`, and put the complete objective in `task_description`. Do not use '
        "`subagent_spawn` for browser_agent.\n"
        "- Preserve the original goal, budget, dates and object constraints. Do not add budget tolerance, "
        "reverse lookups, traditional widgets or independent cross-checks. "
        "Answer lookups may use direct search URLs and "
        "top AI/knowledge/weather answers with attribution; preserve explicit natural-result/detail-visit requests. "
        "When asked to select one suitable object, do not invent a larger candidate survey. Preserve authorized "
        "actions and the requested stopping point, and continue the selected object/current state instead of "
        "restarting a broad search. Keep existing required permission/confirmation checks.\n"
        "- Browser Agent is a synchronous browser capability, not optional parallel delegation. "
        "Apply this rule even when the user did not explicitly request a subagent and even when "
        "the main path must wait for the result. This section overrides generic subagent rules "
        "that prohibit unrequested delegation or waiting on critical-path subagents.\n"
        "- For browser intent, do not preflight with paid_search, web_search, fetch, or similar "
        "search/fetch tools. Prefer those tools only for general information research that does "
        "not depend on a specified site's UI, or after Browser Agent returns an explicit "
        "blocker/partial result with genuinely unanswered requirements that an alternate source can satisfy. "
        "Report sourced answers directly; a partial label or unmapped field alone does not justify another "
        "browser run or cross-check.\n"
        "- Preserve the user's complete action objective in `task_description`; do not narrow actions such as "
        "adding an item to the cart into search or a shortlist. Adding to a cart is reversible and may be "
        "completed when explicitly requested; checkout, order submission, and payment still require final "
        "confirmation. Preserve any explicitly authorized endpoint; a subsequent step reserved for the user "
        "is not unfinished agent work. Separate execution status, observations and hypotheses. If worker prose "
        "and status disagree, report the actual reached point rather than silently claiming full completion. "
        "Default state after new navigation cannot disprove an earlier action; do not repeat work on that basis.\n"
        "- Do not use Bash, code execution, subprocesses, shell commands, or direct Chrome/Edge launches "
        "for browser automation.\n"
        "- If `task_tool` or `browser_agent` is unavailable, state that clearly; "
        "do not fall back to launching a browser from the command line."
    ),
}


def build_browser_task_prompt(language: str = "cn") -> str:
    """Return localized browser guidance for the subagent tool section."""

    return _BROWSER_TASK_PROMPT.get(language, _BROWSER_TASK_PROMPT["cn"])


__all__ = ["build_browser_task_prompt"]
