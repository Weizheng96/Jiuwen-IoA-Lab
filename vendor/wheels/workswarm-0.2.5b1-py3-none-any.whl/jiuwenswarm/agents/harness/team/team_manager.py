# Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.

"""Team lifecycle manager."""

from __future__ import annotations

import asyncio
import copy
import logging
import re
import time
import weakref
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Literal

from openjiuwen.agent_teams.agent.team_agent import TeamAgent
from openjiuwen.agent_teams.runtime.background_task_controller import BackgroundTaskController
from openjiuwen.agent_teams.runtime.pool import RuntimeState
from openjiuwen.agent_teams.schema.blueprint import TeamAgentSpec
from openjiuwen.agent_teams.context import reset_session_id, set_session_id
from openjiuwen.agent_teams import observability as team_observability
from openjiuwen.core.runner import Runner
from openjiuwen.core.common.logging import server_logger
from openjiuwen.harness import DeepAgent
from openjiuwen.harness_protocol.state import HarnessState
from openjiuwen.core.foundation.llm import CompiledModelSelection
from openjiuwen.agent_teams.models.pool import materialize_model_group
from openjiuwen.harness.rails import (
    EvolutionInterruptRail,
    SkillEvolutionRail,
    TeamSkillCreateRail,
    TeamSkillEvolutionRail,
)
from jiuwenswarm.agents.harness.team.bootstrap import configure_agent_teams_home
from jiuwenswarm.common.cron_team_completion import (
    _cron_solo_harness_end_pending,
    apply_cron_team_round_event,
    cron_team_round_should_end,
    new_cron_team_round_state,
)
from jiuwenswarm.common.log_preview import preview_text
from jiuwenswarm.common.model_selection import ModelSelection as SwarmModelSelection
from jiuwenswarm.common.utils import get_user_workspace_dir

configure_agent_teams_home()

from jiuwenswarm.agents.harness.team.config_loader import (
    get_effective_team_model_entries,
    load_team_spec_dict,
)
from jiuwenswarm.agents.harness.team.distributed_runtime import (
    ensure_postgresql_for_leader,
    extract_pg_endpoint,
    fallback_distributed_to_local,
    is_distributed_mode,
    missing_distributed_dependencies,
    is_pg_available,
    is_postgresql_storage,
    normalize_distributed_transport_fields,
    parse_port,
    run_command,
    runtime_member_name,
    runtime_role,
    try_start_pg_cluster,
)
from jiuwenswarm.agents.harness.team.handlers.team_monitor_handler import TeamMonitorHandler
from jiuwenswarm.agents.harness.team.remote_member_bootstrap import release_a2x_reservations_for_session
from jiuwenswarm.common.config import (
    get_config,
    get_evolution_auto_save_enabled,
    get_skill_evolution_enabled,
    get_symphony_evolution_enabled,
)
from jiuwenswarm.common.reasoning_injector import build_reasoning_model_request_kwargs
from jiuwenswarm.agents.harness.team.team_runtime_inheritance import (
    MemberInfo,
    RuntimeInfo,
    TeamWorkspaceInfo,
    build_member_rails,
    get_default_model_name,
)
from jiuwenswarm.agents.harness.observability_runtime import build_observability_config
from jiuwenswarm.observability.config import load_trajectory_store_settings
from jiuwenswarm.observability.runtime import (
    shutdown_trajectory_runtime,
    sync_trajectory_runtime,
)
from jiuwenswarm.server.runtime.session.session_metadata import get_session_metadata

logger = logging.getLogger(__name__)

# Wall-clock cap for a single external command (pg_isready, systemctl, etc.).
_SUBPROCESS_TIMEOUT_SEC = 120.0
# After pg_ctlcluster/systemd reports start, the server may still be initializing.
_PG_POST_START_READY_MAX_SEC = 30.0
_PG_POST_START_READY_INIT_SLEEP = 0.4
_PG_POST_START_READY_MAX_SLEEP = 2.0
_PG_POST_START_READY_BACKOFF = 1.45
_PG_POST_START_LOG_EVERY_SEC = 5.0
_TEAM_STREAM_EXIT_GRACE_TIMEOUT_SEC = 1.5
# Bound each frontend waiter's event backlog.  Producers await a free slot, so
# a slow or disconnected TUI consumer cannot make the process retain every
# event emitted by a long-running team session.
TEAM_EVENT_QUEUE_MAXSIZE = 64
_WAITER_PUT_RECHECK_TIMEOUT_SEC = 0.1
_TEAM_ROUND_FINAL_GRACE_SECONDS = 2.0


def _safe_payload_preview(payload: Any) -> str:
    """Render an interact payload as a bounded single-line log fragment.

    Args:
        payload: Raw interact payload, either plain text or a team message
            object (``GodViewMessage`` / ``HumanAgentMessage`` / ...).

    Returns:
        Clipped text of the payload body, prefixed with the payload type when
        it is not a plain string.
    """
    if isinstance(payload, str):
        return preview_text(payload)
    body = getattr(payload, "body", None)
    text = body if isinstance(body, str) else str(payload)
    return f"<{type(payload).__name__}>{preview_text(text)}"

# ── Team Observability ──────────────────────────────────────
# Tracks whether observability is currently active so we can
# detect config toggles (enabled → disabled or vice-versa)
# and init / shutdown accordingly on each team request.
_observability_active: bool = False


def sync_team_observability() -> None:
    """Synchronize observability state with current config.

    Called before each ``Runner.run_agent_team_streaming`` so that
    hot-reloading the ``team_observability.enabled`` flag takes
    effect immediately:

    * disabled → enabled : ``init_observability()``
    * enabled → disabled : ``shutdown_observability()``
    * unchanged          : no-op

    The Web trajectory store is an independent fan-out owned by
    ``sync_trajectory_runtime``; Team tracing keeps its own demand so
    disabling Team observability never tears down a trajectory sink another
    runtime still uses.

    Evolution also requests the provider when the explicit switch is disabled.
    """
    global _observability_active
    config = get_config()
    cfg = config.get("team_observability", {}) or {}
    trajectory_settings = load_trajectory_store_settings(config)
    evolution_requested = get_skill_evolution_enabled(
        config
    ) or get_symphony_evolution_enabled(config)
    # The Web trajectory store needs the provider exactly like single-Agent
    # does: spans must be exported so the record processor can fan them out to
    # the SQLite sink. ``trajectory_ui.enabled`` therefore also pulls the
    # provider up, mirroring ``sync_agent_observability``.
    want_enabled = (
        bool(cfg.get("enabled", False))
        or trajectory_settings.enabled
        or evolution_requested
    )

    # Always synchronize the trajectory store first (start when its setting is
    # enabled, tear the sink down otherwise); the provider decision below only
    # controls the tracing side.
    try:
        sync_trajectory_runtime(trajectory_settings, demand="team")
    except Exception as exc:
        logger.warning("[TeamObservability] trajectory runtime sync failed: %s", exc)

    if not want_enabled:
        if _observability_active:
            shutdown_team_observability()
        return

    try:
        traces_dir = str(cfg.get("traces_dir") or get_user_workspace_dir() / ".trace")
        obs_cfg = build_observability_config(
            cfg,
            service_name="jiuwenswarm",
            traces_dir=traces_dir,
        )
        provider_existed = team_observability.acquire_observability(obs_cfg)
        was_active = _observability_active
        _observability_active = True
        if not was_active and not provider_existed:
            # Log the resolved config, not the yaml: the two once diverged
            # silently and this line hid it.
            if obs_cfg.exporter == "file":
                logger.info(
                    "[TeamObservability] enabled: exporter=%s traces_dir=%s",
                    obs_cfg.exporter,
                    obs_cfg.traces_dir,
                )
            else:
                logger.info(
                    "[TeamObservability] enabled: exporter=%s endpoint=%s",
                    obs_cfg.exporter,
                    obs_cfg.endpoint,
                )
    except Exception as exc:
        _observability_active = False
        if evolution_requested:
            raise RuntimeError(
                "Team evolution observability initialization failed"
            ) from exc
        logger.warning("[TeamObservability] init failed: %s", exc)


def shutdown_team_observability() -> None:
    """Shutdown team observability (called on disable or process exit)."""
    global _observability_active
    try:
        if not shutdown_trajectory_runtime(demand="team"):
            logger.warning("[TeamObservability] trajectory runtime did not drain cleanly")
    except Exception as exc:
        logger.warning("[TeamObservability] trajectory runtime shutdown failed: %s", exc)
    if not _observability_active:
        return
    try:
        team_observability.release_observability()
        _observability_active = False
        logger.info("[TeamObservability] disabled")
    except Exception as exc:
        logger.warning("[TeamObservability] shutdown failed: %s", exc)


@dataclass
class TeamRailMountContext:
    """Context needed to rebuild team rails after a hot config toggle."""

    agent: Any
    member_info: MemberInfo
    runtime: RuntimeInfo
    team_workspace: TeamWorkspaceInfo


@dataclass
class _ActiveTeamRound:
    """Process-local ownership for one submitted Team interaction round."""

    request_id: str
    generation: int = 0
    release_admission: Callable[[], Awaitable[None]] | None = None
    defer_terminal_release: bool = False
    terminal_armed: bool = False
    # 本回合见证过 swarmflow 终态事件（workflow.updated 转入 completed/failed/
    # stopped）。收尾探测据此区分「本回合正在汇报 flow 结果」与「上一回合遗留
    # 的终态 run」；标记随回合对象生灭，不跨回合。
    saw_flow_terminal: bool = False
    # Terminal replays must not hide execution that continued after the flow.
    continued_after_flow: bool = False
    open_archive_tasks: set[str] = field(default_factory=set)
    completion_state: dict[str, Any] = field(
        default_factory=new_cron_team_round_state
    )
    completion_task: asyncio.Task | None = None


def _make_team_rail_mount_context(
    *,
    agent: Any,
    role: str,
    channel: str = "default",
    language: str = "cn",
    member_name: str | None = None,
    model_name: str | None = None,
    root_dir: str | None = None,
    project_dir: str | None = None,
    skills_dir: str | None = None,
    team_id: str | None = "",
    config: dict[str, Any] | None = None,
    trajectory_span_processor: Any | None = None,
) -> TeamRailMountContext:
    """Build the shared rail context used by swarm and legacy rail mounts."""
    card = getattr(agent, "card", None)
    agent_name = (
        str(member_name or "").strip()
        or str(getattr(card, "name", "") or "").strip()
        or "team_member"
    )
    resolved_model_name = model_name or get_default_model_name(config)
    return TeamRailMountContext(
        agent=agent,
        member_info=MemberInfo(
            agent_name=agent_name,
            model_name=resolved_model_name,
            role=role,
        ),
        runtime=RuntimeInfo(channel=channel, language=language),
        team_workspace=TeamWorkspaceInfo(
            root_dir=root_dir,
            project_dir=project_dir,
            skills_dir=skills_dir,
            team_id=team_id,
            config=config,
            trajectory_span_processor=trajectory_span_processor,
        ),
    )


async def _stop_team_messager(team_agent: Any, *, session_id: str) -> None:
    """Stop a team's mailbox transport so per-team ZMQ sockets release their ports."""
    infra = getattr(team_agent, "infra", None)
    messager = getattr(infra, "messager", None) if infra is not None else None
    stop = getattr(messager, "stop", None)
    if not callable(stop):
        return
    try:
        await stop()
        logger.info("[TeamManager] team messager stopped: session_id=%s", session_id)
    except Exception as exc:
        logger.warning("[TeamManager] team messager stop failed: session_id=%s error=%s", session_id, exc)


def _runner_team_runtime_manager(runner: Any) -> Any:
    """Return Runner's team runtime manager without calling its protected method."""
    attr_name = "_team_runtime_manager"
    manager = vars(runner).get(attr_name)
    if manager is None:
        from openjiuwen.agent_teams.runtime import TeamRuntimeManager

        manager = TeamRuntimeManager()
        setattr(runner, attr_name, manager)
    return manager


class TeamManager:
    """Manage team instances across sessions."""

    def __init__(self):
        # These TeamAgent objects are auxiliary runtimes used only by the
        # distributed teammate bootstrap path. Local leader execution is owned
        # by Runner's TeamRuntimePool instead.
        self._team_agents: dict[str, TeamAgent] = {}
        self._runner_team_agents: dict[str, TeamAgent] = {}
        self._team_monitors: dict[str, TeamMonitorHandler] = {}
        self._stream_tasks: dict[str, asyncio.Task] = {}
        self._stream_task_generations: dict[str, int] = {}
        self._session_generations: dict[str, int] = {}
        self._request_generations: dict[tuple[str, str], int] = {}
        self._waiter_generations: dict[tuple[str, str], int] = {}
        # session_id → request_ids registered as attach-only observation
        # waiters; they receive broadcasts but do not own the Team stream.
        self._attach_waiter_ids: dict[str, set[str]] = {}
        self._round_state_reporter: Callable[[str, int, bool], None] | None = None
        # session_id → request_ids of Team turns that entered the adapter but
        # have not reached a released round yet.  Covers the preparation window
        # (spec assembly, runtime activation) that precedes the round marker.
        self._inflight_requests: dict[str, set[str]] = {}
        # session_id → request_ids whose Team round was already released while
        # their chat response handler may still be parked on the persistent
        # leader stream.  Cleared when that stream ends; distinguishes a
        # parked handler from one that still owns live team work.
        self._round_ended_requests: dict[str, set[str]] = {}
        self._held_idle: dict[str, dict[str, Any]] = {}
        self._background_task_controllers: dict[str, BackgroundTaskController] = {}
        self._bootstrap_lock = asyncio.Lock()
        self._distributed_switch_lock = asyncio.Lock()
        self._session_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = (
            weakref.WeakValueDictionary()
        )
        self._startup_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = (
            weakref.WeakValueDictionary()
        )
        # 当 cancel 请求到达时设置，通知正在执行的 pause 操作中止自身并让 cancel 执行
        self._cancel_requested: dict[str, bool] = {}
        # 追踪当前正在执行的 pause 任务，供 cancel 抢占取消
        self._active_pause_tasks: dict[str, asyncio.Task] = {}
        self._active_team_names: dict[str, str] = {}
        self._pending_team_names: dict[str, str] = {}
        # session_id → list of (request_id, asyncio.Queue) waiters
        self._pending_waiters: dict[str, list[tuple[str, asyncio.Queue]]] = {}
        # A bounded automated round temporarily owns event delivery for the
        # session. The original browser waiter stays registered for later
        # interactive rounds, while this round is delivered exactly once.
        self._exclusive_waiters: dict[str, str] = {}
        # Team runner streams are deliberately persistent.  This registry
        # describes the single actual round admitted for a Session and owns
        # its admission release until terminal/cancel cleanup.
        self._active_rounds: dict[str, _ActiveTeamRound] = {}
        # session_id → cron team round completion state. Lifetime-coupled to
        # _pending_waiters: set by _try_finish_cron_team_stream, popped by the
        # finisher coroutines once the cron stream ends.
        self._cron_team_completion: dict[str, dict[str, Any]] = {}
        # Sessions that have successfully initialized a team runtime at least once.
        # Persists across stream lifecycles so follow-up requests are not
        # misidentified as first requests.
        self._initialized_sessions: set[str] = set()
        # session_id → TeamSkillEvolutionRail instance (set by customizer, used for drain/approval)
        self._team_skill_rails: dict[str, Any] = {}
        # session_id → member SkillEvolutionRail instances
        self._team_member_skill_evolution_rails: dict[str, list[Any]] = {}
        # session_id → TeamSkillCreateRail instance
        self._team_skill_create_rails: dict[str, Any] = {}
        # session_id → context used to rebuild team rails on config enable
        self._team_rail_contexts: dict[str, TeamRailMountContext] = {}
        # session_id → latest in-memory canonical evolution switch.  Slash
        # handling and other request hot paths must consult this snapshot
        # instead of re-reading config.yaml.
        self._team_evolution_enabled: dict[str, bool] = {}
        # session_id → teammate contexts used to rebuild member rails after a
        # disabled → enabled hot toggle without recreating the team runtime.
        self._team_member_rail_contexts: dict[str, list[TeamRailMountContext]] = {}
        # session_id → live rails and owning DeepAgent, for hot-unregister
        self._team_live_rails: dict[str, list[tuple[Any, Any]]] = {}
        # session_id → evolution watcher task
        self._team_evolution_watchers: dict[str, asyncio.Task] = {}
        # session_id → runtime_ready requested a watcher before the rail registered
        self._pending_team_evolution_watcher_sessions: set[str] = set()
        # session_id → workflow handler instance
        self._workflow_handlers: dict[str, Any] = {}
        # Permanent-delete admission fence. It remains set after destructive
        # cleanup and is cleared only when the Runtime delete commits/aborts.
        self._terminal_delete_sessions: set[str] = set()
        self._session_inactive_reporter: (
            Callable[[str], Awaitable[None]] | None
        ) = None

    def bind_generation(self, session_id: str, generation: int) -> None:
        """Bind future process-local Team handles to one Session generation."""
        current = self._session_generations.get(session_id)
        if current is not None and generation < current:
            raise RuntimeError(
                f"stale Team generation: session={session_id} "
                f"expected={current} actual={generation}"
            )
        self._session_generations[session_id] = generation

    def set_round_state_reporter(
        self,
        reporter: Callable[[str, int, bool], None] | None,
    ) -> None:
        """Attach the Runtime observer for active versus parked Team rounds."""
        self._round_state_reporter = reporter

    def report_round_state(
        self,
        session_id: str,
        generation: int | None,
        *,
        running: bool,
    ) -> None:
        """Report the currently observed round activity to the Runtime observer.

        Used when an execution attaches while the Team stream is already
        idle: no round transition will fire the reporter on its own, so the
        attach path aligns its execution state to what it observes —
        otherwise a RUNNING execution keeps the Session busy (undeletable)
        forever. A missing generation means no Runtime execution owns the
        caller, so there is nothing to align.
        """
        if self._round_state_reporter is None or generation is None:
            return
        if not self.generation_matches(session_id, generation):
            return
        self._round_state_reporter(session_id, generation, running)

    def generation_matches(self, session_id: str, generation: int | None) -> bool:
        """Return whether a callback belongs to the current Session generation."""
        if generation is None:
            return True
        return self._session_generations.get(session_id) == generation

    def has_stream_task(
        self,
        session_id: str,
        *,
        generation: int | None = None,
    ) -> bool:
        if not self.generation_matches(session_id, generation):
            return False
        return session_id in self._stream_tasks

    def pop_stream_task(
        self,
        session_id: str,
        *,
        generation: int | None = None,
    ) -> asyncio.Task | None:
        if not self.generation_matches(session_id, generation):
            return None
        if generation is not None and self._stream_task_generations.get(session_id) != generation:
            return None
        # Stream end releases every handler parked on it; their ended-round
        # markers die with the stream instead of accumulating per round.
        self._round_ended_requests.pop(session_id, None)
        self._stream_task_generations.pop(session_id, None)
        return self._stream_tasks.pop(session_id, None)

    def begin_request(
        self,
        session_id: str,
        request_id: str,
        *,
        generation: int | None = None,
    ) -> None:
        """Mark a Team turn as in flight before its round exists.

        The adapter admits a Team request long before ``begin_round`` runs
        (spec assembly, MCP preflight, runtime activation).  Without this
        marker the Session looks idle for that whole window.
        """
        if generation is not None:
            self.bind_generation(session_id, generation)
        normalized_request_id = str(request_id or "")
        self._inflight_requests.setdefault(session_id, set()).add(normalized_request_id)
        if generation is not None:
            self._request_generations[(session_id, normalized_request_id)] = generation

    def end_request(
        self,
        session_id: str,
        request_id: str,
        *,
        generation: int | None = None,
    ) -> None:
        """Release one in-flight Team turn.  Idempotent."""
        normalized_request_id = str(request_id or "")
        expected_generation = self._request_generations.get(
            (session_id, normalized_request_id)
        )
        if generation is not None and expected_generation != generation:
            return
        requests = self._inflight_requests.get(session_id)
        if requests is None:
            return
        requests.discard(normalized_request_id)
        self._request_generations.pop((session_id, normalized_request_id), None)
        if not requests:
            self._inflight_requests.pop(session_id, None)

    def has_inflight_request(self, session_id: str) -> bool:
        return bool(self._inflight_requests.get(session_id))

    def is_session_initialized(self, session_id: str) -> bool:
        """Return whether the session has ever initialized a team runtime."""
        return session_id in self._initialized_sessions

    def clear_session_initialized(self, session_id: str) -> None:
        """Clear the initialized marker for a session (e.g. on stream end)."""
        self._initialized_sessions.discard(session_id)

    def has_waiters(self, session_id: str) -> bool:
        """Return whether there are pending waiters for the given session."""
        return bool(self._pending_waiters.get(session_id))

    def has_interactive_waiter(self, session_id: str) -> bool:
        """Return whether a non-automation consumer owns the persistent stream."""
        exclusive_request_id = self._exclusive_waiters.get(session_id)
        return any(
            request_id != exclusive_request_id
            for request_id, _queue in self._pending_waiters.get(session_id, ())
        )

    def add_waiter(
        self,
        session_id: str,
        request_id: str,
        queue: asyncio.Queue,
        *,
        exclusive: bool = False,
        generation: int | None = None,
        attach_only: bool = False,
    ) -> None:
        """Register a waiter queue for a session's event stream.

        ``attach_only`` marks a pure observation subscription: it receives
        broadcasts like any waiter but never implies the Team stream is
        alive or accepting input (see ``has_input_waiters``).
        """
        if generation is not None:
            self.bind_generation(session_id, generation)
            self._waiter_generations[(session_id, request_id)] = generation
        self._pending_waiters.setdefault(session_id, []).append((request_id, queue))
        if exclusive:
            self._exclusive_waiters[session_id] = request_id
        if attach_only:
            self._attach_waiter_ids.setdefault(session_id, set()).add(request_id)

    def remove_waiter(
        self,
        session_id: str,
        request_id: str,
        *,
        generation: int | None = None,
    ) -> None:
        """Remove a waiter by request_id; clean up empty lists."""
        expected_generation = self._waiter_generations.get((session_id, request_id))
        if generation is not None and expected_generation != generation:
            return
        self._waiter_generations.pop((session_id, request_id), None)
        if self._exclusive_waiters.get(session_id) == request_id:
            self._exclusive_waiters.pop(session_id, None)
        attach_ids = self._attach_waiter_ids.get(session_id)
        if attach_ids is not None:
            attach_ids.discard(request_id)
            if not attach_ids:
                self._attach_waiter_ids.pop(session_id, None)
        waiters = self._pending_waiters.get(session_id)
        if waiters is None:
            return
        remaining = [(rid, q) for rid, q in waiters if rid != request_id]
        if remaining:
            self._pending_waiters[session_id] = remaining
        else:
            self._pending_waiters.pop(session_id, None)

    def has_input_waiters(self, session_id: str) -> bool:
        """Return whether any waiter belongs to an input-owning stream.

        Attach-only subscriptions observe events without owning the Team
        stream; their presence must not flip a fresh user turn into a
        follow-up (the follow-up path would deliver into a stopped runtime
        and stall on ``gate_closed``).
        """
        attach_ids = self._attach_waiter_ids.get(session_id)
        if not attach_ids:
            return bool(self._pending_waiters.get(session_id))
        return any(
            request_id not in attach_ids
            for request_id, _queue in self._pending_waiters.get(session_id, ())
        )

    def _select_broadcast_waiters(
        self,
        session_id: str,
    ) -> list[tuple[str, asyncio.Queue]]:
        """Select event consumers without duplicating attach delivery.

        A Team event forwarded by one interactive waiter is routed by the
        Gateway to every client subscribed to the Session. Attach-only waiters
        are therefore fallback upstream observers, not additional fan-out
        destinations. Keeping all of them registered preserves reconnect and
        multi-window liveness, while selecting one prevents every observer
        stream from persisting the same event again.

        Returns:
            Waiters that should receive the next event.
        """
        waiters = list(self._pending_waiters.get(session_id, ()))
        exclusive_request_id = self._exclusive_waiters.get(session_id)
        if exclusive_request_id is not None:
            return [
                (request_id, queue)
                for request_id, queue in waiters
                if request_id == exclusive_request_id
            ]

        attach_ids = self._attach_waiter_ids.get(session_id, set())
        input_waiters = [
            (request_id, queue)
            for request_id, queue in waiters
            if request_id not in attach_ids
        ]
        if input_waiters:
            return input_waiters
        return waiters[:1]

    async def broadcast_event(
        self,
        session_id: str,
        event: dict[str, Any],
        *,
        channel_id: str | None = None,
    ) -> bool:
        """Broadcast an event with backpressure to every active waiter.

        The short timed wait is only used while a queue is full.  It lets a
        producer notice that ``remove_waiter`` detached a disconnected client
        instead of remaining blocked forever on that orphaned queue.

        Returns:
            True when at least one waiter received the event.  Callers that
            persist event history may use this to detect that nobody consumed
            the frame; the selection and delivery happen under the same call,
            so the answer is atomic with the broadcast itself.
        """
        event_type = str(event.get("event_type") or "")
        terminal = (
            event_type == "chat.processing_status"
            and event.get("is_processing") is False
            and event.get("is_complete") is True
        )
        current_round = self._active_rounds.get(session_id)
        if terminal and current_round is not None and not current_round.terminal_armed:
            # A persistent Runner stream can emit duplicate terminal frames
            # after the previous round has released.  A follow-up round is not
            # allowed to accept a terminal until that stream has produced at
            # least one event for the newly submitted interaction.  Dropping
            # the stale control frame also keeps it out of the new exclusive
            # waiter.
            logger.debug(
                "[TeamManager] ignored unarmed terminal: session_id=%s request_id=%s",
                session_id,
                current_round.request_id,
            )
            return False
        if not terminal and current_round is not None:
            current_round.terminal_armed = True
        if current_round is not None and self._is_workflow_terminal_event(event):
            # 见证即记录：无论有没有 waiter，本回合看到 flow 终态就置位，
            # 收尾探测（team_round_finishing_after_flow）据此关联回合与 run。
            current_round.saw_flow_terminal = True
        if current_round is not None:
            if event_type == "team.task":
                task = event.get("event")
                if isinstance(task, dict) and task.get("task_id"):
                    task_id = str(task["task_id"])
                    status = task.get("status")
                    task_type = str(task.get("type") or "")
                    if status in {"completed", "cancelled", "failed"} or task_type.endswith(
                        (".completed", ".cancelled", ".verified")
                    ):
                        current_round.open_archive_tasks.discard(task_id)
                    elif status or task_type.endswith((".created", ".started", ".claimed")):
                        current_round.open_archive_tasks.add(task_id)
                        if current_round.saw_flow_terminal:
                            current_round.continued_after_flow = True
            if current_round.saw_flow_terminal and event_type in {
                "chat.tool_call", "chat.ask_user_question",
            }:
                current_round.continued_after_flow = True

        waiters = self._select_broadcast_waiters(session_id)

        if not waiters:
            if self._is_workflow_terminal_event(event):
                # A cancel/stop kills the chat stream (and with it the waiters)
                # before the engine unwinds and emits the terminal workflow
                # status ~1s later; the normal broadcast has nowhere to land and
                # the frontend keeps showing the previous status until the user
                # opens the workflows view. Fall back to the gateway server-push
                # side channel, which delivers events without a chat stream.
                await self._push_event_without_waiter(
                    session_id, event, channel_id=channel_id
                )
            elif terminal:
                # A mailbox-driven Team round runs with no interactive waiter:
                # its terminal frame would land nowhere and the frontend would
                # keep showing the Session as running. Mirror the workflow
                # fallback and deliver it through the server-push side channel.
                await self._push_event_without_waiter(
                    session_id, event, channel_id=channel_id
                )

        async def _put_to_waiter(
            request_id: str,
            queue: asyncio.Queue,
        ) -> None:
            queued_event = dict(event)
            while any(
                rid == request_id and registered_queue is queue
                for rid, registered_queue in self._pending_waiters.get(session_id, ())
            ):
                try:
                    await asyncio.wait_for(
                        queue.put(queued_event),
                        timeout=_WAITER_PUT_RECHECK_TIMEOUT_SEC,
                    )
                    break
                except asyncio.TimeoutError:
                    continue
                except Exception:
                    logger.debug(
                        "[TeamManager] broadcast failed: session_id=%s request_id=%s",
                        session_id,
                        request_id,
                        exc_info=True,
                    )
                    break

        await asyncio.gather(*(
            _put_to_waiter(request_id, queue)
            for request_id, queue in waiters
        ))

        # Deliver the terminal frame before releasing admission.  This keeps a
        # new user/Heartbeat round from installing a waiter in the middle of
        # the previous round's final broadcast.
        if terminal:
            await self.finish_round(session_id)
        elif current_round is not None and not current_round.defer_terminal_release:
            self._observe_interactive_round_event(
                session_id,
                current_round,
                event,
            )
        return bool(waiters)

    @staticmethod
    def _is_workflow_terminal_event(event: dict[str, Any]) -> bool:
        """Whether the event is a workflow.updated carrying a terminal status."""
        if not isinstance(event, dict) or event.get("event_type") != "workflow.updated":
            return False
        workflow = event.get("workflow")
        status = (
            workflow.get("status") if isinstance(workflow, dict) else event.get("status")
        )
        return str(status or "") in {"stopped", "paused", "completed", "failed"}

    async def _push_event_without_waiter(
        self,
        session_id: str,
        event: dict[str, Any],
        *,
        channel_id: str | None = None,
    ) -> None:
        """Deliver a waiter-less terminal event via gateway server push."""
        try:
            from jiuwenswarm.server.agent_ws_server import AgentWebSocketServer

            server = AgentWebSocketServer.get_instance()
        except Exception:
            logger.debug(
                "[TeamManager] waiter-less push fallback: server unavailable: session_id=%s",
                session_id,
                exc_info=True,
            )
            return
        payload = dict(event)
        payload.setdefault("session_id", session_id)
        pushed = await server.send_push(
            {
                "request_id": "",
                "channel_id": str(channel_id or "").strip() or "web",
                "session_id": session_id,
                "payload": payload,
                "is_complete": False,
            }
        )
        if pushed:
            status = (
                payload.get("workflow", {}).get("status", "")
                if isinstance(payload.get("workflow"), dict)
                else payload.get("status", "")
            )
            logger.info(
                "[TeamManager] terminal event pushed without waiter: "
                "session_id=%s event_type=%s status=%s",
                session_id,
                str(payload.get("event_type") or ""),
                status,
            )

    def _observe_interactive_round_event(
        self,
        session_id: str,
        current_round: _ActiveTeamRound,
        event: dict[str, Any],
    ) -> None:
        """Synthesize a terminal for supported final-only Team runtimes."""
        apply_cron_team_round_event(current_round.completion_state, event)
        should_end = cron_team_round_should_end(current_round.completion_state)
        pending_task = current_round.completion_task
        if not should_end:
            if pending_task is not None and not pending_task.done():
                pending_task.cancel()
            current_round.completion_task = None
            return
        if pending_task is not None and not pending_task.done():
            return
        grace_seconds = (
            _TEAM_ROUND_FINAL_GRACE_SECONDS
            if _cron_solo_harness_end_pending(current_round.completion_state)
            else 0.0
        )
        current_round.completion_task = asyncio.create_task(
            self._finish_interactive_round_after_grace(
                session_id,
                current_round.request_id,
                grace_seconds,
            ),
            name=f"team-round-final-{session_id}",
        )

    async def _finish_interactive_round_after_grace(
        self,
        session_id: str,
        request_id: str,
        grace_seconds: float,
    ) -> None:
        """Finish the same round only if no delegation event invalidated its final."""
        if grace_seconds > 0:
            await asyncio.sleep(grace_seconds)
        current = self._active_rounds.get(session_id)
        if current is None or current.request_id != request_id:
            return
        current.completion_task = None
        if current.defer_terminal_release:
            return
        if not cron_team_round_should_end(current.completion_state):
            return
        await self.broadcast_event(
            session_id,
            {
                "event_type": "chat.processing_status",
                "session_id": session_id,
                "request_id": request_id,
                "is_processing": False,
                "is_complete": True,
            },
        )

    def begin_round(
        self,
        session_id: str,
        request_id: str,
        *,
        release_admission: Callable[[], Awaitable[None]] | None = None,
        defer_terminal_release: bool = False,
        terminal_armed: bool = False,
        generation: int | None = None,
    ) -> None:
        """Bind the one admitted interaction round to its request."""
        self._assert_session_not_deleting(session_id)
        if generation is not None:
            self.bind_generation(session_id, generation)
        current = self._active_rounds.get(session_id)
        if current is not None:
            raise RuntimeError(
                f"team round already active for session {session_id}: "
                f"{current.request_id}"
            )
        self._active_rounds[session_id] = _ActiveTeamRound(
            request_id=request_id,
            generation=generation or self._session_generations.get(session_id, 0),
            release_admission=release_admission,
            defer_terminal_release=defer_terminal_release,
            terminal_armed=terminal_armed,
        )
        if self._round_state_reporter is not None:
            self._round_state_reporter(
                session_id,
                self._active_rounds[session_id].generation,
                True,
            )

    async def finish_round(self, session_id: str) -> None:
        """Finish the current round on a runtime terminal event."""
        current = self._active_rounds.get(session_id)
        if current is None or current.defer_terminal_release:
            return
        await self.release_round(session_id, current.request_id)

    async def release_round(
        self,
        session_id: str,
        request_id: str,
        *,
        generation: int | None = None,
    ) -> bool:
        """Idempotently release one round and its admission lease."""
        current = self._active_rounds.get(session_id)
        generation_matches = (
            generation is None or current is None or current.generation == generation
        )
        if (
            current is None
            or current.request_id != request_id
            or not generation_matches
        ):
            return False
        self._active_rounds.pop(session_id, None)
        # The round terminal ends the turn's in-flight window as well, so the
        # archive guard stops treating a finished Team Session as running.
        self.end_request(session_id, request_id, generation=generation)
        # This marker only describes a handler parked on an existing persistent
        # stream.  Failed startup and stop paths can release a round after the
        # stream has already gone away; retaining their request ids would leak
        # per-session state and could be mistaken for a future parked handler.
        if self.has_stream_task(session_id):
            self._round_ended_requests.setdefault(session_id, set()).add(
                str(request_id or "")
            )
        completion_task = current.completion_task
        if (
            completion_task is not None
            and completion_task is not asyncio.current_task()
            and not completion_task.done()
        ):
            completion_task.cancel()
        if current.release_admission is not None:
            await current.release_admission()
        if self._round_state_reporter is not None:
            self._round_state_reporter(
                session_id,
                current.generation,
                False,
            )
        return True

    async def release_current_round(self, session_id: str) -> bool:
        """Release whichever round owns a stream that has just terminated."""
        current = self._active_rounds.get(session_id)
        if current is None:
            return False
        return await self.release_round(session_id, current.request_id)

    def is_round_active(self, session_id: str) -> bool:
        """Return whether a Team round, rather than its transport, is active."""
        return session_id in self._active_rounds

    def round_can_finish_after_flow(self, session_id: str) -> bool:
        """Whether the round saw a flow end without outstanding or subsequent work."""
        current = self._active_rounds.get(session_id)
        return (
            current is not None
            and current.saw_flow_terminal
            and not current.continued_after_flow
            and not current.open_archive_tasks
        )

    def is_round_owner(self, session_id: str, request_id: str) -> bool:
        current = self._active_rounds.get(session_id)
        return current is not None and current.request_id == request_id

    def is_round_ended_request(self, session_id: str, request_id: str) -> bool:
        """Whether this request's Team round was already released.

        Its chat response handler can stay parked on the persistent leader
        stream long after the round ended; the archive busy guard treats
        such a handler as parked rather than running.  A request still
        preparing or mid-round has no marker here and keeps the Session
        running.
        """
        return str(request_id or "") in self._round_ended_requests.get(session_id, ())

    async def abort_round(self, session_id: str, request_id: str) -> bool:
        """Stop a cancelled automated round before releasing its ownership.

        Agent-core exposes runtime stop rather than a per-interaction abort.
        Stopping preserves persisted Team state; a later request cold-recovers
        the runtime and cannot receive ghost output from the cancelled round.
        Every local object bound to the stopped runtime must be detached as
        well; in particular, a running TeamMonitorHandler cannot be reused
        after cold recovery because it still listens to the old TeamAgent.
        """
        async with self._get_lifecycle_lock(session_id):
            if not self.is_round_owner(session_id, request_id):
                return False
            team_name = self._resolve_session_team_name(session_id)
            if team_name:
                try:
                    await Runner.stop_agent_team(
                        team_name=team_name,
                        session_id=session_id,
                    )
                except Exception as exc:  # noqa: BLE001
                    # Cancelling the local consumer below is the mandatory
                    # fallback: it closes the active Runner generator even if the
                    # public pool stop reports a transient teardown error.
                    logger.warning(
                        "[TeamManager] heartbeat round stop failed; cancelling stream: "
                        "session_id=%s request_id=%s error=%s",
                        session_id,
                        request_id,
                        exc,
                    )
            # Runner.stop_agent_team removes the runtime from the pool.  Mirror the
            # normal terminal cleanup path so a later cold recovery creates fresh
            # stream/monitor/rail bindings instead of retaining objects attached to
            # the stopped TeamAgent.  This also cancels the local stream when the
            # Runner stop above failed, preserving the no-ghost fallback.
            await self._cleanup_runtime_locals(session_id)
            await self._stop_runner_team_agent_transport(session_id)
            self.clear_active_runtime(session_id)
            self.clear_pending_runtime(session_id)
            self._clear_terminal_session_markers(session_id)
            await self.release_round(session_id, request_id)
            return True

    def get_waiters(self, session_id: str) -> list[tuple[str, asyncio.Queue]]:
        """Return the (request_id, queue) pairs waiting on the given session."""
        return self._pending_waiters.get(session_id, [])

    def get_cron_completion(self, session_id: str) -> dict[str, Any] | None:
        """Return the cron team round completion state for the session, if any."""
        return self._cron_team_completion.get(session_id)

    def setdefault_cron_completion(
        self, session_id: str, default: dict[str, Any]
    ) -> dict[str, Any]:
        """Get or create the cron team round completion state for the session."""
        return self._cron_team_completion.setdefault(session_id, default)

    def pop_cron_completion(self, session_id: str) -> dict[str, Any] | None:
        """Drop the cron team round completion state for the session."""
        return self._cron_team_completion.pop(session_id, None)

    # team.idle is a one-shot marker from the framework. When the idle guard
    # swallows it because a swarmflow run is still active, the lamp can only
    # go out if something re-emits idle — and a tree-view pause/stop that
    # drains the active set produces no member activity, so nothing does. The
    # guard parks the swallowed marker here; the workflow consumer releases it
    # once every run has left the active set.
    def hold_idle(self, session_id: str, marker: dict[str, Any]) -> None:
        self._held_idle[session_id] = marker

    def pop_held_idle(self, session_id: str) -> dict[str, Any] | None:
        return self._held_idle.pop(session_id, None)

    def get_background_task_controller(self, session_id: str) -> BackgroundTaskController:
        """The session's pause/resume/stop surface for background work (swarmflow runs).

        Session-scoped, not round-scoped: a pause in one round and a resume in
        a later round must observe the same ticket registry, and the leader
        NativeHarness that hosts the runs is rebuilt every round. Lazily
        created; dropped by ``_cleanup_runtime_locals`` only when the team is
        torn down for good (a paused team keeps its tickets).
        """
        controller = self._background_task_controllers.get(session_id)
        if controller is None:
            controller = BackgroundTaskController()
            self._background_task_controllers[session_id] = controller
        return controller

    def find_background_task_controller(
        self, session_id: str
    ) -> BackgroundTaskController | None:
        """The session's controller when one already exists, else None.

        Read-only companion of :meth:`get_background_task_controller`: state
        checks must not lazily seed the registry with an empty controller.
        """
        return self._background_task_controllers.get(session_id)

    def has_swarmflow_runs(self, session_id: str) -> bool:
        """Whether the session's controller still holds active or paused runs.

        A swarmflow background run outlives the leader round: after the round
        ends the stream task and active markers are gone, yet the run keeps
        burning tokens. Lifecycle short-circuits keyed only on the foreground
        round would silently skip these runs, so this is the "background work
        exists" leg of those checks.
        """
        controller = self._background_task_controllers.get(session_id)
        if controller is None:
            return False
        return bool(getattr(controller, "_active", None)) or bool(
            getattr(controller, "_paused", None)
        )

    def is_runtime_active(self, session_id: str) -> bool:
        """Return whether a Runner-owned runtime is active for the session."""
        return session_id in self._active_team_names

    def is_runtime_pending(self, session_id: str) -> bool:
        """Return whether runtime activation is pending for the session."""
        return session_id in self._pending_team_names

    def get_active_team_name(self, session_id: str) -> str | None:
        """Return the active Runner-owned team name for the session."""
        return self._active_team_names.get(session_id)

    def get_runtime_team_snapshot(self) -> dict[str, dict[str, str]]:
        """Return session -> team runtime status for active/pending team runs."""
        snapshot: dict[str, dict[str, str]] = {}
        for sid, team_name in self._active_team_names.items():
            snapshot[sid] = {"team_name": team_name, "state": "active"}
        for sid, team_name in self._pending_team_names.items():
            snapshot.setdefault(sid, {"team_name": team_name, "state": "pending"})
        return snapshot

    def _get_lifecycle_lock(self, session_id: str) -> asyncio.Lock:
        """Return the lock that serializes lifecycle operations for a session."""
        if self._is_distributed_mode(get_config()):
            return self._bootstrap_lock

        lock = self._session_locks.get(session_id)
        if lock is None:
            lock = asyncio.Lock()
            self._session_locks[session_id] = lock
        return lock

    def get_startup_lock(self, session_id: str) -> asyncio.Lock:
        """Serialize startup without blocking lifecycle cleanup or live inputs."""
        lock = self._startup_locks.get(session_id)
        if lock is None:
            lock = asyncio.Lock()
            self._startup_locks[session_id] = lock
        return lock

    def get_monitor(self, session_id: str) -> TeamMonitorHandler | None:
        return self._team_monitors.get(session_id)

    def get_team_evolution_watcher(self, session_id: str) -> asyncio.Task | None:
        return self._team_evolution_watchers.get(session_id)

    def register_team_evolution_watcher(self, session_id: str, task: asyncio.Task) -> None:
        self._team_evolution_watchers[session_id] = task

    def pop_team_evolution_watcher(self, session_id: str) -> asyncio.Task | None:
        return self._team_evolution_watchers.pop(session_id, None)

    def mark_team_evolution_watcher_deferred(self, session_id: str) -> None:
        self._pending_team_evolution_watcher_sessions.add(session_id)

    def consume_team_evolution_watcher_deferred(self, session_id: str) -> bool:
        if session_id not in self._pending_team_evolution_watcher_sessions:
            return False
        self._pending_team_evolution_watcher_sessions.discard(session_id)
        return True

    @staticmethod
    def _is_distributed_mode(config_base: dict[str, Any]) -> bool:
        return is_distributed_mode(config_base)

    @staticmethod
    def _runtime_role(config_base: dict[str, Any]) -> str:
        return runtime_role(config_base)

    @staticmethod
    def _runtime_member_name(config_base: dict[str, Any], team_cfg: dict[str, Any]) -> str | None:
        return runtime_member_name(config_base, team_cfg)

    @staticmethod
    def _normalize_distributed_transport_fields(
        config_base: dict[str, Any],
        team_cfg: dict[str, Any],
    ) -> dict[str, Any]:
        return normalize_distributed_transport_fields(config_base, team_cfg)

    @staticmethod
    def normalize_distributed_transport_fields(
        config_base: dict[str, Any],
        team_cfg: dict[str, Any],
    ) -> dict[str, Any]:
        """Public wrapper for distributed transport normalization."""
        return TeamManager._normalize_distributed_transport_fields(config_base, team_cfg)

    @staticmethod
    def _parse_port(value: Any, default: int, field_name: str) -> int:
        return parse_port(value, default, field_name)

    @staticmethod
    def parse_port(value: Any, default: int, field_name: str) -> int:
        """Public wrapper for validated port parsing."""
        return TeamManager._parse_port(value, default, field_name)

    @staticmethod
    def _normalize_team_identity_fields(team_cfg: dict[str, Any]) -> dict[str, Any]:
        normalized_cfg = copy.deepcopy(team_cfg)
        leader_cfg = normalized_cfg.get("leader", {})
        if isinstance(leader_cfg, dict):
            display_name = str(leader_cfg.get("display_name", "")).strip()
            name = str(leader_cfg.get("name", "")).strip()
            if display_name and not name:
                leader_cfg["name"] = display_name
            elif name and not display_name:
                leader_cfg["display_name"] = name

        members = normalized_cfg.get("predefined_members", [])
        if isinstance(members, list):
            for member in members:
                if not isinstance(member, dict):
                    continue
                display_name = str(member.get("display_name", "")).strip()
                name = str(member.get("name", "")).strip()
                if display_name and not name:
                    member["name"] = display_name
                elif name and not display_name:
                    member["display_name"] = name
        return normalized_cfg

    @staticmethod
    def build_session_scoped_team_name(team_name: str, session_id: str) -> str:
        """构造 session 作用域的 team_name（对外公开 API）。

        供网关等外部模块做 team/session 一致性校验时复用，避免直接访问受保护成员。
        """
        base_name = str(team_name or "").strip() or "team"
        session_suffix = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(session_id or "").strip())
        session_suffix = session_suffix.strip("._-")
        if not session_suffix:
            return base_name
        if base_name.endswith(f"_{session_suffix}"):
            return base_name
        return f"{base_name}_{session_suffix}"

    @staticmethod
    def _apply_session_scoped_team_name(
        spec: TeamAgentSpec,
        *,
        session_id: str,
    ) -> None:
        spec.team_name = TeamManager.build_session_scoped_team_name(
            spec.team_name,
            session_id,
        )

    @staticmethod
    def _resolve_and_compile_team_selection(
        selection: SwarmModelSelection,
    ) -> CompiledModelSelection:
        """Resolve a stable Team selection through the server-side boundary."""
        from jiuwenswarm.common.model_errors import (
            TEAM_MODEL_SELECTION_STALE,
            ModelSelectionError,
        )
        from jiuwenswarm.common.model_selection import ResolvedModelGroup
        from jiuwenswarm.server.runtime.model_compiler_adapter import (
            compile_model_selection,
        )
        from jiuwenswarm.server.runtime.model_routing_registry import (
            ModelSelectionResolver,
        )

        try:
            resolved = ModelSelectionResolver().resolve(
                SwarmModelSelection(
                    type=selection.type,
                    id=selection.id,
                    route_id=selection.route_id,
                )
            )
            # Team routes across the whole group. Groups saved from the UI
            # carry no routing strategy, which would compile to the first
            # route only; default them to ordered failover. A manually
            # selected route keeps compiling to that single model.
            if (
                isinstance(resolved, ResolvedModelGroup)
                and selection.route_id is None
                and not (resolved.routing or {}).get("strategy")
            ):
                resolved = resolved.model_copy(
                    update={"routing": {**(resolved.routing or {}), "strategy": "ordered-failover"}}
                )
            compiled = compile_model_selection(resolved)
        except ModelSelectionError:
            # Stable catalog / permission failures are meaningful to callers.
            raise
        except Exception as exc:
            # Foundation errors also expose a numeric ``code`` attribute, but
            # those values are implementation details rather than Team's
            # stable external contract.
            raise ModelSelectionError(
                TEAM_MODEL_SELECTION_STALE,
                "Team model selection cannot be restored; choose a model again",
                selection_type=selection.type,
            ) from exc

        return compiled

    @staticmethod
    def _default_if_deleted(
        selection: SwarmModelSelection | dict[str, Any],
    ) -> SwarmModelSelection | dict[str, Any]:
        """Replace a persisted reference only when its resource was deleted."""
        from jiuwenswarm.common.model_catalog import ModelCatalog
        from jiuwenswarm.server.runtime.model_routing_registry import (
            ModelExecutionContext, ModelSelectionResolver,
        )

        selected = SwarmModelSelection.model_validate(selection)
        catalog = ModelCatalog()
        if catalog.has_selection(selected):
            return selection
        logger.info("saved Team selection %s:%s was deleted; using current default", selected.type, selected.id)
        return ModelSelectionResolver(catalog).choose(None, ModelExecutionContext())

    @staticmethod
    def _selected_model_name(
        selection: SwarmModelSelection,
        compiled: CompiledModelSelection,
    ) -> str:
        """Return the model name a compiled single-model selection points at."""
        from jiuwenswarm.common.model_errors import (
            MODEL_REQUEST_CONFIG_INVALID,
            TEAM_MODEL_SELECTION_STALE,
            ModelSelectionError,
        )

        if (
            compiled.selected_type != selection.type
            or compiled.selected_id != selection.id
        ):
            raise ModelSelectionError(
                TEAM_MODEL_SELECTION_STALE,
                "model selection does not match compiled selection",
            )
        request = (
            compiled.model_request_config.model_dump(
                exclude_none=True,
                by_alias=True,
            )
            if compiled.model_request_config
            else {}
        )
        name = request.get("model") or request.get("model_name") or ""
        if not name:
            raise ModelSelectionError(
                MODEL_REQUEST_CONFIG_INVALID,
                "compiled model selection has an empty model name",
            )
        return name

    @staticmethod
    def _apply_compiled_team_selection(
        spec_dict: dict[str, Any],
        selection: SwarmModelSelection,
        compiled: CompiledModelSelection,
    ) -> None:
        """Materialize one compiled selection into the Team model pool."""
        from jiuwenswarm.common.model_errors import (
            MODEL_REQUEST_CONFIG_INVALID,
            TEAM_MODEL_SELECTION_STALE,
            ModelSelectionError,
        )

        if (
            compiled.selected_type != selection.type
            or compiled.selected_id != selection.id
        ):
            raise ModelSelectionError(
                TEAM_MODEL_SELECTION_STALE,
                "model selection does not match compiled selection",
            )

        # ``load_team_spec_dict`` normally supplies the leader object, but
        # callers may provide a minimal/template snapshot without one.  Keep
        # model selection authoritative in that case too; Pydantic will fill
        # the remaining LeaderSpec defaults when the spec is validated.
        leader = spec_dict.get("leader")
        if not isinstance(leader, dict):
            leader = {}
            spec_dict["leader"] = leader
        # The compiled selection is the sole authoritative model source for
        # this build. Remove stale convenience router declarations from an
        # older template before TeamAgentSpec validates mutual exclusion.
        spec_dict["model_router"] = None
        spec_dict["model_intelli_router"] = None
        client = compiled.model_client_config
        provider = getattr(client, "client_provider", "")
        provider = getattr(provider, "value", provider)
        if selection.type == "model_group" and str(provider) == "intelli_router":
            spec_dict["model_pool"] = [
                entry.model_dump(exclude_none=True)
                for entry in materialize_model_group(compiled, selection)
            ]
            spec_dict["model_pool_strategy"] = "intelli_router"
            # The compiled selection is authoritative. Clear convenience
            # sources from a legacy template and normalize every predefined
            # member to the sole logical Team entry; physical deployment names
            # stay inside the Foundation router.
            spec_dict["model_router"] = None
            spec_dict["model_intelli_router"] = None
            if isinstance(leader, dict):
                leader["model_name"] = "*"
            predefined_members = spec_dict.get("predefined_members")
            if isinstance(predefined_members, list):
                for member in predefined_members:
                    # External CLI members must keep their physical
                    # deployment hint; the CLI path resolves it through the
                    # IntelliRouter deployment catalog. Ordinary Team
                    # members use the single logical wildcard entry.
                    if (
                        isinstance(member, dict)
                        and member.get("role_type") != "external_cli"
                    ):
                        member["model_name"] = "*"
            return

        client = client.model_dump(exclude_none=True)
        request = (
            compiled.model_request_config.model_dump(
                exclude_none=True,
                by_alias=True,
            )
            if compiled.model_request_config
            else {}
        )
        name = request.get("model") or request.get("model_name") or ""
        if not name:
            raise ModelSelectionError(
                MODEL_REQUEST_CONFIG_INVALID,
                "compiled model selection has an empty model name",
            )
        provider = client.get("client_provider", "")
        provider = getattr(provider, "value", provider)
        spec_dict["model_pool"] = [
            {
                "model_name": name,
                "api_key": client.get("api_key", ""),
                "api_base_url": client.get("api_base", ""),
                "api_provider": str(provider),
                "metadata": {
                    "client": {
                        key: value
                        for key, value in client.items()
                        if key not in {"client_provider", "api_key", "api_base"}
                    },
                    "request": {
                        key: value
                        for key, value in request.items()
                        if key not in {"model", "model_name"}
                    },
                },
            }
        ]
        spec_dict["model_pool_strategy"] = "by_model_name"
        # The stable selection is authoritative over stale template hints.
        if isinstance(leader, dict):
            leader["model_name"] = name

    @staticmethod
    def load_default_team_spec(session_id: str) -> TeamAgentSpec:
        """Load the default Team specification for host organization adapters."""
        return TeamManager._load_team_spec(session_id)

    @staticmethod
    def _load_team_spec(
        session_id: str,
        *,
        requested_model_name: str | None = None,
        login_model_entry: dict[str, Any] | None = None,
        template_id: str | None = None,
        template_snapshot: dict[str, Any] | None = None,
        strict_template: bool = False,
        model_selection: SwarmModelSelection | dict[str, Any] | None = None,
    ) -> TeamAgentSpec:
        config_base = get_config()
        # Keep dependency checks scoped to distributed mode to make the
        # control flow explicit at the call site (local mode bypasses checks).
        if TeamManager._is_distributed_mode(config_base):
            missing = missing_distributed_dependencies(config_base)
            if missing:
                missing_list = ", ".join(missing)
                logger.warning(
                    "[TeamManager][MISSING_DISTRIBUTE_DEPS] missing=%s",
                    missing_list,
                )
                logger.error(
                    "[TeamManager][FALLBACK_TO_LOCAL] "
                    "distributed runtime is not available; downgraded to local mode "
                    "for current process"
                )
                logger.warning(
                    "[TeamManager][ACTION] install via: "
                    "pip install -e \".[distribute]\" or uv sync --extra distribute"
                )
                config_base = fallback_distributed_to_local(config_base)

        selection: SwarmModelSelection | None = None
        if model_selection is not None:
            # Normalize through the swarm DTO so ``route_id`` (a valid
            # group-scope pin) survives; the foundation ``ModelSelection``
            # would silently drop it.
            raw_selection = (
                model_selection
                if isinstance(model_selection, dict)
                else model_selection.model_dump(exclude_none=True)
            )
            selection = SwarmModelSelection.model_validate(
                {
                    key: raw_selection[key]
                    for key in ("type", "id", "route_id")
                    if key in raw_selection
                }
            )
        if selection is not None and selection.type == "model":
            # A single-model selection only names the page-selected model; the
            # pool keeps every configured model below so members can still be
            # assigned any of them. Resolving it also rejects a stale selection.
            requested_model_name = TeamManager._selected_model_name(
                selection,
                TeamManager._resolve_and_compile_team_selection(selection),
            )

        spec_dict = load_team_spec_dict(
            config_base=config_base,
            requested_model_name=requested_model_name,
            login_model_entry=login_model_entry,
            template_id=template_id,
            template_snapshot=template_snapshot,
            strict_template=strict_template,
        )
        spec_dict = TeamManager._normalize_team_identity_fields(spec_dict)
        if TeamManager._is_distributed_mode(config_base):
            spec_dict = TeamManager._normalize_distributed_transport_fields(config_base, spec_dict)

        if selection is not None and selection.type == "model_group":
            compiled = TeamManager._resolve_and_compile_team_selection(selection)
            TeamManager._apply_compiled_team_selection(
                spec_dict,
                selection,
                compiled,
            )
            return TeamAgentSpec.model_validate(spec_dict)

        # Populate the pool from valid configured entries plus the effective
        # page-selected model. The latter may be an in-memory Zen model or a
        # login model, both intentionally absent from config.yaml.
        effective_models = get_effective_team_model_entries(
            config_base,
            requested_model_name=requested_model_name,
            login_model_entry=login_model_entry,
        )
        if effective_models:
            from openjiuwen.agent_teams.schema.team import ModelPoolEntry

            pool_entries: list[dict] = []
            for entry in effective_models:
                mcc = entry.get("model_client_config") or {}
                mco = entry.get("model_config_obj") or {}
                if not mcc.get("model_name"):
                    continue
                # Map the internal ``reasoning_level`` hint to provider-specific
                # params here; leaving it raw would let ``ModelRequestConfig``
                # (extra=allow) forward it to ``AsyncCompletions.create()`` and
                # raise ``unexpected keyword argument 'reasoning_level'``.
                request_config = build_reasoning_model_request_kwargs(
                    model_client_config=mcc,
                    model_config_obj=mco,
                    model_name=mcc["model_name"],
                )
                request_config.pop("model", None)
                pool_entry = ModelPoolEntry(
                    model_name=mcc["model_name"],
                    api_key=mcc.get("api_key", ""),
                    api_base_url=mcc.get("api_base", ""),
                    api_provider=mcc.get("client_provider", ""),
                    metadata={
                        "client": {
                            k: v for k, v in mcc.items()
                            if k not in ("model_name", "api_key", "api_base", "client_provider") and v is not None
                        },
                        # 新声明下方言由 endpoint_profile 表达(client_provider 多数为 OpenAI)。
                        # 同时透传 profile 供下游需要区分 DeepSeek/DashScope 等方言时使用。
                        "endpoint_profile": mcc.get("endpoint_profile", ""),
                        "request": request_config,
                    },
                )
                pool_entries.append(pool_entry.model_dump())

            if pool_entries:
                spec_dict["model_pool"] = pool_entries
                spec_dict["model_pool_strategy"] = "by_model_name"

        return TeamAgentSpec.model_validate(spec_dict)

    @staticmethod
    def _lookup_bound_team_identity(session_id: str) -> tuple[str | None, str | None, dict[str, Any] | None]:
        metadata = get_session_metadata(session_id, cache_bust=True)
        team_name = str(metadata.get("team_name") or "").strip()
        template_id = str(metadata.get("team_template_id") or "").strip()
        template_snapshot: dict[str, Any] | None = None
        if team_name:
            from jiuwenswarm.server.runtime.team_binding_store import get_team_binding_store
            from jiuwenswarm.server.runtime.team_entity_store import ensure_team_entity, ensure_team_entity_for_binding

            binding = get_team_binding_store().get(team_name)
            if binding is not None:
                if not template_id:
                    template_id = binding.template_id
                entity = ensure_team_entity_for_binding(binding, config_base=get_config())
            else:
                legacy_snapshot = (
                    copy.deepcopy(metadata.get("team_template_snapshot"))
                    if isinstance(metadata.get("team_template_snapshot"), dict)
                    else None
                )
                entity = ensure_team_entity(
                    team_name=team_name,
                    template_id=template_id,
                    template_snapshot=legacy_snapshot,
                    config_base=get_config(),
                )
            if entity is not None:
                template_id = entity.template_id
                template_snapshot = copy.deepcopy(entity.template_snapshot)
        return team_name or None, template_id or None, template_snapshot

    def _load_session_team_spec(
        self,
        session_id: str,
        *,
        requested_model_name: str | None = None,
        login_model_entry: dict[str, Any] | None = None,
        model_selection: SwarmModelSelection | dict[str, Any] | None = None,
    ) -> tuple[TeamAgentSpec, bool]:
        team_name, template_id, template_snapshot = self._lookup_bound_team_identity(session_id)
        load_kwargs: dict[str, Any] = {}
        if requested_model_name is not None:
            load_kwargs["requested_model_name"] = requested_model_name
        if login_model_entry is not None:
            load_kwargs["login_model_entry"] = login_model_entry
        if template_id is not None:
            load_kwargs["template_id"] = template_id
            load_kwargs["strict_template"] = template_snapshot is None
        if template_snapshot is not None:
            load_kwargs["template_snapshot"] = template_snapshot
        # A persisted selection is a business reference, not a runtime
        # snapshot.  Re-resolve it on every cold build so config/credentials
        # and permissions are current.
        restored_selection = model_selection is None
        if restored_selection:
            metadata = get_session_metadata(session_id, cache_bust=True)
            # Team bindings own the long-lived business selection.  Keep the
            # session field as a read-only compatibility fallback for legacy
            # sessions/checkpoints that predate Team-level persistence.
            team_name = str(metadata.get("team_name") or "").strip()
            if team_name:
                try:
                    from jiuwenswarm.server.runtime.team_binding_store import get_team_binding_store
                    stored_team = get_team_binding_store().get_team_selection(team_name)
                except Exception:
                    stored_team = None
                if isinstance(stored_team, dict) and stored_team.get("type") and stored_team.get("id"):
                    model_selection = stored_team
            if model_selection is None:
                from jiuwenswarm.server.runtime.session.model_selection_store import (
                    get_session_model_selection,
                )

                try:
                    stored = get_session_model_selection(session_id)
                except ValueError:
                    stored = None
                if stored is not None:
                    model_selection = stored.model_dump(exclude_none=True)

        if model_selection is not None:
            if restored_selection:
                model_selection = self._default_if_deleted(model_selection)
            load_kwargs["model_selection"] = model_selection
        spec = self._load_team_spec(session_id, **load_kwargs)
        if team_name:
            spec.team_name = team_name
            return spec, True
        return spec, False


    async def get_swarm_enriched_team_spec(
        self,
        session_id: str,
        *,
        mode: str,
        project_dir: str | None = None,
        trusted_dirs: list[str] | None = None,
        request_id: str | None = None,
        user_id: str | None = None,
        channel_id: str | None = None,
        request_metadata: dict[str, Any] | None = None,
        requested_model_name: str | None = None,
        login_model_entry: dict[str, Any] | None = None,
        agent_group_name: str | None = None,
        swarmflow_config: dict | None = None,
        dispatch_mode: str | None = None,
        bootstrap_mode: str | None = None,
        model_selection: SwarmModelSelection | dict[str, Any] | None = None,
    ) -> TeamAgentSpec:
        """Build a team spec via provider-based assembly (no parent DeepAgent).

        Sources every member capability from the shared config source through
        ``enrich_team_spec_for_swarm`` instead of inheriting from a pre-built
        single agent, so creating a team never requires constructing one first.

        Args:
            session_id: Active session id.
            mode: Request mode (e.g. "team").
            project_dir: Resolved project directory, if any.
            trusted_dirs: Directories the client declared as trusted for this request.
            request_id: Originating request id, if any.
            channel_id: Raw channel id from the request, if any.
            request_metadata: Request metadata mapping.
            agent_group_name: Optional AgentGroup package bound to the session.
            login_model_entry: Model entry for a page-selected login model,
                built from the request's forwarded credentials (placeholder
                api_key; the real token is swapped in per HTTP request).
            dispatch_mode: Session-level task dispatch mode (``"autonomous"`` /
                ``"scheduled"``); None keeps the team config's ``dispatch_mode``.
                Task verification only applies to scheduled dispatch, so it is
                switched off when the session picks autonomous dispatch.
            bootstrap_mode: Session-level team bootstrap mode (``"leader"`` /
                ``"framework"``); None keeps the team config's ``bootstrap_mode``.
                ``"framework"`` requires the effective dispatch mode to be
                ``"scheduled"`` and raises ``ValueError`` otherwise — the
                combination is rejected here, at the request boundary, rather
                than surfacing as a spec build failure later.

        Returns:
            The enriched ``TeamAgentSpec`` ready to build (``build_context`` set;
            assembly is fully declarative, no imperative post-processing).
        """
        from jiuwenswarm.agents.swarm import enrich_team_spec_for_swarm

        config_base = get_config()
        self._team_evolution_enabled[session_id] = get_skill_evolution_enabled(config_base)
        await self._ensure_postgresql_for_leader(config_base)
        spec, has_binding = self._load_session_team_spec(
            session_id,
            requested_model_name=requested_model_name,
            login_model_entry=login_model_entry,
            model_selection=model_selection,
        )
        if not has_binding:
            self._apply_session_scoped_team_name(spec, session_id=session_id)
        self.apply_team_plan_mode(spec, request_metadata=request_metadata)
        enrich_team_spec_for_swarm(
            spec,
            session_id=session_id,
            mode=mode,
            project_dir=project_dir,
            trusted_dirs=trusted_dirs,
            request_id=request_id,
            user_id=user_id,
            channel_id=channel_id,
            request_metadata=request_metadata,
            agent_group_name=agent_group_name,
        )
        if swarmflow_config is not None:
            spec.enable_swarmflow = bool(swarmflow_config.get("enable_swarmflow", False))
            budget = swarmflow_config.get("swarmflow_budget")
            if isinstance(budget, int) and budget > 0:
                spec.swarmflow_budget = budget
            else:
                spec.swarmflow_budget = None
            # Session-level worktree gate: True arms the manager, False withholds
            # it, None (not specified) keeps the team config's worktree section.
            worktree_flag = swarmflow_config.get("swarmflow_worktree")
            if worktree_flag is True:
                if spec.worktree is None:
                    from openjiuwen.harness.tools.worktree import WorktreeConfig

                    spec.worktree = WorktreeConfig(enabled=True)
                elif not spec.worktree.enabled:
                    spec.worktree = spec.worktree.model_copy(update={"enabled": True})
            elif worktree_flag is False:
                spec.worktree = None
        if dispatch_mode is not None:
            spec.dispatch_mode = dispatch_mode
            if dispatch_mode != "scheduled":
                spec.enable_task_verification = False
        if bootstrap_mode is not None:
            spec.bootstrap_mode = bootstrap_mode
        if spec.bootstrap_mode == "framework" and spec.dispatch_mode != "scheduled":
            raise ValueError(
                "team_bootstrap_mode='framework' requires scheduled dispatch "
                f"(effective dispatch_mode={spec.dispatch_mode!r}); "
                "turn on scheduled dispatch for this session or drop the bootstrap mode"
            )
        return spec

    @staticmethod
    def apply_team_plan_mode(
        spec: TeamAgentSpec,
        *,
        request_metadata: dict[str, Any] | None,
    ) -> None:
        from jiuwenswarm.common.mode_matrix import is_team_plan_mode

        mode = (request_metadata or {}).get("mode")
        if is_team_plan_mode(mode):
            try:
                spec.enable_team_plan = True
            except (AttributeError, ValueError):
                object.__setattr__(spec, "enable_team_plan", True)

    async def prepare_runtime_activation(self, session_id: str, team_name: str) -> None:
        self._assert_session_not_deleting(session_id)
        if self._is_distributed_mode(get_config()):
            async with self._distributed_switch_lock:
                await self._wait_same_session_runner_runtime_released(session_id)
                await self._stop_stale_distributed_sessions(
                    session_id,
                    reason="switch runtime: ",
                )
                self._pending_team_names[session_id] = team_name
            return

        self._pending_team_names[session_id] = team_name

    async def _wait_same_session_runner_runtime_released(
        self,
        session_id: str,
        *,
        timeout_sec: float = 5.0,
        poll_interval_sec: float = 0.1,
    ) -> None:
        """Before same-session rebuild, wait old Runner runtime/messager to stop."""
        if not self._is_distributed_mode(get_config()):
            return
        if not self.is_runtime_active(session_id):
            return
        if self.has_stream_task(session_id):
            return

        # Best-effort eager stop for the cached Runner-owned team agent transport.
        await self._stop_runner_team_agent_transport(session_id)

        team_name = self._resolve_session_team_name(session_id)
        if not team_name:
            return

        from openjiuwen.core.runner.runner import GLOBAL_RUNNER

        runtime_mgr = _runner_team_runtime_manager(GLOBAL_RUNNER)
        deadline = time.monotonic() + max(0.0, timeout_sec)
        while time.monotonic() < deadline:
            active_team = await runtime_mgr.pool.get(team_name)
            if active_team is None:
                logger.info(
                    "[TeamManager] same-session runtime released before rebuild: "
                    "session_id=%s team_name=%s",
                    session_id,
                    team_name,
                )
                return
            await asyncio.sleep(max(0.02, poll_interval_sec))

        logger.warning(
            "[TeamManager] same-session runtime still active before rebuild timeout: "
            "session_id=%s team_name=%s timeout=%.1fs",
            session_id,
            team_name,
            timeout_sec,
        )

    async def prepare_session_switch(
        self,
        target_session_id: str,
        reason: str = "",
        previous_session_id: str | None = None,
    ) -> None:
        """Enforce the distributed runtime's single-session switch policy.

        Local Runner-owned teams use session-scoped team names and may stay
        active concurrently. Distributed deployments retain the existing
        single-session behavior because their bootstrap resources are scoped to
        one active session per channel.
        """
        distributed = self._is_distributed_mode(get_config())
        normalized_previous = str(previous_session_id or "").strip()
        if normalized_previous and normalized_previous != target_session_id:
            # Product foreground/task facts own KVC offload.  A navigation
            # event must not offload a Team that is still running.
            await self.stop_paused_session_runtime(
                normalized_previous,
                reason=f"{reason}session-switch: ",
                offload=False,
                preserve_organization=not distributed,
            )

        if not distributed:
            logger.info(
                "[TeamManager] %sprepare_session_switch skipped for local runtime target=%s",
                reason,
                target_session_id,
            )
            return

        async with self._distributed_switch_lock:
            await self._stop_stale_distributed_sessions(
                target_session_id,
                reason=reason,
            )

    def set_session_inactive_reporter(
        self,
        reporter: Callable[[str], Awaitable[None]] | None,
    ) -> None:
        """Inject the Runtime-owned, KVC-neutral inactivity event sink."""
        self._session_inactive_reporter = reporter

    async def _report_session_inactive(self, session_id: str) -> None:
        reporter = self._session_inactive_reporter
        if reporter is not None:
            await reporter(session_id)

    async def _stop_stale_distributed_sessions(
        self,
        target_session_id: str,
        *,
        reason: str,
    ) -> None:
        """Stop active or pending distributed sessions except the target."""
        stale_sessions = [
            session_id
            for session_id in self._active_team_names
            if session_id != target_session_id
        ]
        stale_sessions.extend(
            session_id
            for session_id in self._pending_team_names
            if session_id != target_session_id
        )
        logger.info(
            "[TeamManager] %sprepare_session_switch target=%s active=%s pending=%s stale=%s",
            reason,
            target_session_id,
            list(self._active_team_names),
            list(self._pending_team_names),
            list(dict.fromkeys(stale_sessions)),
        )

        for stale_session_id in dict.fromkeys(stale_sessions):
            await self.stop_session_runtime(
                stale_session_id,
                reason=reason,
            )

    def commit_runtime_ready(self, session_id: str, team_name: str) -> None:
        self._active_team_names[session_id] = team_name
        self._pending_team_names.pop(session_id, None)
        self._initialized_sessions.add(session_id)
        logger.info(
            "[TeamManager] commit_runtime_ready session_id=%s team_name=%s active=%s pending=%s",
            session_id,
            team_name,
            list(self._active_team_names),
            list(self._pending_team_names),
        )

    def clear_pending_runtime(self, session_id: str) -> None:
        self._pending_team_names.pop(session_id, None)

    def clear_active_runtime(self, session_id: str) -> None:
        removed = self._active_team_names.pop(session_id, None)
        if removed is not None:
            logger.info(
                "[TeamManager] clear_active_runtime: session_id=%s team_name=%s remaining_active=%s",
                session_id, removed, list(self._active_team_names),
            )

    def _lookup_session_team_name(self, session_id: str) -> str | None:
        active_team_name = self._active_team_names.get(session_id)
        if active_team_name:
            return active_team_name
        pending_team_name = self._pending_team_names.get(session_id)
        if pending_team_name:
            return pending_team_name

        metadata = get_session_metadata(session_id)
        team_name = str(metadata.get("team_name") or "").strip()
        return team_name or None

    def _resolve_session_team_name(self, session_id: str) -> str | None:
        team_name = self._lookup_session_team_name(session_id)
        if team_name:
            return team_name

        logger.warning(
            "[TeamManager] failed to resolve team_name from active/pending/metadata: session_id=%s",
            session_id,
        )
        return None

    async def _resolve_resumable_runner_entry(self, session_id: str) -> tuple[str, Any] | None:
        """Return a same-session paused/running Runner pool entry when resumable."""
        team_name = self._lookup_session_team_name(session_id)
        if not team_name:
            return None

        from openjiuwen.core.runner.runner import GLOBAL_RUNNER

        runtime_mgr = _runner_team_runtime_manager(GLOBAL_RUNNER)
        entry = await runtime_mgr.pool.get(team_name)
        if entry is None or getattr(entry, "current_session_id", None) != session_id:
            return None
        # Trust the Runner pool over claw-local active/pending markers here.
        # The local markers can be stale after a team.plan round pauses on
        # exit_plan_mode, but the pool still owns the resumable runtime.
        if getattr(entry, "state", None) not in {RuntimeState.PAUSED, RuntimeState.RUNNING}:
            return None
        return team_name, entry

    async def has_resumable_runtime(self, session_id: str) -> bool:
        return await self._resolve_resumable_runner_entry(session_id) is not None

    async def session_has_runtime(self, session_id: str) -> bool:
        return (
            self.is_runtime_active(session_id)
            or self.is_runtime_pending(session_id)
            or self.has_stream_task(session_id)
            or await self.has_resumable_runtime(session_id)
        )

    def _restore_active_runtime(self, session_id: str, team_name: str) -> None:
        self._active_team_names[session_id] = team_name
        self._pending_team_names.pop(session_id, None)
        logger.info(
            "[TeamManager] restored resumable runtime: session_id=%s team_name=%s active=%s pending=%s",
            session_id,
            team_name,
            list(self._active_team_names),
            list(self._pending_team_names),
        )

    async def restore_resumable_runtime(self, session_id: str) -> bool:
        resolved = await self._resolve_resumable_runner_entry(session_id)
        if resolved is None:
            return False
        team_name, _entry = resolved
        self._restore_active_runtime(session_id, team_name)
        return True

    async def wait_for_resumable_runtime(
        self,
        session_id: str,
        *,
        timeout_sec: float = 1.0,
        poll_interval_sec: float = 0.05,
    ) -> bool:
        """Best-effort wait for a paused/running Runner pool entry to become resumable."""
        if self.is_runtime_active(session_id):
            return True
        if await self.restore_resumable_runtime(session_id):
            return True

        deadline = time.monotonic() + max(0.0, timeout_sec)
        sleep_sec = max(0.01, poll_interval_sec)
        while time.monotonic() < deadline:
            await asyncio.sleep(sleep_sec)
            if await self.restore_resumable_runtime(session_id):
                logger.info(
                    "[TeamManager] recovered resumable runtime after wait: session_id=%s",
                    session_id,
                )
                return True
        return self.is_runtime_active(session_id)

    @staticmethod
    def _resolve_delete_session_team_name(session_id: str) -> str | None:
        metadata = get_session_metadata(session_id)
        team_name = str(metadata.get("team_name") or "").strip()
        if team_name:
            return team_name

        logger.warning(
            "[TeamManager] failed to resolve delete team_name from metadata: session_id=%s",
            session_id,
        )
        return None


    @staticmethod
    def _is_postgresql_storage(team_cfg: dict[str, Any]) -> bool:
        return is_postgresql_storage(team_cfg)

    @staticmethod
    def _extract_pg_endpoint(team_cfg: dict[str, Any]) -> tuple[str, int]:
        return extract_pg_endpoint(team_cfg)

    @staticmethod
    async def _run_command(*args: str) -> tuple[int, str]:
        return await run_command(*args, subprocess_timeout_sec=_SUBPROCESS_TIMEOUT_SEC)

    async def _is_pg_available(self, host: str, port: int) -> bool:
        return await is_pg_available(host, port, subprocess_timeout_sec=_SUBPROCESS_TIMEOUT_SEC)

    async def _try_start_pg_cluster(self) -> bool:
        return await try_start_pg_cluster(subprocess_timeout_sec=_SUBPROCESS_TIMEOUT_SEC)

    async def _ensure_postgresql_for_leader(self, config_base: dict[str, Any]) -> None:
        await ensure_postgresql_for_leader(
            config_base,
            subprocess_timeout_sec=_SUBPROCESS_TIMEOUT_SEC,
            post_start_ready_max_sec=_PG_POST_START_READY_MAX_SEC,
            post_start_ready_init_sleep=_PG_POST_START_READY_INIT_SLEEP,
            post_start_ready_max_sleep=_PG_POST_START_READY_MAX_SLEEP,
            post_start_ready_backoff=_PG_POST_START_READY_BACKOFF,
            post_start_log_every_sec=_PG_POST_START_LOG_EVERY_SEC,
        )

    async def create_team(
        self,
        session_id: str,
        deep_agent: DeepAgent,
        request_id: str | None = None,
        channel_id: str | None = None,
        request_metadata: dict[str, Any] | None = None,
    ) -> TeamAgent:
        """Build an auxiliary TeamAgent for distributed teammate bootstrap.

        Local leader requests are built and owned by Runner's TeamRuntimePool;
        they must not use this cache.
        """
        config_base = get_config()
        await self._ensure_postgresql_for_leader(config_base)
        logger.info("[TeamManager] building TeamAgentSpec: session_id=%s", session_id)
        spec, has_binding = self._load_session_team_spec(session_id)
        if not has_binding:
            self._apply_session_scoped_team_name(
                spec,
                session_id=session_id,
            )

        resolved_mode = str((request_metadata or {}).get("mode") or "").strip()
        # Provider-based assembly: source every member capability from the shared
        # config source, no pre-built parent DeepAgent / customizer. Mirrors
        # get_swarm_enriched_team_spec so a team rebuilt here (e.g. the distributed
        # teammate's auxiliary leader) carries provider declarations plus the
        # serializable build_context_seed.
        from jiuwenswarm.agents.swarm import enrich_team_spec_for_swarm

        self.apply_team_plan_mode(spec, request_metadata=request_metadata)
        enrich_team_spec_for_swarm(
            spec,
            session_id=session_id,
            mode=resolved_mode,
            project_dir=(request_metadata or {}).get("project_dir"),
            request_id=request_id,
            channel_id=channel_id,
            request_metadata=request_metadata,
            agent_group_name=str(
                (request_metadata or {}).get("agent_group_name") or ""
            ).strip()
            or None,
        )

        logger.info("[TeamManager] TeamAgentSpec ready: team_name=%s", spec.team_name)

        token = set_session_id(session_id)
        try:
            logger.info("[TeamManager] creating TeamAgent from spec")
            team_agent = spec.build()
            team_agent.channel_id = channel_id  # 记录 channel，供 _destroy_other_sessions 按 channel 隔离
            self._team_agents[session_id] = team_agent
            # The team-level Skill visibility document is seeded by
            # ``TeamWorkspaceManager.initialize`` — the single writer for team
            # scope — when the team workspace comes up. Nothing to do here.

            if self._is_distributed_mode(config_base):
                try:
                    from jiuwenswarm.agents.harness.team.remote_member_bootstrap import (
                        attach_build_team_post_tool_registration_hook,
                        attach_clean_team_distributed_teardown_wrapper,
                        attach_distributed_local_spawn_guard,
                        attach_remote_bootstrap_ack_listener,
                        attach_shutdown_member_remote_cleanup_wrapper,
                    )

                    attach_distributed_local_spawn_guard(
                        team_agent,
                        session_id=session_id,
                        channel_id=channel_id,
                    )
                    attach_build_team_post_tool_registration_hook(
                        team_agent,
                        session_id=session_id,
                        channel_id=channel_id,
                    )
                    attach_shutdown_member_remote_cleanup_wrapper(
                        team_agent,
                        session_id=session_id,
                        channel_id=channel_id,
                    )
                    attach_clean_team_distributed_teardown_wrapper(
                        team_agent,
                        session_id=session_id,
                        channel_id=channel_id,
                    )
                    attach_remote_bootstrap_ack_listener(
                        team_agent,
                        session_id=session_id,
                        channel_id=channel_id,
                    )
                except Exception as exc:
                    logger.warning(
                        "[TeamManager] remote_member_bootstrap wrapper attach failed: %s",
                        exc,
                    )
            logger.info(
                "[TeamManager] Team created: session_id=%s, team_name=%s",
                session_id,
                spec.team_name,
            )
            return team_agent
        finally:
            reset_session_id(token)

    async def get_or_create_team(
        self,
        session_id: str,
        deep_agent: DeepAgent,
        request_id: str | None = None,
        channel_id: str | None = None,
        request_metadata: dict[str, Any] | None = None,
    ) -> TeamAgent:
        """Return the distributed bootstrap TeamAgent for a session.

        This cache is only used by remote member bootstrap on distributed
        teammate processes. Distributed channels intentionally retain a single
        cached session and destroy the previous auxiliary TeamAgent on switch.
        """
        async with self._bootstrap_lock:
            team_agent = self._team_agents.get(session_id)
            if team_agent is not None:
                return team_agent

            await self._destroy_other_sessions(session_id, channel_id)
            return await self.create_team(
                session_id,
                deep_agent,
                request_id,
                channel_id,
                request_metadata,
            )

    async def interact(
        self,
        session_id: str,
        user_input: Any,
        *,
        run_context: object | None = None,
    ) -> tuple[bool, str | None]:
        restored_this_call = False
        try:
            if not self.is_runtime_active(session_id):
                restored = await self.wait_for_resumable_runtime(session_id)
                if restored:
                    restored_this_call = True
                    logger.info(
                        "[TeamManager] interact restored paused runtime before delivery: session_id=%s",
                        session_id,
                    )

            team_name = self.get_active_team_name(session_id)
            if not team_name:
                logger.warning(
                    "[TeamManager] interact ignored for non-active team session: "
                    "session_id=%s active_sessions=%s reason=not_active",
                    session_id,
                    list(self._active_team_names),
                )
                return False, "not_active"

            # Last stop before the message enters the team runner interact path.
            server_logger.info(
                "[AgentServer] team message entering runner interact: session_id=%s team=%s payload=%s",
                session_id,
                team_name,
                _safe_payload_preview(user_input),
            )
            interact_kwargs: dict[str, Any] = {
                "team_name": team_name,
                "session_id": session_id,
            }
            if run_context is not None:
                interact_kwargs["run_context"] = run_context
            result = await Runner.interact_agent_team(
                user_input,
                **interact_kwargs,
            )
            if not result:
                reason = getattr(result, "reason", None) or "runner_failed"
                logger.warning(
                    "[TeamManager] interact failed against runner runtime: session_id=%s team=%s reason=%s",
                    session_id,
                    team_name,
                    reason,
                )
                if restored_this_call and reason == "gate_closed":
                    # The restored bookkeeping does not describe a usable
                    # runtime (the input gate is closed while the pool entry
                    # still reads RUNNING/PAUSED). Roll it back so follow-up
                    # boundary retries can observe a stopped Session and
                    # degrade to a cold start instead of looping on
                    # gate_closed until the timeout, and so the Session stays
                    # deletable (no half-restored active marker).
                    self._active_team_names.pop(session_id, None)
                    logger.info(
                        "[TeamManager] rolled back restored runtime after rejected interact: "
                        "session_id=%s team=%s reason=%s",
                        session_id,
                        team_name,
                        reason,
                    )
                return False, reason
            return True, None
        except Exception as exc:
            logger.error("[TeamManager] interact failed: session_id=%s, error=%s", session_id, exc)
            return False, "exception"

    # TeamSkillEvolutionRail accessors.

    def get_team_skill_rail(self, session_id: str) -> Any | None:
        return self._team_skill_rails.get(session_id)

    def get_team_skill_create_rail(self, session_id: str) -> Any | None:
        return self._team_skill_create_rails.get(session_id)

    def find_team_skill_rail_for_request(self, request_id: str) -> Any | None:
        """Find the TeamSkillEvolutionRail that owns a pending approval with this request_id."""
        for rail in self._team_skill_rails.values():
            owns_request = getattr(rail, "owns_approval_request", None)
            if callable(owns_request) and owns_request(request_id):
                return rail
            if request_id in getattr(rail, "_pending_approval_snapshots", {}):
                return rail
            if request_id in getattr(rail, "_pending_governance", {}):
                return rail
        return None

    async def drain_team_skill_events(self, session_id: str) -> list[dict]:
        """Drain buffered approval events from this session's TeamSkillEvolutionRail."""
        rail = self._team_skill_rails.get(session_id)
        if rail is None:
            return []
        return await rail.drain_pending_approval_events()

    def register_team_skill_rail(self, session_id: str, rail: Any) -> None:
        """Register a TeamSkillEvolutionRail instance for the given session."""
        self._team_skill_rails[session_id] = rail

    def register_team_member_skill_evolution_rail(self, session_id: str, rail: Any) -> None:
        """Register a member SkillEvolutionRail instance for hot config updates."""
        rails = self._team_member_skill_evolution_rails.setdefault(session_id, [])
        if rail not in rails:
            rails.append(rail)

    def register_team_skill_create_rail(self, session_id: str, rail: Any) -> None:
        """Register a TeamSkillCreateRail instance for hot config updates."""
        self._team_skill_create_rails[session_id] = rail

    def register_team_rail_context(self, session_id: str, context: TeamRailMountContext) -> None:
        """Register session context needed to rebuild missing team rails."""
        if getattr(context.member_info, "role", None) == "leader":
            self._team_rail_contexts[session_id] = context

    def register_team_member_rail_context(
        self, session_id: str, context: TeamRailMountContext
    ) -> None:
        """Remember a teammate mount context for evolution hot re-enable."""
        contexts = self._team_member_rail_contexts.setdefault(session_id, [])
        for existing in contexts:
            if existing.agent is context.agent:
                return
        contexts.append(context)

    def get_team_rail_context(self, session_id: str) -> TeamRailMountContext | None:
        """Return the stored leader rail mount context for a session."""
        return self._team_rail_contexts.get(session_id)

    def get_team_evolution_enabled(self, session_id: str) -> bool | None:
        """Return the cached canonical evolution switch for a session."""
        return self._team_evolution_enabled.get(session_id)

    def register_team_live_rail(self, session_id: str, agent: Any, rail: Any) -> None:
        """Remember a live rail owner so hot reload can unregister mounted rails."""
        rails = self._team_live_rails.setdefault(session_id, [])
        entry = (agent, rail)
        if entry not in rails:
            rails.append(entry)

    async def reload_team_skill_views(self, session_id: str | None = None) -> int:
        """Re-scan the shared Skill library for live team members.

        Skills live in exactly one physical library and each member is narrowed
        by its ``skills-visibility.json`` document, so a library or metadata
        change needs no fan-out: the only stale thing is each running member's
        in-memory Skill rail. ``SkillUseRail`` would notice on its own at the
        next model call through its snapshot signature; reloading here makes the
        change land immediately instead.

        Only members tracked as live rail owners are reachable, which today
        means members that mounted an evolution rail. Members without one still
        pick the change up through the snapshot signature.

        Args:
            session_id: Restrict the reload to one session; ``None`` reloads
                every tracked session.

        Returns:
            Number of Skill rails reloaded across the visited agents.
        """
        from jiuwenswarm.agents.harness.team.rails.team_skill_library_reload_rail import (
            reload_agent_skill_views,
        )

        if session_id is None:
            sessions = list(self._team_live_rails)
        else:
            sessions = [session_id]

        visited: set[int] = set()
        reloaded = 0
        for current_session in sessions:
            for agent, _rail in list(self._team_live_rails.get(current_session, [])):
                if agent is None or id(agent) in visited:
                    continue
                visited.add(id(agent))
                reloaded += await reload_agent_skill_views(agent)
        logger.info(
            "[TeamManager] reloaded team skill views: session_id=%s agents=%d rails=%d",
            session_id,
            len(visited),
            reloaded,
        )
        return reloaded

    def _clear_team_rail_registries(self, session_id: str) -> None:
        self._team_skill_rails.pop(session_id, None)
        self._team_member_skill_evolution_rails.pop(session_id, None)
        self._team_skill_create_rails.pop(session_id, None)
        self._team_rail_contexts.pop(session_id, None)
        self._team_evolution_enabled.pop(session_id, None)
        self._team_member_rail_contexts.pop(session_id, None)
        self._team_live_rails.pop(session_id, None)

    def _clear_terminal_session_markers(self, session_id: str) -> None:
        """Release process-wide markers only for non-resumable teardown."""
        self.clear_session_initialized(session_id)
        self.pop_cron_completion(session_id)
        self._pending_team_evolution_watcher_sessions.discard(session_id)

    def _assert_session_not_deleting(self, session_id: str) -> None:
        """Reject execution admission after permanent-delete quiesce starts."""
        if session_id in self._terminal_delete_sessions:
            raise RuntimeError(f"session is being permanently deleted: {session_id}")

    async def _cancel_team_evolution_watcher(self, session_id: str) -> None:
        watcher_task = self._team_evolution_watchers.pop(session_id, None)
        if watcher_task and not watcher_task.done():
            watcher_task.cancel()
            try:
                await watcher_task
            except asyncio.CancelledError:
                pass
            except Exception as exc:
                logger.warning(
                    "[TeamManager] evolution watcher stop failed: session_id=%s error=%s",
                    session_id,
                    exc,
                )

    async def _unregister_live_rail(self, session_id: str, rail: Any) -> None:
        live_rails = self._team_live_rails.get(session_id, [])
        remaining: list[tuple[Any, Any]] = []
        for agent, live_rail in live_rails:
            if live_rail is not rail:
                remaining.append((agent, live_rail))
                continue
            unregister = getattr(agent, "unregister_rail", None)
            if callable(unregister):
                try:
                    result = unregister(live_rail)
                    if hasattr(result, "__await__"):
                        await result
                except Exception as exc:
                    logger.warning(
                        "[TeamManager] live rail unregister failed: session_id=%s rail=%s error=%s",
                        session_id,
                        type(live_rail).__name__,
                        exc,
                    )
        if remaining:
            self._team_live_rails[session_id] = remaining
        else:
            self._team_live_rails.pop(session_id, None)

    async def _unregister_live_rails(self, session_id: str) -> None:
        """Unmount every evolution rail while preserving registration order."""
        for _agent, rail in list(self._team_live_rails.get(session_id, [])):
            await self._unregister_live_rail(session_id, rail)

    def _clear_team_evolution_rails(self, session_id: str) -> None:
        """Forget mounted evolution rails while retaining rebuild contexts."""
        self._team_skill_rails.pop(session_id, None)
        self._team_skill_create_rails.pop(session_id, None)
        self._team_member_skill_evolution_rails.pop(session_id, None)

    def _has_live_rail(self, session_id: str, agent: Any, rail_type: type) -> bool:
        """Return whether *agent* already owns a rail of *rail_type*."""
        return any(
            owner is agent and isinstance(rail, rail_type)
            for owner, rail in self._team_live_rails.get(session_id, [])
        )

    def _build_and_mount_member_rails_for_context(
        self,
        session_id: str,
        context: TeamRailMountContext,
        *,
        mount_team_skill_rail: bool,
        mount_team_skill_create_rail: bool,
        mount_skill_evolution_rail: bool,
    ) -> tuple[Any | None, Any | None]:
        """Rebuild team rails for a session using the stored mount context."""
        latest_config = get_config()
        context.team_workspace.config = latest_config
        member_rails = build_member_rails(
            member_info=context.member_info,
            runtime=context.runtime,
            team_workspace=context.team_workspace,
        )
        team_skill_rail: Any | None = None
        team_skill_create_rail: Any | None = None
        for rail in member_rails:
            if isinstance(rail, TeamSkillEvolutionRail) and mount_team_skill_rail:
                context.agent.add_rail(rail)
                self.register_team_live_rail(session_id, context.agent, rail)
                team_skill_rail = rail
            elif isinstance(rail, EvolutionInterruptRail) and (
                mount_team_skill_rail or mount_skill_evolution_rail
            ):
                context.agent.add_rail(rail)
                self.register_team_live_rail(session_id, context.agent, rail)
            elif isinstance(rail, SkillEvolutionRail) and mount_skill_evolution_rail:
                context.agent.add_rail(rail)
                self.register_team_live_rail(session_id, context.agent, rail)
                self.register_team_member_skill_evolution_rail(session_id, rail)
            elif isinstance(rail, TeamSkillCreateRail) and mount_team_skill_create_rail:
                context.agent.add_rail(rail)
                self.register_team_live_rail(session_id, context.agent, rail)
                team_skill_create_rail = rail

        if team_skill_rail is not None:
            self.register_team_skill_rail(session_id, team_skill_rail)
        if team_skill_create_rail is not None:
            self.register_team_skill_create_rail(session_id, team_skill_create_rail)
        return team_skill_rail, team_skill_create_rail

    async def update_evolution_config(self, config: dict[str, Any] | None) -> None:
        """Hot-update team evolution rails for existing team runtimes."""
        enabled = get_skill_evolution_enabled(config)
        auto_save = get_evolution_auto_save_enabled(config)
        known_sessions = set(self._team_rail_contexts)
        known_sessions.update(self._team_member_rail_contexts)
        known_sessions.update(self._team_skill_rails)
        known_sessions.update(self._team_skill_create_rails)
        known_sessions.update(self._team_member_skill_evolution_rails)
        for session_id in known_sessions:
            self._team_evolution_enabled[session_id] = enabled

        if not enabled:
            # Disable is a full capability teardown.  Cancel the watcher before
            # unregistering rails so no pending approval can be emitted after
            # the switch has been persisted.
            for session_id in known_sessions:
                await self._cancel_team_evolution_watcher(session_id)
                # Every rail mounted by the evolution providers is recorded
                # with its owning agent.  Unregister the complete snapshot so
                # approval interrupts are removed together with their parent
                # evolution/create rails; relying on find_rails_by_type here
                # is unsafe because host implementations need not accept a
                # tuple of types.  Mount contexts remain for a later enable.
                await self._unregister_live_rails(session_id)
                self._clear_team_evolution_rails(session_id)
            return

        # Existing rails receive the fixed role trigger policy and canonical
        # auto-save value; neither role policy is user-configurable.
        for rail in self._team_skill_rails.values():
            try:
                rail.signal_trigger = False
                rail.review_trigger = True
                rail.auto_save = auto_save
            except Exception as exc:
                logger.debug("[TeamManager] team auto_save update failed: %s", exc)
        for rails in self._team_member_skill_evolution_rails.values():
            for rail in rails:
                try:
                    rail.signal_trigger = True
                    rail.review_trigger = False
                    rail.auto_save = True
                except Exception as exc:
                    logger.debug("[TeamManager] member auto_save update failed: %s", exc)

        # Rebuild any missing role-specific rails from the preserved context.
        for session_id, context in list(self._team_rail_contexts.items()):
            has_team_rail = session_id in self._team_skill_rails
            has_create_rail = session_id in self._team_skill_create_rails
            if has_team_rail and has_create_rail:
                continue
            self._build_and_mount_member_rails_for_context(
                session_id,
                context,
                mount_team_skill_rail=not has_team_rail,
                mount_team_skill_create_rail=not has_create_rail,
                mount_skill_evolution_rail=True,
            )
        for session_id, contexts in list(self._team_member_rail_contexts.items()):
            for context in contexts:
                if self._has_live_rail(session_id, context.agent, SkillEvolutionRail):
                    continue
                self._build_and_mount_member_rails_for_context(
                    session_id,
                    context,
                    mount_team_skill_rail=False,
                    mount_team_skill_create_rail=False,
                    mount_skill_evolution_rail=True,
                )

    async def destroy_team(self, session_id: str) -> bool:
        async with self._bootstrap_lock:
            return await self._destroy_team(session_id)

    async def _destroy_other_sessions(self, current_session_id: str, channel_id: str | None = None) -> None:
        """Destroy stale distributed bootstrap TeamAgents on session switch.

        按 channel_id 过滤：singleton 模式下多个 channel 共享同一个 TeamManager，
        只销毁同 channel 的旧 session，不影响其他 channel 正在运行的 team 实例。
        """
        stale_session_ids = []
        for sid, agent in self._team_agents.items():
            if sid != current_session_id and (
                channel_id is None or getattr(agent, 'channel_id', None) == channel_id
            ):
                stale_session_ids.append(sid)
        for stale_session_id in stale_session_ids:
            await self._destroy_team(stale_session_id)

    async def _destroy_team(self, session_id: str) -> bool:
        await self._cleanup_runtime_locals(session_id)

        team_agent = self._team_agents.pop(session_id, None)
        cleaned = False
        try:
            if team_agent is None:
                logger.info("[TeamManager] no in-memory team for session_id=%s", session_id)
                return False

            token = set_session_id(session_id)
            try:
                try:
                    cleaned = await team_agent.destroy_team(force=True)
                finally:
                    await release_a2x_reservations_for_session(session_id, team_agent=team_agent)
                    await _stop_team_messager(team_agent, session_id=session_id)
            finally:
                reset_session_id(token)

            logger.info(
                "[TeamManager] Team cleaned via core API: session_id=%s cleaned=%s",
                session_id,
                cleaned,
            )
        except Exception as exc:
            logger.error(
                "[TeamManager] destroy team failed: session_id=%s error=%s",
                session_id,
                exc,
            )

        return cleaned

    async def cleanup_all(self) -> None:
        async with self._bootstrap_lock:
            session_ids = list(self._team_agents.keys())
            for session_id in session_ids:
                await self._destroy_team(session_id)
            logger.info("[TeamManager] all teams cleaned")

    def get_team_agent(self, session_id: str) -> TeamAgent | None:
        """Return the live Team leader for either supported runtime path."""
        return self._team_agents.get(session_id) or self._runner_team_agents.get(session_id)

    def get_monitor_handler(self, session_id: str) -> TeamMonitorHandler | None:
        return self._team_monitors.get(session_id)

    def register_monitor(self, session_id: str, handler: TeamMonitorHandler) -> None:
        self._team_monitors[session_id] = handler

    def register_workflow_handler(self, session_id: str, handler: Any) -> None:
        self._workflow_handlers[session_id] = handler

    def get_workflow_handler(self, session_id: str) -> Any | None:
        return self._workflow_handlers.get(session_id)

    def pop_workflow_handler(self, session_id: str) -> Any | None:
        return self._workflow_handlers.pop(session_id, None)

    def register_stream_task(
        self,
        session_id: str,
        task: asyncio.Task,
        *,
        generation: int | None = None,
    ) -> None:
        if generation is not None:
            self.bind_generation(session_id, generation)
            self._stream_task_generations[session_id] = generation
        self._stream_tasks[session_id] = task

    def is_generation_running(self, session_id: str, generation: int) -> bool:
        """Return whether the current generation owns active Team work."""
        if not self.generation_matches(session_id, generation):
            return False
        return is_team_session_running(session_id)

    def _has_local_team_runtime(self, session_id: str) -> bool:
        """Return whether the session should use the legacy in-memory TeamAgent path."""
        return self._is_distributed_mode(get_config()) and session_id in self._team_agents

    async def attach_distributed_hooks_for_runner_runtime(
        self,
        team_name: str,
        session_id: str,
        channel_id: str | None = None,
    ) -> bool:
        """Track Runner-owned TeamAgent, then attach hooks in distributed mode.

        When team streaming uses Runner.run_agent_team_streaming(), the actual
        TeamAgent is created and cached by openjiuwen TeamRuntimeManager pool,
        not by TeamManager.create_team(). This method retrieves the Runner-owned
        TeamAgent from GLOBAL_RUNNER's pool for execution checks in every mode.
        Distributed bootstrap hooks are attached only in distributed mode.

        Args:
            team_name: Team name to look up in Runner pool.
            session_id: Session identifier for hook context.
            channel_id: Channel identifier for hook context.

        Returns:
            True if hooks attached successfully, False otherwise.
        """
        from openjiuwen.core.runner.runner import GLOBAL_RUNNER

        runtime_mgr = _runner_team_runtime_manager(GLOBAL_RUNNER)
        active_team = await runtime_mgr.pool.get(team_name)
        if active_team is None or active_team.current_session_id != session_id:
            logger.warning(
                "[TeamManager] Runner pool has no active team for distributed hooks "
                "team_name=%s session_id=%s",
                team_name,
                session_id,
            )
            return False

        team_agent = active_team.agent
        if team_agent is None:
            logger.warning(
                "[TeamManager] ActiveTeam has no agent instance for distributed hooks "
                "team_name=%s session_id=%s",
                team_name,
                session_id,
            )
            return False

        self._runner_team_agents[session_id] = team_agent

        if not self._is_distributed_mode(get_config()):
            return False

        try:
            from jiuwenswarm.agents.harness.team.remote_member_bootstrap import (
                attach_build_team_post_tool_registration_hook,
                attach_clean_team_distributed_teardown_wrapper,
                attach_distributed_local_spawn_guard,
                attach_remote_bootstrap_ack_listener,
                attach_shutdown_member_remote_cleanup_wrapper,
            )

            attach_distributed_local_spawn_guard(
                team_agent,
                session_id=session_id,
                channel_id=channel_id,
            )
            attach_build_team_post_tool_registration_hook(
                team_agent,
                session_id=session_id,
                channel_id=channel_id,
            )
            attach_shutdown_member_remote_cleanup_wrapper(
                team_agent,
                session_id=session_id,
                channel_id=channel_id,
            )
            attach_clean_team_distributed_teardown_wrapper(
                team_agent,
                session_id=session_id,
                channel_id=channel_id,
            )
            attach_remote_bootstrap_ack_listener(
                team_agent,
                session_id=session_id,
                channel_id=channel_id,
            )
            logger.info(
                "[TeamManager] distributed hooks attached to Runner-owned TeamAgent "
                "team_name=%s session_id=%s channel_id=%s",
                team_name,
                session_id,
                channel_id,
            )
            return True
        except Exception as exc:
            logger.warning(
                "[TeamManager] distributed hooks attach failed for Runner-owned TeamAgent "
                "team_name=%s session_id=%s error=%s",
                team_name,
                session_id,
                exc,
            )
            return False

    async def _stop_local_team_runtime(self, session_id: str, team_agent: TeamAgent) -> bool:
        stopped = False
        stop_coordination = getattr(team_agent, "stop_coordination", None) or getattr(
            team_agent,
            "_stop_coordination",
            None,
        )
        if callable(stop_coordination):
            try:
                await stop_coordination()
                stopped = True
            except Exception as exc:
                logger.warning(
                    "[TeamManager] stop local team coordination failed: session_id=%s error=%s",
                    session_id,
                    exc,
                )

        try:
            await release_a2x_reservations_for_session(session_id, team_agent=team_agent)
        except Exception as exc:
            logger.warning(
                "[TeamManager] release A2X reservations failed: session_id=%s error=%s",
                session_id,
                exc,
            )
        try:
            await _stop_team_messager(team_agent, session_id=session_id)
        except Exception as exc:
            logger.warning(
                "[TeamManager] stop local team messager failed: session_id=%s error=%s",
                session_id,
                exc,
            )
        return stopped

    async def _stop_runner_team_agent_transport(self, session_id: str) -> None:
        if not self._is_distributed_mode(get_config()):
            self._runner_team_agents.pop(session_id, None)
            return

        team_agent = self._runner_team_agents.pop(session_id, None)
        if team_agent is None:
            return

        stop_coordination = getattr(team_agent, "stop_coordination", None)
        if callable(stop_coordination):
            try:
                await stop_coordination()
            except Exception as exc:
                logger.warning(
                    "[TeamManager] stop Runner-owned team coordination failed: session_id=%s error=%s",
                    session_id,
                    exc,
                )

        try:
            await _stop_team_messager(team_agent, session_id=session_id)
        except Exception as exc:
            logger.warning(
                "[TeamManager] stop Runner-owned team messager failed: session_id=%s error=%s",
                session_id,
                exc,
            )

    async def _dispatch_swarmflow_controller(
        self,
        session_id: str,
        *,
        action: Literal["pause", "stop"],
    ) -> None:
        """Drive the session's BackgroundTaskController for every swarmflow run.

        Team lifecycle teardown is the single point that must do this, or a
        paused/destroyed team leaves dangling handles still burning tokens.
        Pause keeps the relaunch ticket (resumable); stop drops it (seal).

        The controller only returns once each cancelled task has unwound, i.e.
        the engine has written the pause/seal record and emitted the terminal
        progress event — so the workflow handler (still alive at this point)
        has it in its queue before anything tears the harness down.
        """
        controller = self.get_background_task_controller(session_id)
        try:
            if action == "pause":
                await controller.pause(None)
            else:
                await controller.stop(None)
        except Exception as exc:
            logger.warning(
                "[TeamManager] background task controller dispatch failed: "
                "session_id=%s action=%s error=%s",
                session_id,
                action,
                exc,
            )

    async def _pause_swarmflow_runs(self, session_id: str) -> None:
        """Park every active swarmflow run (idempotent for already-paused ones)."""
        await self._dispatch_swarmflow_controller(session_id, action="pause")

    async def _cleanup_runtime_locals(
        self,
        session_id: str,
        *,
        finalize_workflows: bool = True,
        workflow_disposition: Literal["stop", "pause"] = "stop",
    ) -> None:
        await self._cancel_team_evolution_watcher(session_id)

        stream_task = self._stream_tasks.pop(session_id, None)
        # Direct pop (stop_session_runtime path): mirror pop_stream_task's
        # marker cleanup so parked handlers draining now read as busy again.
        self._round_ended_requests.pop(session_id, None)
        self._held_idle.pop(session_id, None)
        # finalize_workflows=False is the pause path: the team comes back in
        # this process and resumes against the same tickets, so the controller
        # must survive. Every other teardown is final.
        if finalize_workflows:
            self._background_task_controllers.pop(session_id, None)
        if stream_task and not stream_task.done():
            stream_task.cancel()
            try:
                await stream_task
            except asyncio.CancelledError:
                pass
            except Exception as exc:
                logger.warning(
                    "[TeamManager] stream stop failed: session_id=%s error=%s",
                    session_id,
                    exc,
                )

        monitor_handler = self._team_monitors.pop(session_id, None)
        if monitor_handler is not None:
            try:
                await monitor_handler.stop()
            except Exception as exc:
                logger.warning(
                    "[TeamManager] monitor stop failed: session_id=%s error=%s",
                    session_id,
                    exc,
                )

        # The swarmflow controller is NOT driven here. Each lifecycle method
        # (pause / cancel / stop_paused) dispatches it before Runner.pause/stop —
        # Runner tears the leader harness down and would otherwise cancel the
        # swarmflow coroutine as a plain cancel (no pause/seal record). By the
        # time this runs the abort has unwound and the handler below only has
        # to drain the WORKFLOW_PAUSED/STOPPED it produced.
        workflow_handler = self.pop_workflow_handler(session_id)
        if workflow_handler is not None:
            try:
                # On non-resumable teardown the team runtime (and the swarmflow
                # background task it drives) is gone, so no further workflow
                # events can arrive — finalize any still-running run to a
                # terminal status before stopping, otherwise the checkpoint
                # would keep it 'running' forever. Pause keeps the runtime
                # parked and resumable in place, so it opts out.
                if finalize_workflows:
                    workflow_handler.finalize_pending_runs(
                        disposition=workflow_disposition
                    )
                await workflow_handler.stop()
                logger.info(
                    "[WF_DBG cleanup] workflow handler stopped: session_id=%s "
                    "finalized=%s",
                    session_id,
                    finalize_workflows,
                )
            except Exception as exc:
                logger.warning(
                    "[WF_DBG cleanup] workflow handler stop failed: session_id=%s error=%s",
                    session_id,
                    exc,
                )

        self._clear_team_rail_registries(session_id)

    async def _stop_runner_team_runtime(
        self, session_id: str, team_name: str, caller: str
    ) -> bool:
        """Stop Runner-owned team runtime, with proper cancellation and error handling.

        Args:
            session_id: The session ID
            team_name: The team name to stop
            caller: Caller identifier for logging (e.g., "cancel", "terminate", "pause")

        Returns:
            True if stop was successful, False otherwise
        """
        try:
            result = await Runner.stop_agent_team(
                team_name=team_name,
                session_id=session_id,
            )
            logger.info(
                "[TeamManager] %s: Runner pool entry removed: "
                "session_id=%s team_name=%s",
                caller,
                session_id,
                team_name,
            )
            return result
        except asyncio.CancelledError:
            logger.warning(
                "[TeamManager] %s: Runner stop cancelled: "
                "session_id=%s team_name=%s",
                caller,
                session_id,
                team_name,
            )
            return False
        except Exception as exc:
            logger.warning(
                "[TeamManager] %s: Runner stop failed: "
                "session_id=%s team_name=%s error=%s",
                caller,
                session_id,
                team_name,
                exc,
            )
            return False

    async def _finalize_runtime_cleanup(
        self,
        session_id: str,
        caller: str,
        *,
        workflow_disposition: Literal["stop", "pause"] = "stop",
    ) -> None:
        """Finalize runtime cleanup: cleanup locals and clear active/pending registrations."""
        logger.info(
            "[TeamManager] %s: executing cleanup, session_id=%s",
            caller,
            session_id,
        )
        await self._cleanup_runtime_locals(
            session_id,
            workflow_disposition=workflow_disposition,
        )
        logger.info(
            "[TeamManager] %s: cleanup done, clearing active, session_id=%s",
            caller,
            session_id,
        )
        self.clear_active_runtime(session_id)
        self.clear_pending_runtime(session_id)
        await self.release_current_round(session_id)
        # These round/session markers live on the process-wide TeamManager.
        # TUI disconnect cancels the async event generator before its normal
        # tail can clear them, so terminal runtime cleanup must own the
        # idempotent release as well.
        self._clear_terminal_session_markers(session_id)
        logger.info(
            "[TeamManager] %s: clear done, session_id=%s",
            caller,
            session_id,
        )

    async def _wait_for_stream_task_exit(
        self,
        session_id: str,
        *,
        timeout_sec: float = _TEAM_STREAM_EXIT_GRACE_TIMEOUT_SEC,
    ) -> bool:
        """Wait briefly for a team stream task to finish its own cleanup."""
        stream_task = self._stream_tasks.get(session_id)
        if stream_task is None or stream_task.done():
            return True

        try:
            await asyncio.wait_for(
                asyncio.shield(stream_task),
                timeout=timeout_sec,
            )
            logger.info(
                "[TeamManager] stream task exited within grace timeout: "
                "session_id=%s timeout_sec=%.1f",
                session_id,
                timeout_sec,
            )
            return True
        except asyncio.TimeoutError:
            logger.warning(
                "[TeamManager] stream task did not exit within grace timeout: "
                "session_id=%s timeout_sec=%.1f; cancelling during cleanup",
                session_id,
                timeout_sec,
            )
            return False
        except asyncio.CancelledError:
            if stream_task.done() and stream_task.cancelled():
                logger.info(
                    "[TeamManager] stream task was cancelled during grace timeout: "
                    "session_id=%s",
                    session_id,
                )
                return True
            raise
        except Exception as exc:
            logger.warning(
                "[TeamManager] stream task exited with error during grace timeout: "
                "session_id=%s error=%s",
                session_id,
                exc,
            )
            return True

    async def terminate_session_runtime(self, session_id: str, reason: str = "") -> bool:
        """Stop-like teardown for the current team session runtime.

        This stops the foreground stream/monitor owned by claw and then asks the
        Runner-owned team runtime to enter the stop state. Used for explicit
        team stop so the same session can resume later.
        """
        async with self._get_lifecycle_lock(session_id):
            has_stream_task = session_id in self._stream_tasks
            has_local_team_runtime = self._has_local_team_runtime(session_id)
            has_team_runtime = (
                has_local_team_runtime
                or session_id in self._team_monitors
                or self.is_runtime_active(session_id)
                or self.is_runtime_pending(session_id)
            )
            if not has_stream_task and not has_team_runtime:
                await self.release_current_round(session_id)
                self._clear_terminal_session_markers(session_id)
                return False
            logger.info(
                "[TeamManager] %s terminate team session runtime: session_id=%s",
                reason,
                session_id,
            )

            # Resolve team_name early before cleanup, from active/pending/metadata
            team_name = self._resolve_session_team_name(session_id)

            await self._report_session_inactive(session_id)

            # Stop Runner-owned runtime first before cleaning locals
            # to avoid gate/teardown races
            if team_name:
                await self._stop_runner_team_runtime(session_id, team_name, "terminate")

            if has_local_team_runtime:
                cleaned = await self._destroy_team(session_id)
            else:
                cleaned = False

            await self._finalize_runtime_cleanup(session_id, "terminate")
        logger.info(
            "[TeamManager] %steam session terminated: session_id=%s cleaned=%s",
            reason,
            session_id,
            cleaned,
        )
        return True

    async def cancel_session_runtime(
        self,
        session_id: str,
        reason: str = "",
        *,
        workflow_disposition: Literal["stop", "pause"] = "stop",
        generation: int | None = None,
    ) -> bool:
        """Cancel the current team session runtime, removing it from Runner pool.

        Unlike pause/terminate, this fully stops the Runner-owned team runtime
        so it is removed from the pool. This prevents subsequent sessions from
        hitting "present in pool but missing from DB" reject_inconsistent errors.

        Used for team cancel intent where the session should not be resumed.
        """
        if not self.generation_matches(session_id, generation):
            return False
        logger.info(
            "[TeamManager] cancel_session_runtime 入口: session_id=%s reason=%s",
            session_id, reason,
        )
        # 通知正在执行的 pause 操作中止自身，让 cancel 尽快获取 lifecycle lock
        self._cancel_requested[session_id] = True

        # 抢占：主动取消正在执行的 pause 任务，使其抛出 CancelledError 释放锁
        pause_task = self._active_pause_tasks.get(session_id)
        if pause_task and not pause_task.done():
            pause_task.cancel()
            logger.info(
                "[TeamManager] cancel: preempting pause task, session_id=%s",
                session_id,
            )

        # 如果 lifecycle lock 被其他操作（如 pause）持有，先尝试直接停止 Runner
        # 以避免 cancel 被 pause 阻塞长达数分钟
        lock = self._get_lifecycle_lock(session_id)
        if lock.locked():
            team_name = self._resolve_session_team_name(session_id)
            if team_name:
                # Drive the controller before Runner.stop tears the harness
                # down, or the swarmflow coroutine dies as a plain cancel with
                # no seal/pause record (see cancel path below).
                await self._dispatch_swarmflow_controller(
                    session_id, action=workflow_disposition
                )
                await self._stop_runner_team_runtime(
                    session_id, team_name, "cancel: forced"
                )


        async with self._get_lifecycle_lock(session_id):
            # 清理 cancel_requested 标志
            self._cancel_requested.pop(session_id, None)

            has_stream_task = session_id in self._stream_tasks
            has_local_team_runtime = self._has_local_team_runtime(session_id)
            has_team_runtime = (
                has_local_team_runtime
                or session_id in self._team_monitors
                or self.is_runtime_active(session_id)
                or self.is_runtime_pending(session_id)
            )
            if (
                not has_stream_task
                and not has_team_runtime
                and not self.has_swarmflow_runs(session_id)
            ):
                await self.release_current_round(session_id)
                self._clear_terminal_session_markers(session_id)
                return False

            logger.info(
                "[TeamManager] %s cancel team session runtime: session_id=%s",
                reason,
                session_id,
            )

            # Resolve team_name early before cleanup, from active/pending/metadata
            team_name = self._resolve_session_team_name(session_id)

            # Drive the swarmflow controller BEFORE Runner.stop (stop_all
            # precedes stop_team). Runner.stop tears down the leader
            # harness, whose async-tool runtime cancels the coroutine as a
            # plain cancel — no abort reason, so the engine writes neither the
            # seal (user termination) nor the pause record (disconnect reclaim)
            # and run_background's finally deregisters the handle before the
            # controller ever sees it.
            await self._dispatch_swarmflow_controller(
                session_id, action=workflow_disposition
            )

            # Stop Runner-owned runtime first before cancelling stream task
            # to avoid gate/teardown races and ensure pool removal
            runner_stopped = False
            if team_name:
                runner_stopped = await self._stop_runner_team_runtime(
                    session_id, team_name, "cancel"
                )
                await self._stop_runner_team_agent_transport(session_id)

            cleaned = False

            await self._finalize_runtime_cleanup(
                session_id,
                "cancel",
                workflow_disposition=workflow_disposition,
            )

        logger.info(
            "[TeamManager] %steam session cancelled: session_id=%s cleaned=%s runner_stopped=%s",
            reason,
            session_id,
            cleaned,
            runner_stopped,
        )
        return True

    async def stop_session_runtime(
        self,
        session_id: str,
        reason: str = "",
        *,
        stop_runner: bool = True,
        generation: int | None = None,
    ) -> bool:
        """Stop local runtime resources and, by default, the Runner runtime.

        Permanent delete callers leave the Runner runtime alive until
        ``Runner.delete_agent_team(force=True)`` so agent-core can snapshot its
        member bindings before performing the equivalent stop itself.
        """
        if not self.generation_matches(session_id, generation):
            return False
        async with self._get_lifecycle_lock(session_id):
            has_stream_task = session_id in self._stream_tasks
            has_local_team_runtime = self._has_local_team_runtime(session_id)
            has_team_runtime = (
                has_local_team_runtime
                or session_id in self._runner_team_agents
                or session_id in self._team_monitors
                or self.is_runtime_active(session_id)
                or self.is_runtime_pending(session_id)
            )
            if (
                not has_stream_task
                and not has_team_runtime
                and not self.has_swarmflow_runs(session_id)
            ):
                await self.release_current_round(session_id)
                self._clear_terminal_session_markers(session_id)
                return False

            logger.info(
                "[TeamManager] %s stop team session runtime: session_id=%s",
                reason,
                session_id,
            )
            # Drive the swarmflow controller BEFORE the teardown below drops
            # it: without a controller-driven stop the run dies as a plain
            # cancel — no abort reason, no seal record (same ordering
            # rationale as the cancel path).
            await self._dispatch_swarmflow_controller(session_id, action="stop")
            team_agent = self._team_agents.pop(session_id, None) if has_local_team_runtime else None
            await self._cleanup_runtime_locals(session_id)

            stopped = False
            if has_local_team_runtime and team_agent is not None:
                stopped = await self._stop_local_team_runtime(session_id, team_agent)

            team_name = self._resolve_session_team_name(session_id)

            if team_name and stop_runner:
                try:
                    runner_stopped = await Runner.stop_agent_team(team_name=team_name, session_id=session_id)
                    stopped = runner_stopped or stopped
                except Exception as exc:
                    logger.warning(
                        "[TeamManager] runner stop failed: session_id=%s team_name=%s error=%s",
                        session_id,
                        team_name,
                        exc,
                    )
            if not has_local_team_runtime:
                try:
                    team_agent = self._runner_team_agents.get(session_id)
                    await release_a2x_reservations_for_session(session_id, team_agent=team_agent)
                except Exception as exc:
                    logger.warning(
                        "[TeamManager] release A2X reservations failed: session_id=%s error=%s",
                        session_id,
                        exc,
                    )
                if stop_runner:
                    await self._stop_runner_team_agent_transport(session_id)
                else:
                    # Runner.delete_agent_team(force=True) still owns the
                    # actual TeamAgent stop; drop only Jiuwenswarm's mirror.
                    self._runner_team_agents.pop(session_id, None)

            self.clear_active_runtime(session_id)
            self.clear_pending_runtime(session_id)
            await self.release_current_round(session_id)
            self._clear_terminal_session_markers(session_id)

        logger.info(
            "[TeamManager] %steam session stopped: session_id=%s stopped=%s",
            reason,
            session_id,
            stopped,
        )
        return True

    async def quiesce_for_delete(
        self,
        target: Any,
        *,
        reason: str,
    ) -> None:
        """Stop Team execution while retaining TeamAgent/Model/Runner objects."""
        session_id = target.descriptor.session_id
        async with self._get_lifecycle_lock(session_id):
            self._terminal_delete_sessions.add(session_id)
            try:
                await self._dispatch_swarmflow_controller(session_id, action="stop")
                await self._cleanup_runtime_locals(session_id)
            except BaseException:
                # Nothing destructive has started yet.  Let a later request
                # cold-recover the stopped runtime when delete quiesce fails or
                # is cancelled before resource release/disposal.
                self._terminal_delete_sessions.discard(session_id)
                raise

    async def dispose_after_resource_release(
        self,
        target: Any,
        *,
        reason: str,
    ) -> None:
        """Dispose local Team resources after derived resources were released."""
        session_id = target.descriptor.session_id
        async with self._get_lifecycle_lock(session_id):
            team_agent = self._team_agents.pop(session_id, None)
            if team_agent is not None:
                await self._stop_local_team_runtime(session_id, team_agent)
            runner_team_agent = self._runner_team_agents.pop(session_id, None)
            if runner_team_agent is not None:
                try:
                    await release_a2x_reservations_for_session(
                        session_id,
                        team_agent=runner_team_agent,
                    )
                except Exception as exc:
                    logger.warning(
                        "[TeamManager] release A2X reservations failed during "
                        "delete: session_id=%s error=%s",
                        session_id,
                        exc,
                    )
            self.clear_active_runtime(session_id)
            self.clear_pending_runtime(session_id)
            await self.release_current_round(session_id)
            self._clear_terminal_session_markers(session_id)

    def delete_aborted(self, target: Any) -> None:
        """Reopen execution admission when deletion stops before disposal."""
        self._terminal_delete_sessions.discard(target.descriptor.session_id)

    def delete_committed(self, target: Any) -> None:
        """Release the admission fence after permanent deletion commits."""
        self._terminal_delete_sessions.discard(target.descriptor.session_id)

    @staticmethod
    async def _find_paused_runner_team_name(session_id: str) -> str | None:
        """Return the paused Runner team name for a session using the public facade."""
        normalized_session_id = str(session_id or "").strip()
        if not normalized_session_id:
            return None

        try:
            active_teams = await Runner.list_active_teams()
        except Exception as exc:
            logger.warning(
                "[TeamManager] list active teams failed before paused lookup: session_id=%s error=%s",
                session_id,
                exc,
            )
            return None

        for info in active_teams:
            current_session_id = str(info.current_session_id or "").strip()
            if current_session_id == normalized_session_id and info.state == RuntimeState.PAUSED:
                team_name = str(info.team_name or "").strip()
                return team_name or None
        return None

    async def stop_paused_session_runtime(
        self,
        session_id: str,
        reason: str = "",
        *,
        offload: bool = True,
        preserve_organization: bool = False,
    ) -> bool:
        """Stop a parked runtime; local navigation may preserve organization Teams."""
        async with self._get_lifecycle_lock(session_id):
            if self.has_stream_task(session_id):
                logger.debug(
                    "[TeamManager] skip paused runtime stop because stream task is active: session_id=%s",
                    session_id,
                )
                return False

            team_name = await self._find_paused_runner_team_name(session_id)
            if not team_name:
                logger.debug(
                    "[TeamManager] skip paused runtime stop because no paused Runner entry matched: session_id=%s",
                    session_id,
                )
                return False

            if preserve_organization:
                from openjiuwen.core.runner.runner import GLOBAL_RUNNER

                runtime_mgr = _runner_team_runtime_manager(GLOBAL_RUNNER)
                entry = await runtime_mgr.pool.get(team_name)
                if entry is not None and entry.current_session_id == session_id:
                    backend = entry.agent.team_backend
                    org_manager = getattr(backend, "org_task_manager", None)
                    if getattr(org_manager, "organization_id", None):
                        # A parked organization leader still receives task reviews
                        # and final-report delivery while another session is visible.
                        logger.info(
                            "[TeamManager] preserve organization runtime during session switch: "
                            "session_id=%s team_name=%s",
                            session_id,
                            team_name,
                        )
                        return False

            if offload:
                await self._report_session_inactive(session_id)

            logger.info(
                "[TeamManager] %sstop paused team session runtime: session_id=%s team_name=%s",
                reason,
                session_id,
                team_name,
            )
            # Session switch / new session: drop the parked tickets (no seal —
            # the pause record stays in the journal for a cold-start resume).
            # Same slot as the other lifecycle paths: before Runner.stop.
            await self._dispatch_swarmflow_controller(session_id, action="stop")
            stopped = await self._stop_runner_team_runtime(
                session_id,
                team_name,
                "paused-runtime-stop",
            )
            await self._stop_runner_team_agent_transport(session_id)
            await self._finalize_runtime_cleanup(session_id, "paused-runtime-stop")

        logger.info(
            "[TeamManager] %spaused team session stopped: session_id=%s stopped=%s",
            reason,
            session_id,
            stopped,
        )
        return stopped

    async def stop_all_paused_session_runtimes(self, reason: str = "") -> int:
        """Stop every paused Runner team runtime known to the process."""
        try:
            active_teams = await Runner.list_active_teams()
        except Exception as exc:
            logger.warning("[TeamManager] list active teams failed before paused stop: %s", exc)
            return 0

        paused_session_ids: set[str] = set()
        for info in active_teams:
            if info.state != RuntimeState.PAUSED:
                continue
            current_session_id = str(info.current_session_id or "").strip()
            if current_session_id:
                paused_session_ids.add(current_session_id)
        stopped_count = 0
        for session_id in paused_session_ids:
            stopped = await self.stop_paused_session_runtime(session_id, reason=reason)
            if stopped:
                stopped_count += 1
        return stopped_count

    async def pause_session_runtime(
        self,
        session_id: str,
        reason: str = "",
        *,
        generation: int | None = None,
    ) -> bool:
        """Pause the current team runtime for this session.

        Team runtimes are persistent. The current implementation pauses by
        tearing down the foreground stream task and parking the Runner-owned
        runtime in paused state so a later `chat.send` can resume it.
        """
        if not self.generation_matches(session_id, generation):
            return False
        async with self._get_lifecycle_lock(session_id):
            has_stream_task = session_id in self._stream_tasks
            has_local_team_runtime = self._has_local_team_runtime(session_id)
            has_team_runtime = (
                has_local_team_runtime
                or session_id in self._team_monitors
                or self.is_runtime_active(session_id)
                or self.is_runtime_pending(session_id)
            )
            if not has_stream_task and not has_team_runtime:
                return False

            # 如果 cancel 请求已到达，中止 pause 并让 cancel 执行
            if self._cancel_requested.get(session_id):
                logger.info(
                    "[TeamManager] %s pause aborted: cancel requested for session_id=%s",
                    reason, session_id,
                )
                return False

            logger.info(
                "[TeamManager] %s pause team session runtime: session_id=%s",
                reason,
                session_id,
            )

            team_name = self._resolve_session_team_name(session_id)
            runner_paused = False
            if team_name:
                try:
                    # 再次检查 cancel 标志，避免在等待 Runner.pause 时 cancel 已到达
                    if self._cancel_requested.get(session_id):
                        logger.info(
                            "[TeamManager] %s pause aborted before Runner.pause: session_id=%s",
                            reason, session_id,
                        )
                        return False

                    # Park swarmflow runs BEFORE Runner.pause. Runner.pause tears
                    # down the leader harness, whose async-tool runtime cancels
                    # the swarmflow coroutine as a plain cancel — no abort reason,
                    # no pause record, and run_background's finally deregisters
                    # the handle. Pausing first lets the controller's three-step
                    # abort (reason=pause) unwind the engine so it writes the
                    # pause record, emits WORKFLOW_PAUSED while the workflow
                    # handler is still alive, and parks the relaunch ticket.
                    await self._pause_swarmflow_runs(session_id)

                    # 注册当前 pause 任务，供 cancel 抢占取消
                    self._active_pause_tasks[session_id] = asyncio.current_task()
                    try:
                        runner_paused = await Runner.pause_agent_team(
                            team_name=team_name,
                            session_id=session_id,
                        )
                    except asyncio.CancelledError:
                        logger.info(
                            "[TeamManager] %s pause aborted: cancelled by cancel request, session_id=%s",
                            reason, session_id,
                        )
                        team_name = self._resolve_session_team_name(session_id)
                        if team_name:
                            await self._stop_runner_team_runtime(
                                session_id, team_name, "pause aborted"
                            )
                        await self._finalize_runtime_cleanup(session_id, "pause aborted")
                        return False
                    finally:
                        self._active_pause_tasks.pop(session_id, None)

                except Exception as exc:
                    logger.warning(
                        "[TeamManager] runner pause failed: session_id=%s team_name=%s error=%s",
                        session_id,
                        team_name,
                        exc,
                    )

            if runner_paused:
                await self._wait_for_stream_task_exit(session_id)

            # Pause parks the runtime in place (resumable via a later chat.send),
            # so running workflows may still continue — do NOT finalize them.
            await self._cleanup_runtime_locals(session_id, finalize_workflows=False)
            self.clear_active_runtime(session_id)
            self.clear_pending_runtime(session_id)

        logger.info(
            "[TeamManager] %steam session paused: session_id=%s runner_paused=%s",
            reason,
            session_id,
            runner_paused,
        )
        return True

    async def _cancel_stream_task(self, session_id: str, reason: str) -> None:
        """Cancel one stream task while serializing its lifecycle operations."""
        async with self._get_lifecycle_lock(session_id):
            task = self._stream_tasks.get(session_id)
            if task is None:
                return
            if not task.done():
                logger.info(
                    "[TeamManager] %s cancel stream task session_id=%s",
                    reason,
                    session_id,
                )
                task.cancel()
            if not task.done():
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                except Exception as exc:
                    logger.warning(
                        "[TeamManager] stream task await after cancel failed session_id=%s: %s",
                        session_id,
                        exc,
                    )
            if self._stream_tasks.get(session_id) is task:
                self._stream_tasks.pop(session_id, None)
                # Same invariant as pop_stream_task: the parked handlers this
                # stream released are gone, so their markers must not survive
                # into the next stream generation for the same session.
                self._round_ended_requests.pop(session_id, None)

    async def cancel_all_stream_tasks(
        self,
        reason: str = "",
        *,
        exclude_session_ids: set[str] | None = None,
    ) -> None:
        """Cancel Team streams after disconnect, preserving process-owned runs."""
        protected = set(exclude_session_ids or ())
        session_ids = [
            session_id
            for session_id in self._stream_tasks
            if session_id not in protected
        ]
        await asyncio.gather(
            *(self._cancel_stream_task(session_id, reason) for session_id in session_ids),
        )


# Singleton TeamManager: all channels share one instance. Team runtime state
# (_stream_tasks / _initialized_sessions / _active_team_names /
# _pending_waiters / _cron_team_completion / rails / watchers) is indexed by
# session_id and is per-session, never per-channel. Sharing the instance lets a
# bridged follow-up request (e.g. a /join member replying from feishu while the
# originating web stream is still
# alive) see the originating channel's runtime markers so it is correctly
# routed through interact() instead of being misidentified as a first request
# and colliding with the Runner team pool.
_team_manager: TeamManager | None = None


def is_team_session_running(session_id: str) -> bool:
    """Read executing members and workflow agents, without counting ownership.

    Request, round, stream and runtime registrations may all survive execution.
    They are not evidence that the Session is busy.
    """
    manager = _team_manager
    if manager is None:
        return False
    team_agent = manager.get_team_agent(session_id)
    if team_agent is not None:
        # Cooperative pause waits for the executing tool to reach a boundary.
        # PAUSING still executes; only the acknowledged PAUSED state is idle.
        if team_agent.is_agent_running() or getattr(
            getattr(team_agent, "harness", None), "state", None
        ) is HarnessState.PAUSING:
            return True
        # The leader keeps the current member statuses from core transitions.
        # Read peers only: its own harness above is the direct execution state.
        registry = getattr(getattr(team_agent, "_state", None), "member_registry", None)
        if registry is not None and any(
            status == "busy" and name != registry.self_member_name
            for name, status in registry.snapshot().items()
        ):
            return True
    controller = manager.find_background_task_controller(session_id)
    handler = manager.get_workflow_handler(session_id)
    if controller is None or handler is None:
        return False
    # Paused/stopped runs leave resumable cards and monitor state behind.
    # Only live runs with an agent actually running count; human waits do not.
    active_runs = getattr(controller, "_active", {})
    return any(
        run_id in active_runs
        and run.status == "running"
        and any(agent.status == "running" for phase in run.phases for agent in phase.agents)
        for run_id, run in handler.get_run_states().items()
    )


def team_session_has_parked_request(session_id: str, request_ids) -> bool:
    """Whether every listed chat request is parked on a released Team round.

    Companion of :func:`is_team_session_running` for the archive guard: a
    request whose round was released no longer owns team work even though its
    response handler stays alive on the persistent leader stream.  Once that
    stream ends the markers are cleared, so a handler still draining the
    stream's tail counts as busy again rather than parked.
    """
    manager = _team_manager
    if manager is None:
        return False
    if (
        not manager.has_stream_task(session_id)
        # ``request_ids`` only covers WebSocket chat handlers.  Automation
        # (and other non-Web ingress) can own a Team round without appearing
        # there, so no active Team state may coexist with a parked exemption.
        or manager.has_inflight_request(session_id)
        or manager.is_round_active(session_id)
    ):
        return False
    return all(
        manager.is_round_ended_request(session_id, request_id)
        for request_id in request_ids
    )


def team_round_finishing_after_flow(session_id: str) -> bool:
    """Whether the active Team round is only wrapping up after its swarmflow runs ended.

    Companion of :func:`is_team_session_running` for the lifecycle busy guard:
    ``swarmflow.stop`` and natural workflow completion leave the round active
    while the leader reports the outcome, so an archive or delete in that
    window hits SESSION_BUSY even though nothing is left for the user to stop.
    The guard uses this to answer "retry shortly" instead of "stop it first".

    Two gates keep the probe honest: the round must itself have witnessed a
    flow terminal event (``round_can_finish_after_flow`` — the workflow handler
    keeps run states across rounds, so stale terminals from an earlier round
    must not leak into a fresh one), and every run must be terminal.  A paused
    run is deliberately excluded: the flow has not ended, so the user still
    has something to resume or stop.
    Outstanding Team tasks and execution after the terminal event also exclude
    the round: flow completion alone does not mean the leader is only reporting.
    """
    manager = _team_manager
    if manager is None or not manager.is_round_active(session_id):
        return False
    if not manager.round_can_finish_after_flow(session_id):
        return False
    handler = manager.get_workflow_handler(session_id)
    if handler is None:
        return False
    get_run_states = getattr(handler, "get_run_states", None)
    if not callable(get_run_states):
        return False
    run_states = get_run_states() or {}
    if not run_states:
        # A round that never ran a swarmflow is ordinary execution, not the
        # post-flow report window this probe describes.
        return False
    return all(
        bool(getattr(run, "is_terminal", False)) for run in run_states.values()
    )


def get_team_manager(channel_id: str | None = None) -> TeamManager:
    """Return the singleton TeamManager instance (channel_id is ignored)."""
    global _team_manager
    if _team_manager is None:
        _team_manager = TeamManager()
    return _team_manager


def find_team_skill_rail_across_managers(request_id: str) -> Any | None:
    """Find the TeamSkillEvolutionRail that owns a pending request."""
    return get_team_manager().find_team_skill_rail_for_request(request_id)


async def reload_team_skill_views_across_managers(session_id: str | None = None) -> int:
    """Reload live team Skill views on the singleton manager.

    Args:
        session_id: Restrict the reload to one session; ``None`` reloads all.

    Returns:
        Number of Skill rails reloaded.
    """
    return await get_team_manager().reload_team_skill_views(session_id)


async def cancel_all_team_stream_tasks_across_managers(
    reason: str = "",
    *,
    exclude_session_ids: set[str] | None = None,
) -> None:
    """Cancel Team streams except explicitly process-owned sessions."""
    await get_team_manager().cancel_all_stream_tasks(
        reason=reason,
        exclude_session_ids=exclude_session_ids,
    )


async def stop_team_session_runtime_across_managers(
    session_id: str,
    reason: str = "",
    *,
    stop_runner: bool = True,
) -> bool:
    """Stop a team session runtime on the singleton manager."""
    return await get_team_manager().stop_session_runtime(
        session_id,
        reason=reason,
        stop_runner=stop_runner,
    )


async def stop_all_paused_team_session_runtimes_across_managers(reason: str = "") -> int:
    """Stop all paused team runtimes on the singleton manager."""
    return await get_team_manager().stop_all_paused_session_runtimes(reason=reason)


def get_all_team_managers() -> list[TeamManager]:
    """Return the singleton manager wrapped in a list (callers iterate this)."""
    return [get_team_manager()]


def reset_team_manager(channel_id: str | None = None) -> None:
    """Reset the singleton TeamManager (channel_id is ignored)."""
    global _team_manager
    _team_manager = None
