import sys

sys.path[:0] = ["/a2c", "/pkg"]
import a2c_verifier  # noqa: E402

a2c_verifier.main()
