# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.

"""Human-agent-side inbox: dumb router for typed ``HumanAgentMessage`` payloads.

The inbox does **not** parse the body — the top-layer
``parse_interact_str`` already turned ``@<member>`` / ``@all`` / ``$<name>``
syntax into structured payloads. ``send`` only routes based on the
explicit ``to`` argument:

* ``to is None`` → enqueue the body into the matching avatar's own
  coordination as user input (``interact`` → ``USER_INPUT`` event), tagged
  ``<team-inbound from="controller">`` so the avatar can tell its
  controller apart from the team; the avatar consumes it after its harness
  has started. No bus message. Avatar-flavored members only — a passive
  human member has no avatar to drive, and ``_dispatch_payload`` refuses
  bare passive input with ``passive_member_no_avatar`` before it gets here.
* ``to in BROADCAST_TARGETS`` (``"all"`` / ``"*"``) → broadcast as the
  human ``sender`` (avatar or passive — both post bus rows).
* ``to=<member>`` → validate the target and post a point-to-point bus
  message from ``sender`` (both flavors).

Sender resolution stays here: a team with a single human member
(avatar or passive) can omit ``sender``, and we still want unknown senders
to raise ``UnknownHumanAgentError`` rather than silently injecting a rogue
identity into the message log. A passive member's structured actions do
NOT flow through this inbox — tool-call relays arrive as
``HumanAgentToolCall`` payloads and go to the passthrough executor.
"""

from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Awaitable,
    Callable,
    Optional,
)

from openjiuwen.agent_teams.constants import HUMAN_AGENT_MEMBER_NAME
from openjiuwen.agent_teams.inbound_render import render_controller_input
from openjiuwen.agent_teams.interaction.payload import (
    DeliverResult,
    HumanAgentInboundEvent,
)
from openjiuwen.agent_teams.interaction.router import (
    BROADCAST_TARGETS,
    deliver_direct,
)
from openjiuwen.core.common.logging import team_logger

if TYPE_CHECKING:
    from openjiuwen.agent_teams.agent.team_agent import TeamAgent
    from openjiuwen.agent_teams.tools.message_manager import TeamMessageManager
    from openjiuwen.agent_teams.tools.team import TeamBackend


AgentLookup = Callable[[str], Awaitable[Optional["TeamAgent"]]]
"""Resolve a human-agent ``member_name`` to its live ``TeamAgent``
runtime. Returns ``None`` when no live runtime is bound to that
member (cold start, before spawn, or after shutdown)."""


OnInbound = Callable[[HumanAgentInboundEvent], Awaitable[None]]
"""Callback fired when the runtime detects an inbound team-side
message addressed to a human agent. The hook is owned by the SDK /
business layer that wraps the runtime; the inbox itself does not
register subscriptions."""


class HumanAgentNotEnabledError(RuntimeError):
    """Raised when a caller tries to speak as a human agent on a
    team that has no human-agent member registered at all.
    """


class UnknownHumanAgentError(RuntimeError):
    """Raised when ``sender`` is not a registered human-agent member.

    Distinct from ``HumanAgentNotEnabledError``: the team has HITT on,
    but the specific sender the caller picked does not exist.
    """


class HumanAgentInbox:
    """Route human-agent input.

    Holds a reference to ``TeamBackend`` so the entry points can verify
    the team has at least one human agent registered and that the
    chosen ``sender`` is one of them. Unregistered senders raise
    ``UnknownHumanAgentError`` instead of silently injecting a rogue
    identity into the message log.

    Construction-time hooks:

    * ``agent_lookup(sender) -> TeamAgent | None`` — resolves the
      live human-agent runtime so non-mention input is enqueued into
      its coordination (``interact``) and drives its LLM. Required for
      the LLM-driven path; ``None`` falls back to a
      ``DeliverResult.failure("agent_unavailable")`` so the caller
      learns the avatar is not running yet.
    * ``on_inbound(HumanAgentInboundEvent)`` — passed through to the
      runtime that wires team→user notifications. ``HumanAgentInbox``
      itself does not call it; ``TeamRuntimeManager`` subscribes to
      ``TeamTopic.MESSAGE`` and forwards events here.
    """

    def __init__(
        self,
        team: "TeamBackend",
        message_manager: "TeamMessageManager",
        *,
        agent_lookup: Optional[AgentLookup] = None,
        on_inbound: Optional[OnInbound] = None,
    ):
        self._team = team
        self._mm = message_manager
        self._agent_lookup = agent_lookup
        self._on_inbound = on_inbound

    @property
    def on_inbound(self) -> Optional[OnInbound]:
        """Return the registered team→user notification callback, if any."""
        return self._on_inbound

    async def _resolve_sender(self, sender: Optional[str]) -> str:
        """Pick a sender and verify it is a registered human-agent member.

        Defaults to the first registered human agent when ``sender`` is
        omitted so single-human teams keep the minimal call form
        ``inbox.send(body)`` working.
        """
        names = await self._team.human_agent_names()
        if not names:
            raise HumanAgentNotEnabledError(
                "No human-agent member is registered on this team; "
                "create the team with enable_hitt=True or declare "
                "TeamMemberSpec(role_type=TeamRole.HUMAN_AGENT, ...) "
                "entries in predefined_members"
            )
        if sender is None:
            # Deterministic default: the reserved name if present,
            # otherwise the lexicographically first registered one.
            if HUMAN_AGENT_MEMBER_NAME in names:
                return HUMAN_AGENT_MEMBER_NAME
            return sorted(names)[0]
        if sender not in names:
            raise UnknownHumanAgentError(
                f"'{sender}' is not a registered human-agent member; registered members: {sorted(names)}"
            )
        return sender

    async def send(
        self,
        body: str,
        to: Optional[str] = None,
        *,
        sender: Optional[str] = None,
    ) -> DeliverResult:
        """Dispatch one already-parsed human-agent payload.

        Routes purely on ``to``:

        * ``to is None`` → enqueue ``body`` into the matching avatar's
          own coordination via ``interact`` (a ``USER_INPUT`` event);
          the avatar's loop consumes it once its harness is started, so
          no reach-in to a not-yet-started harness. Returns
          ``DeliverResult.failure("agent_unavailable")`` when no
          ``agent_lookup`` is wired or the avatar is not running.
        * ``to`` in :data:`BROADCAST_TARGETS` (``"all"`` / ``"*"``) →
          broadcast as ``sender``.
        * ``to=<member>`` → validate ``to`` against the live roster
          and post a direct bus message from ``sender``. Unknown
          targets surface as
          ``DeliverResult.failure("unknown_member:<target>")``.

        The body is delivered verbatim — top-level
        ``parse_interact_str`` already stripped any ``@<member>`` /
        ``$<name>`` prefixes before this layer sees the call.

        Args:
            body: Already-parsed message content.
            to: ``None`` to drive the avatar; broadcast token to
                broadcast; otherwise a member name.
            sender: Member name of the human agent speaking. Optional
                on single-human teams; required when the team declares
                multiple human-agent members.

        Raises:
            HumanAgentNotEnabledError: When the team has no registered
                human-agent member at all.
            UnknownHumanAgentError: When ``sender`` does not match any
                registered human-agent member.
        """
        resolved_sender = await self._resolve_sender(sender)
        team_logger.debug(
            "HumanAgentInbox: sender=%s, to=%s, body_len=%d",
            resolved_sender,
            to or "<avatar>",
            len(body or ""),
        )

        if to is None:
            return await self._drive_agent(body, sender=resolved_sender)
        if to in BROADCAST_TARGETS:
            msg_id = await self._mm.broadcast_message(
                content=body,
                from_member_name=resolved_sender,
            )
            if msg_id is None:
                return DeliverResult.failure("broadcast_failed")
            return DeliverResult.success(msg_id)
        return await deliver_direct(
            body,
            sender=resolved_sender,
            target=to,
            message_manager=self._mm,
            member_exists=self._member_exists,
        )

    # ------------------------------------------------------------------
    # Routing primitives
    # ------------------------------------------------------------------

    async def _member_exists(self, name: str) -> bool:
        """Async predicate adapter for ``deliver_direct``."""
        return await self._team.member_exists(name)

    async def _drive_agent(self, body: str, *, sender: str) -> DeliverResult:
        if self._agent_lookup is None:
            team_logger.warning(
                "HumanAgentInbox: no agent_lookup wired; cannot deliver input to human agent %s",
                sender,
            )
            return DeliverResult.failure("agent_unavailable")
        agent = await self._agent_lookup(sender)
        if agent is None:
            team_logger.warning("HumanAgentInbox: human agent %s has no live runtime", sender)
            return DeliverResult.failure("agent_unavailable")
        # Route through the avatar's OWN coordination (a USER_INPUT inner
        # event) instead of reaching into its harness directly. ``interact``
        # only enqueues; the avatar's coordination loop consumes it after
        # ``coordination.start`` has started the harness. A direct
        # ``deliver_input`` here would call ``harness.send`` from the
        # leader's coroutine and crash with "NativeHarness not started"
        # whenever the avatar was spawned but its run cycle has not yet
        # started its harness (e.g. the leader's initial routed input).
        #
        # Tag the body as coming from the controller. Delivered bare it
        # arrives as the harness's ordinary user turn, indistinguishable
        # from a team message, and the avatar answers it the way a member
        # answers ``user`` — by messaging ``user``, who is a different
        # person on the leader's side.
        await agent.interact(render_controller_input(content=body))
        return DeliverResult.success(None)


__all__ = [
    "AgentLookup",
    "HumanAgentInbox",
    "HumanAgentInboundEvent",
    "HumanAgentNotEnabledError",
    "OnInbound",
    "UnknownHumanAgentError",
]
