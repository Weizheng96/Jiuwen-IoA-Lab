# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.

"""Bind already-active in-process teams into an organization."""

from __future__ import annotations

import asyncio
import time
from collections import deque
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from typing import TYPE_CHECKING, Any, Awaitable, Callable, cast

from openjiuwen.agent_teams.messager.base import MessagerTransportConfig
from openjiuwen.agent_teams.messager.inprocess import InProcessMessager
from openjiuwen.agent_teams.organization.events import (
    OrgEvent,
    OrgEventMessage,
    OrgTaskClaimedEvent,
    OrgTaskCompletedEvent,
    OrgTaskCreatedEvent,
    OrgTaskDelegatedEvent,
    OrgTaskDescriptionRevisedEvent,
    OrgTaskFailedEvent,
    OrgTaskReviewedEvent,
    OrgTaskReviewRequestedEvent,
    OrgTeamInvitedEvent,
    OrgTeamJoinedEvent,
    OrgTopic,
)
from openjiuwen.agent_teams.organization.expert_adapters import (
    ExpertGroupCatalog,
    ExpertTeamLauncher,
)
from openjiuwen.agent_teams.organization.pool import get_process_org_manager, remove_process_org_manager
from openjiuwen.agent_teams.organization.schema import (
    ORG_TASK_REPAIRS_TASK_ID_KEY,
    OrganizationSpec,
    OrgAssignmentType,
    OrgSummaryExecutionStatus,
    OrgSummaryTeamStatus,
    OrgTaskAggregationMode,
    OrgTaskFailureCode,
    OrgTaskReviewStatus,
    OrgTaskStatus,
    OrgUnclaimedTaskPolicy,
)
from openjiuwen.agent_teams.organization.summary_team import SummaryTeamLauncher
from openjiuwen.agent_teams.organization.task_pool import (
    OrgTaskManager,
    _is_root_task_row,
    _is_supersedable_task,
)
from openjiuwen.agent_teams.organization.unclaimed import OrgUnclaimedTaskService
from openjiuwen.agent_teams.runtime.pool import RuntimeState
from openjiuwen.agent_teams.tools.team import TeamBackend
from openjiuwen.core.common.logging import team_logger
from openjiuwen.core.foundation.llm.schema.message import ToolMessage
from openjiuwen.core.single_agent.rail.base import (
    AgentCallbackContext,
    AgentCallbackEvent,
    ModelCallInputs,
    ToolCallInputs,
)
from openjiuwen.harness.rails.base import DeepAgentRail

logger = team_logger

_closeout_team: ContextVar[str | None] = ContextVar("organization_summary_closeout_team", default=None)
_SUBMISSION_TOOLS = frozenset({"read_file", "org_summary_get_inputs", "org_summary_complete"})


@contextmanager
def _summary_closeout_scope(team_id: str | None) -> Iterator[None]:
    """Cover host activation and its agent tasks, restoring normal policy on exit."""
    token = _closeout_team.set(team_id)
    try:
        yield
    finally:
        _closeout_team.reset(token)


def _is_summary_closeout(team_id: str) -> bool:
    return _closeout_team.get() == team_id


class _SummaryCloseoutRail(DeepAgentRail):
    """Bound Summary drafting and submission; narrow tool access only in recovery."""

    def __init__(self, team_id: str) -> None:
        super().__init__()
        self._team_id = team_id
        self._summary_task_id: str | None = None
        self._draft_dispatches: dict[str, int] = {}

    def stop_drafting(self, summary_task_id: str) -> None:
        """Exhaust the drafting budget for a blocked Summary task."""
        self._draft_dispatches[summary_task_id] = 2

    def callback_priority(self, event: AgentCallbackEvent) -> int:
        # Disclose last, but reject execution before permission/approval side effects.
        return -100 if event == AgentCallbackEvent.BEFORE_MODEL_CALL else 1000

    async def before_model_call(self, ctx: AgentCallbackContext) -> None:
        inputs = cast(ModelCallInputs, ctx.inputs)
        if _is_summary_closeout(self._team_id) and isinstance(inputs.tools, list):
            inputs.tools = [tool for tool in inputs.tools if tool.name in _SUBMISSION_TOOLS]

    async def before_tool_call(self, ctx: AgentCallbackContext) -> None:
        inputs = cast(ToolCallInputs, ctx.inputs)
        args = inputs.tool_args if isinstance(inputs.tool_args, dict) else {}
        if inputs.tool_name == "send_message" and args.get("to") == "delivery-drafter":
            task_id = self._summary_task_id or ""
            dispatches = self._draft_dispatches.get(task_id, 0)
            if dispatches >= 2:
                self._reject(ctx, "Summary permits only the initial draft and one focused revision.")
                return
            # Reserve before awaiting execution so parallel sends cannot exceed the bound.
            self._draft_dispatches[task_id] = dispatches + 1
        if not _is_summary_closeout(self._team_id) or inputs.tool_name in _SUBMISSION_TOOLS:
            return
        reason = "Summary closeout only permits read_file, org_summary_get_inputs and org_summary_complete."
        self._reject(ctx, reason)

    @staticmethod
    def _reject(ctx: AgentCallbackContext, reason: str) -> None:
        inputs = cast(ToolCallInputs, ctx.inputs)
        tool_call_id = inputs.tool_call.id if inputs.tool_call is not None else ""
        ctx.extra["_skip_tool"] = True
        inputs.tool_result = {"error": reason}
        inputs.tool_msg = ToolMessage(content=reason, tool_call_id=tool_call_id)

    async def after_tool_call(self, ctx: AgentCallbackContext) -> None:
        """Formal submission is terminal; failures remain available for correction."""
        inputs = cast(ToolCallInputs, ctx.inputs)
        if ctx.exception is not None:
            return
        result = inputs.tool_result
        success = result.get("success") if isinstance(result, dict) else getattr(result, "success", False)
        if success is not True:
            return
        args = inputs.tool_args if isinstance(inputs.tool_args, dict) else {}
        if inputs.tool_name == "org_summary_get_inputs":
            task_id = str(args.get("summary_task_id") or "")
            if task_id and task_id != self._summary_task_id:
                self._summary_task_id = task_id
            return
        if inputs.tool_name != "org_summary_complete":
            return
        context = args.get("output_context") or {}
        ctx.request_force_finish({"output": context.get("description", ""), "result_type": "answer"})

_ORG_OWNER_LIFECYCLE_SECTION = "organization_owner_lifecycle"
_ORG_COLLABORATION_SECTION = "organization_collaboration"
_ORG_SUMMARY_TEAM_SECTION = "organization_summary_team"
_ORG_OWNER_LIFECYCLE_PROMPT = {
    "cn": (
        "## Team Organization 生命周期约束\n"
        "你是当前 Team Organization 的 owner。organization 存在期间，禁止调用 "
        "clean_team，也不要关闭或解散本 Team。需要结束 organization 时，必须先调用 "
        "org_dissolve_organization 清空 organization 的成员和任务池；仅在该调用成功后，"
        "才能执行 shutdown_member 或 clean_team。"
    ),
    "en": (
        "## Team Organization lifecycle constraint\n"
        "You own the current Team Organization. While it exists, do not call clean_team "
        "and do not shut down or disband this Team. To end the organization, first call "
        "org_dissolve_organization to clear its members and task pool. Only after that call "
        "succeeds may you use shutdown_member or clean_team."
    ),
}

_ORG_COLLABORATION_PROMPT = {
    "cn": (
        "## Team Organization 协作记录\n"
        "团内 ≠ 跨 Team：拆分给本 Team 的 teammate 时，只用 create_task / claim_task / "
        "spawn_teammate / send_message；禁止把成员名当作 to_team_id 去调 org_create_task、"
        "org_delegate_task 或 org_send_leader_message。org_* 仅用于 Organization 内其他 Team"
        "（org team_id）。\n"
        "当跨 Team 依赖需要确认 API 契约、输入输出、验收结论或明确阻塞项时，使用 "
        "org_send_leader_message 向相关 leader 发送简短、可执行的消息。不要用它发送例行状态，"
        "也不要用它替代 task pool 的认领、完成和评审操作。\n"
        "对于已委派给其他 Team 的直接子任务，DELEGATED、CLAIMED 和 IN_PROGRESS 均表示对方 "
        "正在负责处理；暂未出现 output_context 或 output_abstract 不代表失败。不得重新委派、"
        "认领、启动、完成该任务，也不得为绕过等待创建内容重复的替代子任务。结束当前回合并等待 "
        "完成事件；只有 FAILED、REJECTED 或 NEEDS_REVISION 时，才按既有修复流程创建修复子任务。\n"
        "认领根任务后，必须在拆分前显式选择汇总模式；默认倾向 SUMMARY_TEAM。只有本 Team 能完成根任务的"
        "主体工作并独立作最终判断，其他 Team 的子任务仅提供完成该根任务所需的一小部分局部支持材料时，"
        "才选 HIERARCHICAL。若多个 Team 各自负责不同领域的一部分，成果相互独立且需要跨域形成最终结论，"
        "或本 Team 只负责其中一部分，则选 SUMMARY_TEAM；投资、法律、技术、市场等并列尽调即属此类。"
        "选择并启动根任务后，所有拆分工作都必须以该根任务为直接父任务，"
        "不能创建并列根任务；禁止对根任务调用 org_delegate_task，跨 Team 只通过子任务的 "
        "delegated_to_team_id 或对子任务 org_delegate_task。SUMMARY_TEAM 下，本 Team 自己的贡献也必须写成 "
        "根任务的直接子任务并完成验收，才能作为最终汇总来源；不要只留在 Team 内部任务中。"
    ),
    "en": (
        "## Team Organization collaboration record\n"
        "In-team ≠ cross-team: to assign work to this Team's teammates, use create_task / "
        "claim_task / spawn_teammate / send_message only. Never pass a member name as to_team_id "
        "to org_create_task, org_delegate_task, or org_send_leader_message. org_* tools target "
        "other organization Teams (org team_id) only.\n"
        "When a cross-team dependency needs an API-contract, input/output, acceptance, or concrete "
        "blocker confirmation, send a short actionable org_send_leader_message to the relevant leader. "
        "Do not use it for routine status updates or instead of task-pool claim, completion, and review operations.\n"
        "For a direct child delegated to another Team, DELEGATED, CLAIMED, and IN_PROGRESS mean that Team "
        "owns its execution; missing output does not mean failure. Do not re-delegate, claim, start, or complete "
        "it, and do not create a duplicate replacement merely to bypass waiting. End the current turn and wait "
        "for its completion event. Create a repair child only after FAILED, REJECTED, or NEEDS_REVISION.\n"
        "After claiming a root, explicitly choose its aggregation mode before decomposition; prefer "
        "SUMMARY_TEAM by default. Use HIERARCHICAL only when your Team performs the substantial core of "
        "the root task and can independently make the final judgment, while other Teams' child tasks "
        "supply only small, local supporting pieces. Use SUMMARY_TEAM when multiple Teams each own a "
        "distinct domain or part whose independent results require a cross-domain final judgment, or "
        "when your Team handles only one part; parallel investment, legal, technical, and market due "
        "diligence is an example. After choosing and starting the root, create every work item as "
        "its direct child, never as a parallel root; never org_delegate_task the root—cross-team work uses "
        "child delegated_to_team_id or org_delegate_task on that child only. In SUMMARY_TEAM mode, record your "
        "own contribution as a direct root child and have it accepted; an internal Team task alone is not a "
        "summary source."
    ),
}

_ORG_SUMMARY_TEAM_PROMPT = {
    "cn": (
        "## Summary Team 固定职责\n"
        "你只负责组织根任务的最终汇总。收到 `organization.summary` 任务时，必须先调用 "
        "`org_summary_get_inputs` 读取该任务绑定的、已验收来源及其输出；仅基于这些来源形成最终结论。"
        "不得创建 Organization 子任务、重新认领任务、审核或修改来源任务。中间产物放在 Summary Team "
        "工作空间，最终文件写入 Organization 工作空间的 summary/ 目录。将可交付给用户的最终内容写入 "
        "`org_summary_complete` 的 output_context.description，并在有最终文件时提供 result_uri，同时提供 "
        "output_abstract。"
    ),
    "en": (
        "## Summary Team fixed responsibility\n"
        "You only produce the final aggregation for an organization root task. For an "
        "`organization.summary` task, first call `org_summary_get_inputs` to read its bound, "
        "accepted sources and their outputs, then derive the final result only from those sources. "
        "Do not create Organization child tasks, re-claim tasks, or review or modify source tasks. Keep "
        "intermediate artifacts in the Summary Team workspace and write final files under the Organization "
        "workspace summary/ directory. Complete the Summary Task via `org_summary_complete`, putting the "
        "user-facing deliverable in output_context.description, the final path in result_uri when present, "
        "and a concise output_abstract."
    ),
}

_LEADER_TURN_PAUSE_POLL_INTERVAL_SECONDS = 0.1
_PARENT_RESUME_TERMINAL_STATUSES = frozenset(
    {
        OrgTaskStatus.COMPLETED,
        OrgTaskStatus.FAILED,
    }
)

if TYPE_CHECKING:
    from openjiuwen.agent_teams.agent.team_agent import TeamAgent
    from openjiuwen.agent_teams.runtime.manager import TeamRuntimeManager


class OrganizationRuntimeManager:
    """Create organizations and bind active leaders without restarting teams."""

    def __init__(self, team_runtime_manager: "TeamRuntimeManager") -> None:
        self._team_runtime_manager = team_runtime_manager
        self._membership_lock = asyncio.Lock()
        self._unclaimed_services: dict[tuple[str, str], OrgUnclaimedTaskService] = {}
        self._subscribed_topics: set[tuple[str, str, str, OrgTopic, int]] = set()
        self._org_subscribers: dict[tuple[str, str, str], Any] = {}
        self._org_subscriber_sources: dict[tuple[str, str, str], int] = {}
        self._team_organizations: dict[tuple[str, str], str] = {}
        self._leader_turn_queues: dict[tuple[str, str], deque[object]] = {}
        self._leader_turn_workers: dict[tuple[str, str], asyncio.Task[Any]] = {}
        self._scheduled_leader_messages: set[tuple[str, str, str]] = set()
        self._scheduled_parent_reviews: set[tuple[str, str, str]] = set()
        self._scheduled_summary_executions: set[tuple[str, str, str]] = set()
        self._summary_closeout_attempts: dict[tuple[str, str, str], int] = {}
        self._summary_member_failures: dict[tuple[str, str, str], set[str]] = {}
        self._leader_turn_runner: Callable[[str, str, object], Awaitable[bool]] | None = None
        self._summary_turn_runner: Callable[[str, str, object], Awaitable[bool]] | None = None
        self._configured_team_provider: Callable[[str], Awaitable[list[dict[str, Any]]]] | None = None
        self._team_activator: Callable[[str, str], Awaitable[str | None]] | None = None
        self._expert_group_catalog: ExpertGroupCatalog | None = None
        self._expert_team_launcher: ExpertTeamLauncher | None = None
        self._expert_adapter_installer: Callable[["OrganizationRuntimeManager"], None] | None = None
        self._summary_team_launcher: SummaryTeamLauncher | None = None
        self._summary_adapter_installer: Callable[["OrganizationRuntimeManager"], None] | None = None
        self._organization_progress_publisher: Callable[[str, str, dict[str, Any]], Awaitable[None]] | None = None
        self._summary_team_locks: dict[tuple[str, str], asyncio.Lock] = {}

    def set_leader_turn_runner(self, runner: Callable[[str, str, object], Awaitable[bool]]) -> None:
        """Set the host-owned path used to run an autonomous leader turn."""

        self._leader_turn_runner = runner

    def set_summary_turn_runner(self, runner: Callable[[str, str, object], Awaitable[bool]]) -> None:
        """Run only Summary Team background turns through the host's event relay."""
        self._summary_turn_runner = runner

    def set_configured_team_provider(self, provider: Callable[[str], Awaitable[list[dict[str, Any]]]]) -> None:
        """Set the host callback exposing dormant same-process team templates."""

        self._configured_team_provider = provider

    def set_team_activator(self, activator: Callable[[str, str], Awaitable[str | None]]) -> None:
        """Set the host callback that activates one configured team on invitation."""

        self._team_activator = activator

    def set_expert_group_catalog(self, catalog: ExpertGroupCatalog) -> None:
        """Set the host adapter that lists validated AgentGroup packages."""

        self._expert_group_catalog = catalog

    def set_expert_team_launcher(self, launcher: ExpertTeamLauncher) -> None:
        """Set the host adapter that launches expert Teams for organization invite."""

        self._expert_team_launcher = launcher

    def set_expert_adapter_installer(self, installer: Callable[["OrganizationRuntimeManager"], None] | None) -> None:
        """Register a host callback that injects Catalog/Launcher on first use.

        The installer should be idempotent and must not run package scans itself;
        it only constructs and ``set_*`` the adapters. Listing/launch still happen
        when tools call ``list_expert_groups`` / ``create_and_invite_expert_team``.
        """

        self._expert_adapter_installer = installer

    def set_summary_team_launcher(self, launcher: SummaryTeamLauncher) -> None:
        """Set the host launcher for the organization-wide reusable Summary Team."""

        self._summary_team_launcher = launcher

    def set_organization_progress_publisher(
        self, publisher: Callable[[str, str, dict[str, Any]], Awaitable[None]] | None
    ) -> None:
        """Install the host callback for user-visible organization milestones."""

        self._organization_progress_publisher = publisher

    async def publish_organization_progress(self, session_id: str, root_team_id: str, progress: dict[str, Any]) -> None:
        """Forward a factual organization milestone without exposing model reasoning."""

        if self._organization_progress_publisher is not None:
            await self._organization_progress_publisher(session_id, root_team_id, progress)

    def set_summary_adapter_installer(self, installer: Callable[["OrganizationRuntimeManager"], None] | None) -> None:
        """Register the host's lazy Summary Team adapter installer."""

        self._summary_adapter_installer = installer

    def _ensure_summary_adapter(self) -> None:
        """Install the host Summary Team launcher on first summary execution request."""

        if self._summary_team_launcher is not None or self._summary_adapter_installer is None:
            return
        self._summary_adapter_installer(self)

    def _ensure_expert_adapters(self) -> None:
        """Lazily run the host installer once Catalog or Launcher is still missing."""

        if self._expert_group_catalog is not None and self._expert_team_launcher is not None:
            return
        installer = self._expert_adapter_installer
        if installer is None:
            return
        installer(self)

    async def ensure_summary_team(
        self,
        *,
        organization_id: str,
        root_team_id: str,
        session_id: str,
    ) -> tuple[str, str]:
        """Lazily launch, invite, and persist the singleton Summary Team for one organization."""

        self._ensure_summary_adapter()
        if self._summary_team_launcher is None:
            raise ValueError("Summary Team launcher is not configured by the host")
        _, root_backend = await self._resolve_leader(root_team_id, session_id)
        manager = get_process_org_manager(
            organization_id=organization_id,
            db=root_backend.db,
            messager=root_backend.messager,
            session_id=session_id,
        )
        lock = self._summary_team_locks.setdefault((session_id, organization_id), asyncio.Lock())
        async with lock:
            existing = await manager.task_pool.get_summary_team()
            if existing is not None and existing.status == OrgSummaryTeamStatus.READY:
                if existing.summary_team_id and existing.leader_id:
                    entry = await self._team_runtime_manager.pool.get(existing.summary_team_id)
                    if (
                        entry is not None
                        and entry.current_session_id == session_id
                        and self._team_organizations.get((session_id, existing.summary_team_id)) == organization_id
                    ):
                        return existing.summary_team_id, existing.leader_id
            await manager.task_pool.reserve_summary_team()
            organization = await manager.get_organization()
            if organization is None or not organization.owner_team_id:
                raise ValueError("organization owner is required to invite the Summary Team")
            launched = await self._summary_team_launcher.launch(
                organization_id=organization_id,
                session_id=session_id,
                share_db_from_team_id=root_team_id,
            )
            try:
                await self.invite_team(
                    organization_id=organization_id,
                    inviter_team_id=organization.owner_team_id,
                    target_team_id=launched.team_id,
                    session_id=session_id,
                )
            except Exception:
                logger.error(
                    "invite Summary Team %s failed for org %s; stopping launched team",
                    launched.team_id,
                    organization_id,
                    exc_info=True,
                )
                await self._summary_team_launcher.stop(team_id=launched.team_id, session_id=session_id)
                raise
            await manager.task_pool.mark_summary_team_ready(
                team_id=launched.team_id,
                leader_id=launched.leader_id,
            )
            logger.info(
                "Summary Team ready: org=%s team=%s leader=%s",
                organization_id,
                launched.team_id,
                launched.leader_id,
            )
            return launched.team_id, launched.leader_id

    async def notify_summary_provision_failure(
        self,
        *,
        organization_id: str,
        root_team_id: str,
        root_leader_id: str,
        summary_task_id: str,
        reason: str,
        session_id: str,
    ) -> None:
        """Persist and deliver a provisioning-failure notice to the Root Leader."""

        _, backend = await self._resolve_leader(root_team_id, session_id)
        manager = get_process_org_manager(
            organization_id=organization_id,
            db=backend.db,
            messager=backend.messager,
            session_id=session_id,
        )
        notice = await manager.message_service.send_leader_message(
            from_team_id="__organization__",
            from_leader_id="__organization__",
            to_team_id=root_team_id,
            to_leader_id=root_leader_id,
            content=(
                f"Summary Team provisioning failed for Summary Task {summary_task_id}. "
                f"The Summary Task is FAILED(SUMMARY_PROVISION_FAILED). Reason: {reason}"
            ),
            metadata={
                "kind": "summary_provision_failed",
                "task_id": summary_task_id,
                "failure_code": OrgTaskFailureCode.SUMMARY_PROVISION_FAILED.value,
            },
        )
        if not notice.ok:
            logger.warning(
                "summary provision failure notice not delivered: summary=%s root=%s reason=%s",
                summary_task_id,
                root_team_id,
                notice.reason,
            )

    async def ensure_control_tools(self, agent: "TeamAgent", *, session_id: str) -> None:
        """Mount organization bootstrap tools on a running team leader."""

        backend = getattr(agent, "team_backend", None)
        if backend is None or not getattr(backend, "is_leader", False):
            return
        if not getattr(agent.spec, "enable_organization", True):
            return
        harness = agent.harness
        add_tool = getattr(harness, "add_tool", None)
        if not callable(add_tool):
            return
        from openjiuwen.agent_teams.organization.tools import create_org_control_tools

        for tool in create_org_control_tools(
            runtime_manager=self,
            team_id=backend.team_name,
            session_id=session_id,
        ):
            add_tool(tool)

    async def create_organization(
        self,
        *,
        organization_id: str,
        owner_team_id: str,
        session_id: str,
        display_name: str | None = None,
        description: str | None = None,
        unclaimed_task_policy: OrgUnclaimedTaskPolicy | None = None,
    ) -> OrganizationSpec:
        """Create an organization owned by an active team and bind its leader."""

        from openjiuwen.agent_teams.organization.workspace import validate_organization_id

        validate_organization_id(organization_id)
        async with self._membership_lock:
            owner_agent, owner_backend = await self._resolve_leader(owner_team_id, session_id)
            existing_manager = getattr(owner_backend, "org_task_manager", None)
            if existing_manager is not None and existing_manager.organization_id != organization_id:
                raise ValueError(f"team already belongs to organization: {existing_manager.organization_id}")

            manager = get_process_org_manager(
                organization_id=organization_id,
                db=owner_backend.db,
                messager=owner_backend.messager,
                session_id=session_id,
            )
            existing = await manager.get_organization()
            if existing is not None and existing.owner_team_id not in (None, owner_team_id):
                raise ValueError(f"organization already belongs to team: {existing.owner_team_id}")

            was_new = existing is None
            owner_leader_id = self._leader_id(owner_agent, owner_backend)
            spec = await manager.initialize(
                unclaimed_task_policy=unclaimed_task_policy,
                display_name=display_name,
                description=description,
                metadata={
                    **(existing.metadata if existing is not None else {}),
                    "owner_team_id": owner_team_id,
                    "owner_leader_id": owner_leader_id,
                    "session_id": session_id,
                },
            )
            await self._bind_team(
                agent=owner_agent,
                backend=owner_backend,
                manager=manager,
                session_id=session_id,
            )
            created = (await manager.get_organization()) or spec
            if was_new:
                logger.info(
                    "organization created: org=%s owner=%s leader=%s",
                    organization_id,
                    owner_team_id,
                    owner_leader_id,
                )
            return created

    async def invite_team(
        self,
        *,
        organization_id: str,
        inviter_team_id: str,
        target_team_id: str,
        session_id: str,
    ) -> OrganizationSpec:
        """Invite an active team, activating a configured dormant team when needed."""

        async with self._membership_lock:
            inviter_agent, inviter_backend = await self._resolve_leader(inviter_team_id, session_id)
            try:
                target_agent, target_backend = await self._resolve_leader(target_team_id, session_id)
            except ValueError as exc:
                if self._team_activator is None:
                    raise
                activated_team_id = await self._team_activator(target_team_id, session_id)
                if not activated_team_id:
                    raise ValueError(f"configured team could not be activated: {target_team_id}") from exc
                target_team_id = activated_team_id
                target_agent, target_backend = await self._resolve_leader(target_team_id, session_id)
            manager = get_process_org_manager(
                organization_id=organization_id,
                db=inviter_backend.db,
                messager=inviter_backend.messager,
                session_id=session_id,
            )
            organization = await manager.get_organization()
            if organization is None:
                raise ValueError(f"organization not found: {organization_id}")
            if organization.owner_team_id != inviter_team_id:
                raise ValueError("only the organization owner team can invite members")
            if target_backend.db is not inviter_backend.db:
                raise ValueError("invited team must use the owner's shared TeamDatabase instance")

            current_manager = getattr(target_backend, "org_task_manager", None)
            if current_manager is not None and current_manager.organization_id != organization_id:
                raise ValueError(f"team already belongs to organization: {current_manager.organization_id}")

            await manager.publish_event(
                OrgTeamInvitedEvent(
                    organization_id=organization_id,
                    team_id=inviter_team_id,
                    leader_id=self._leader_id(inviter_agent, inviter_backend),
                    inviter_team_id=inviter_team_id,
                    invited_team_id=target_team_id,
                ),
                team_inbox_id=target_team_id,
            )
            await self._bind_team(
                agent=target_agent,
                backend=target_backend,
                manager=manager,
                session_id=session_id,
            )
            await self._resume_assignable_tasks(
                manager=manager,
                team_id=target_team_id,
                session_id=session_id,
                capabilities=set(self._capabilities(target_agent)),
            )
            target_leader_id = self._leader_id(target_agent, target_backend)
            await manager.publish_event(
                OrgTeamJoinedEvent(
                    organization_id=organization_id,
                    team_id=target_team_id,
                    leader_id=target_leader_id,
                    joined_team_id=target_team_id,
                    joined_leader_id=target_leader_id,
                )
            )
            joined = (await manager.get_organization()) or organization
            logger.info(
                "team joined organization: org=%s team=%s leader=%s invited_by=%s",
                organization_id,
                target_team_id,
                target_leader_id,
                inviter_team_id,
            )
            return joined

    async def dissolve_organization(
        self,
        *,
        organization_id: str,
        owner_team_id: str,
        session_id: str,
    ) -> dict[str, Any]:
        """Unbind all members, stop temporary experts, and erase organization rows."""

        async with self._membership_lock:
            _, owner_backend = await self._resolve_leader(owner_team_id, session_id)
            manager = get_process_org_manager(
                organization_id=organization_id,
                db=owner_backend.db,
                messager=owner_backend.messager,
                session_id=session_id,
            )
            organization = await manager.get_organization()
            if organization is None:
                raise ValueError(f"organization not found: {organization_id}")
            if organization.owner_team_id != owner_team_id:
                raise ValueError("only the organization owner team can dissolve an organization")
            summary_team = await manager.task_pool.get_summary_team()

            service = self._unclaimed_services.pop((session_id, organization_id), None)
            if service is not None:
                await service.stop()

            member_team_ids = {leader.team_id for leader in organization.leaders}
            member_team_ids.add(owner_team_id)
            expert_team_ids: set[str] = set()
            for team_id in member_team_ids:
                key = (session_id, team_id)
                worker = self._leader_turn_workers.pop(key, None)
                if worker is not None and not worker.done():
                    worker.cancel()
                self._leader_turn_queues.pop(key, None)
                self._scheduled_leader_messages = {
                    message_key for message_key in self._scheduled_leader_messages if message_key[:2] != key
                }
                self._scheduled_parent_reviews = {
                    review_key for review_key in self._scheduled_parent_reviews if review_key[:2] != key
                }
                self._scheduled_summary_executions = {
                    summary_key for summary_key in self._scheduled_summary_executions if summary_key[:2] != key
                }
                await self._release_org_subscriber(organization_id, session_id, team_id)
                entry = await self._team_runtime_manager.pool.get(team_id)
                if entry is None or entry.current_session_id != session_id:
                    continue
                backend = getattr(entry.agent, "team_backend", None)
                if backend is None:
                    continue
                metadata = getattr(entry.agent.spec, "metadata", None) or {}
                if team_id != owner_team_id and metadata.get("expert_team"):
                    expert_team_ids.add(team_id)
                backend.org_task_manager = None
                backend.org_message_service = None
                self._unbind_organization_workspace(entry.agent, backend)
                spawn_manager = getattr(entry.agent, "spawn_manager", None)
                for handle in getattr(spawn_manager, "spawned_handles", {}).values():
                    teammate = getattr(handle, "agent_ref", None)
                    teammate_backend = getattr(teammate, "team_backend", None)
                    if teammate is not None and teammate_backend is not None:
                        self._unbind_organization_workspace(teammate, teammate_backend)
                self._set_owner_lifecycle_prompt(entry.agent, is_owner=False)
                harness = getattr(entry.agent, "harness", None)
                remove_tool = getattr(harness, "remove_tool", None)
                if callable(remove_tool):
                    from openjiuwen.agent_teams.organization.tools import ORG_LEADER_TOOL_NAMES

                    for tool_name in ORG_LEADER_TOOL_NAMES:
                        remove_tool(tool_name)
                self._team_organizations.pop(key, None)

            deleted = await manager.dissolve_organization()
            if self._expert_team_launcher is not None:
                for team_id in sorted(expert_team_ids):
                    await self._expert_team_launcher.stop(team_id=team_id, session_id=session_id)
            if self._summary_team_launcher is not None and summary_team is not None and summary_team.summary_team_id:
                await self._summary_team_launcher.stop(
                    team_id=summary_team.summary_team_id,
                    session_id=session_id,
                )
            self._summary_team_locks.pop((session_id, organization_id), None)
            remove_process_org_manager(
                organization_id=organization_id,
                db=owner_backend.db,
                session_id=session_id,
            )
            from openjiuwen.agent_teams.organization.workspace import (
                remove_organization_workspace_manager,
            )

            remove_organization_workspace_manager(organization_id, session_id)
            result = {
                "organization_id": organization_id,
                "dissolved_team_ids": sorted(member_team_ids),
                "deleted": deleted,
            }
            logger.info(
                "organization dissolved: org=%s owner=%s teams=%s deleted=%s",
                organization_id,
                owner_team_id,
                result["dissolved_team_ids"],
                deleted,
            )
            return result

    async def get_organization(self, *, organization_id: str, team_id: str, session_id: str) -> OrganizationSpec | None:
        """Read organization state through an active member's shared database."""

        _, backend = await self._resolve_leader(team_id, session_id)
        manager = get_process_org_manager(
            organization_id=organization_id,
            db=backend.db,
            messager=backend.messager,
            session_id=session_id,
        )
        organization = await manager.get_organization()
        if organization is None:
            return None
        if team_id not in {leader.team_id for leader in organization.leaders}:
            raise ValueError("team is not a member of this organization")
        return organization

    async def list_available_teams(self, *, session_id: str) -> list[dict[str, Any]]:
        """Return active same-session teams that can be invited by an owner leader."""

        teams = await self._team_runtime_manager.pool.teams_for_session(session_id)
        available: list[dict[str, Any]] = []
        for entry in teams:
            backend = getattr(entry.agent, "team_backend", None)
            if backend is None or not getattr(backend, "is_leader", False):
                continue
            available.append(
                {
                    "team_id": backend.team_name,
                    "leader_id": self._leader_id(entry.agent, backend),
                    "state": entry.state.value,
                    "capabilities": self._capabilities(entry.agent),
                    "organization_id": getattr(getattr(backend, "org_task_manager", None), "organization_id", None),
                }
            )
        return available

    async def list_configured_teams(self, *, session_id: str) -> list[dict[str, Any]]:
        """Return host-registered dormant team templates for this session."""

        if self._configured_team_provider is None:
            return []
        return await self._configured_team_provider(session_id)

    async def list_expert_groups(self, *, capabilities: set[str] | None = None) -> list[dict[str, Any]]:
        """List host-validated AgentGroup templates; does not create Teams."""

        self._ensure_expert_adapters()
        if self._expert_group_catalog is None:
            return []
        return [descriptor.to_dict() for descriptor in self._expert_group_catalog.list(capabilities=capabilities)]

    async def create_and_invite_expert_team(
        self,
        *,
        organization_id: str,
        owner_team_id: str,
        agent_group_name: str,
        session_id: str,
        display_name: str | None = None,
    ) -> dict[str, Any]:
        """Launch an expert Team from an AgentGroup package and invite it."""

        self._ensure_expert_adapters()
        if self._expert_team_launcher is None:
            raise ValueError("expert team launcher is not configured")
        group_name = str(agent_group_name or "").strip()
        if not group_name:
            raise ValueError("agent_group_name is required")

        _, owner_backend = await self._resolve_leader(owner_team_id, session_id)
        manager = get_process_org_manager(
            organization_id=organization_id,
            db=owner_backend.db,
            messager=owner_backend.messager,
            session_id=session_id,
        )
        organization = await manager.get_organization()
        if organization is None:
            raise ValueError(f"organization not found: {organization_id}")
        if organization.owner_team_id != owner_team_id:
            raise ValueError("only the organization owner team can create expert teams")

        launched = await self._expert_team_launcher.launch(
            organization_id=organization_id,
            agent_group_name=group_name,
            session_id=session_id,
            display_name=display_name,
            share_db_from_team_id=owner_team_id,
        )
        try:
            organization = await self.invite_team(
                organization_id=organization_id,
                inviter_team_id=owner_team_id,
                target_team_id=launched.team_id,
                session_id=session_id,
            )
        except Exception:
            logger.error(
                "invite expert team %s failed for org %s (group=%s); stopping launched team",
                launched.team_id,
                organization_id,
                group_name,
                exc_info=True,
            )
            await self._expert_team_launcher.stop(
                team_id=launched.team_id,
                session_id=session_id,
            )
            raise

        return {
            "organization": organization.model_dump(),
            **launched.to_dict(),
            "agent_group_name": launched.agent_group_name or group_name,
        }

    async def _bind_team(self, *, agent: "TeamAgent", backend: TeamBackend, manager: Any, session_id: str) -> None:
        backend.org_task_manager = manager.task_pool
        backend.org_message_service = manager.message_service
        from openjiuwen.agent_teams.organization.workspace import (
            get_organization_workspace_manager,
        )

        workspace_manager = get_organization_workspace_manager(manager.organization_id, session_id)
        await workspace_manager.initialize()
        workspace_manager.ensure_team_directory(backend.team_name)
        self._bind_organization_workspace(
            agent=agent,
            backend=backend,
            workspace_manager=workspace_manager,
            organization_id=manager.organization_id,
            session_id=session_id,
        )
        # Phase one supports one process.  Teammates spawned before their team
        # joins the organization therefore need the mount immediately; members
        # spawned later inherit the metadata above through AgentConfigurator.
        spawn_manager = getattr(agent, "spawn_manager", None)
        for handle in getattr(spawn_manager, "spawned_handles", {}).values():
            teammate = getattr(handle, "agent_ref", None)
            teammate_backend = getattr(teammate, "team_backend", None)
            if teammate is None or teammate_backend is None:
                continue
            self._bind_organization_workspace(
                agent=teammate,
                backend=teammate_backend,
                workspace_manager=workspace_manager,
                organization_id=manager.organization_id,
                session_id=session_id,
            )
        self._team_organizations[(session_id, backend.team_name)] = manager.organization_id
        organization = await manager.get_organization()
        self._set_owner_lifecycle_prompt(
            agent,
            is_owner=organization is not None and organization.owner_team_id == backend.team_name,
        )
        self._set_collaboration_prompt(agent)
        is_summary_team = self._is_summary_team(agent)
        self._set_summary_team_prompt(agent, is_summary_team=is_summary_team)
        leader_id = self._leader_id(agent, backend)
        await manager.register_leader(
            team_id=backend.team_name,
            leader_id=leader_id,
            leader_member_name=backend.leader_member_name or leader_id,
            capabilities=self._capabilities(agent),
        )
        if not is_summary_team:
            await self.ensure_control_tools(agent, session_id=session_id)

        harness = agent.harness
        add_tool = getattr(harness, "add_tool", None)
        if callable(add_tool):
            from openjiuwen.agent_teams.organization.tools import (
                create_org_leader_tools,
                create_summary_leader_tools,
            )

            tools = (
                create_summary_leader_tools(
                    manager=manager.task_pool,
                    message_service=manager.message_service,
                    team_id=backend.team_name,
                    leader_id=leader_id,
                    runtime_manager=self,
                    session_id=session_id,
                )
                if is_summary_team
                else create_org_leader_tools(
                    manager=manager.task_pool,
                    message_service=manager.message_service,
                    team_id=backend.team_name,
                    leader_id=leader_id,
                    runtime_manager=self,
                    session_id=session_id,
                )
            )
            for tool in tools:
                add_tool(tool)
        if is_summary_team:
            add_rail = getattr(harness, "add_rail", None)
            find_rail = getattr(harness, "find_rails_by_type", None)
            existing = find_rail((_SummaryCloseoutRail,)) if callable(find_rail) else []
            if callable(add_rail) and not existing:
                add_rail(_SummaryCloseoutRail(backend.team_name))
        await self._subscribe_team_events(
            backend,
            manager,
            session_id,
            capabilities=set(self._capabilities(agent)),
        )
        await self._ensure_unclaimed_service(manager, session_id)

    def _bind_organization_workspace(
        self,
        *,
        agent: "TeamAgent",
        backend: TeamBackend,
        workspace_manager: Any,
        organization_id: str,
        session_id: str,
    ) -> None:
        """Attach the shared workspace to one local Team member."""

        backend.organization_workspace_manager = workspace_manager
        spec = getattr(agent, "spec", None)
        if spec is not None:
            metadata = dict(getattr(spec, "metadata", None) or {})
            metadata.update(
                {
                    "organization_id": organization_id,
                    "organization_session_id": session_id,
                }
            )
            spec.metadata = metadata
        harness = getattr(agent, "harness", None)
        member_workspace = getattr(harness, "workspace", None)
        workspace_root = getattr(member_workspace, "root_path", None)
        if workspace_root:
            workspace_manager.mount_into_workspace(workspace_root)
        mounted_key = (organization_id, session_id)
        add_rail = getattr(harness, "add_rail", None)
        if callable(add_rail) and backend.organization_workspace_rail_key != mounted_key:
            from openjiuwen.agent_teams.organization.workspace_rail import (
                OrganizationWorkspaceRail,
            )

            add_rail(
                OrganizationWorkspaceRail(
                    workspace_manager,
                    team_id=backend.team_name,
                    member_name=agent.member_name or backend.member_name,
                    summary_team=self._is_summary_team(agent),
                )
            )
            backend.organization_workspace_rail_key = mounted_key

    @staticmethod
    def _unbind_organization_workspace(agent: "TeamAgent", backend: TeamBackend) -> None:
        """Unmount the shared workspace from one local Team member."""

        workspace_manager = getattr(backend, "organization_workspace_manager", None)
        harness = getattr(agent, "harness", None)
        member_workspace = getattr(harness, "workspace", None)
        workspace_root = getattr(member_workspace, "root_path", None)
        if workspace_manager is not None and workspace_root:
            workspace_manager.unmount_from_workspace(workspace_root)
        backend.organization_workspace_manager = None
        spec = getattr(agent, "spec", None)
        if spec is not None:
            metadata = dict(getattr(spec, "metadata", None) or {})
            metadata.pop("organization_id", None)
            metadata.pop("organization_session_id", None)
            spec.metadata = metadata

    async def _ensure_unclaimed_service(self, manager: Any, session_id: str) -> None:
        key = (session_id, manager.organization_id)
        service = self._unclaimed_services.get(key)
        if service is None:
            organization = await manager.get_organization()

            async def notify(message: dict[str, Any]) -> None:
                team_id = message["to_team_id"]
                if self._team_organizations.get((session_id, team_id)) != manager.organization_id:
                    return
                entry = await self._team_runtime_manager.pool.get(team_id)
                if entry is None or entry.current_session_id != session_id:
                    return
                message_key = (session_id, team_id, message["message_id"])
                if message_key in self._scheduled_leader_messages:
                    self._ensure_leader_turn_worker(team_id, session_id)
                    return
                self._scheduled_leader_messages.add(message_key)
                self._schedule_leader_turn(
                    team_id=team_id,
                    session_id=session_id,
                    prompt="",
                    message_key=message_key,
                    unclaimed_notification=(key, message),
                )

            service = OrgUnclaimedTaskService(
                manager,
                notify,
                organization.unclaimed_task_policy.scan_interval_seconds,
            )
            self._unclaimed_services[key] = service
        service.start()

    async def release_team(self, *, team_id: str, session_id: str) -> None:
        """Release background work before the last bound team or its database stops."""
        key = (session_id, team_id)
        organization_id = self._team_organizations.pop(key, None)
        self._summary_closeout_attempts = {
            attempt_key: attempts
            for attempt_key, attempts in self._summary_closeout_attempts.items()
            if attempt_key[:2] != key
        }
        self._summary_member_failures = {
            failure_key: failures for failure_key, failures in self._summary_member_failures.items()
            if failure_key[:2] != key
        }
        worker = self._leader_turn_workers.pop(key, None)
        if worker is not None and worker is not asyncio.current_task():
            worker.cancel()
            await asyncio.gather(worker, return_exceptions=True)
        queue = self._leader_turn_queues.pop(key, deque())
        self._clear_leader_turn_queue(queue)
        if organization_id:
            await self._release_org_subscriber(organization_id, session_id, team_id)
        if organization_id and not any(
            session == session_id and org == organization_id for (session, _), org in self._team_organizations.items()
        ):
            service = self._unclaimed_services.pop((session_id, organization_id), None)
            if service is not None:
                await service.stop()

    async def close(self) -> None:
        """Stop organization-owned tasks before host teardown."""
        services = list(self._unclaimed_services.values())
        self._unclaimed_services.clear()
        for service in services:
            await service.stop()
        workers = [worker for worker in self._leader_turn_workers.values() if worker is not asyncio.current_task()]
        for worker in workers:
            worker.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        self._leader_turn_workers.clear()
        self._leader_turn_queues.clear()
        self._scheduled_leader_messages.clear()
        self._scheduled_parent_reviews.clear()
        self._scheduled_summary_executions.clear()
        self._summary_closeout_attempts.clear()
        self._summary_member_failures.clear()
        for session_id, organization_id, team_id in tuple(self._org_subscribers):
            await self._release_org_subscriber(organization_id, session_id, team_id)

    @staticmethod
    def _set_owner_lifecycle_prompt(agent: "TeamAgent", *, is_owner: bool) -> None:
        """Keep the owner-only organization lifecycle rule in the live system prompt."""

        harness = getattr(agent, "harness", None)
        prompt_builder = getattr(harness, "system_prompt_builder", None)
        if prompt_builder is None:
            return
        prompt_builder.remove_section(_ORG_OWNER_LIFECYCLE_SECTION)
        if not is_owner:
            return
        from openjiuwen.harness.prompts.builder import PromptSection

        prompt_builder.add_section(
            PromptSection(
                name=_ORG_OWNER_LIFECYCLE_SECTION,
                content=_ORG_OWNER_LIFECYCLE_PROMPT,
                priority=75,
            )
        )

    @staticmethod
    def _set_collaboration_prompt(agent: "TeamAgent") -> None:
        """Add the small shared rule for auditable leader communication."""

        harness = getattr(agent, "harness", None)
        prompt_builder = getattr(harness, "system_prompt_builder", None)
        if prompt_builder is None:
            return
        prompt_builder.remove_section(_ORG_COLLABORATION_SECTION)
        from openjiuwen.harness.prompts.builder import PromptSection

        prompt_builder.add_section(
            PromptSection(
                name=_ORG_COLLABORATION_SECTION,
                content=_ORG_COLLABORATION_PROMPT,
                priority=70,
            )
        )

    @staticmethod
    def _is_summary_team(agent: "TeamAgent") -> bool:
        """Return whether the host marked this agent as the organization Summary Team."""

        metadata = getattr(getattr(agent, "spec", None), "metadata", None)
        return isinstance(metadata, dict) and metadata.get("summary_team") is True

    @staticmethod
    def _set_summary_team_prompt(agent: "TeamAgent", *, is_summary_team: bool) -> None:
        """Add Summary Team-only instructions and remove them from all ordinary Teams."""

        harness = getattr(agent, "harness", None)
        prompt_builder = getattr(harness, "system_prompt_builder", None)
        if prompt_builder is None:
            return
        prompt_builder.remove_section(_ORG_SUMMARY_TEAM_SECTION)
        if not is_summary_team:
            return
        from openjiuwen.harness.prompts.builder import PromptSection

        prompt_builder.add_section(
            PromptSection(
                name=_ORG_SUMMARY_TEAM_SECTION,
                content=_ORG_SUMMARY_TEAM_PROMPT,
                priority=85,
            )
        )

    async def ensure_team_binding(
        self,
        *,
        team_id: str,
        session_id: str,
        agent: "TeamAgent" | None = None,
    ) -> bool:
        """Restore organization bindings after a host recreates a team harness.

        Configured dormant teams are intentionally created before their first LLM
        turn.  The normal Team runner may replace that provisional agent on the
        first actual invocation, so bindings must be mounted on the live agent.
        """

        if agent is None:
            agent, backend = await self._resolve_leader(team_id, session_id)
        else:
            backend = getattr(agent, "team_backend", None)
            if backend is None or not getattr(backend, "is_leader", False):
                return False
        if not getattr(agent.spec, "enable_organization", True):
            return False

        organization_id = self._team_organizations.get((session_id, team_id))
        if not organization_id:
            # ``_team_organizations`` disappears on a host restart while the
            # organization tables remain durable.  Rebuild the binding from
            # the leader membership record instead of silently falling back to
            # ordinary team-only tools.
            organization_ids = await OrgTaskManager.find_organization_ids_for_team(backend.db, team_id)
            if len(organization_ids) != 1:
                logger.warning(
                    "ensure_team_binding failed: team %s maps to %s org(s) %s",
                    team_id,
                    len(organization_ids),
                    organization_ids,
                )
                return False
            organization_id = organization_ids[0]

        manager = get_process_org_manager(
            organization_id=organization_id,
            db=backend.db,
            messager=backend.messager,
            session_id=session_id,
        )
        if await manager.get_organization() is None:
            logger.warning(
                "ensure_team_binding failed: organization %s not found for team %s",
                organization_id,
                team_id,
            )
            return False
        await self._bind_team(agent=agent, backend=backend, manager=manager, session_id=session_id)
        await self._resume_assignable_tasks(
            manager=manager,
            team_id=team_id,
            session_id=session_id,
            capabilities=set(self._capabilities(agent)),
        )
        return True

    async def _resume_assignable_tasks(
        self,
        *,
        manager: Any,
        team_id: str,
        session_id: str,
        capabilities: set[str],
    ) -> None:
        """Recover assignable work and durable organization follow-ups.

        Topic delivery is intentionally best effort.  The task pool is the
        durable source of truth, so a freshly bound or recovered leader must
        also scan matching OPEN tasks and §7.3 parent follow-ups rather than
        relying only on past events.
        """

        await self._resume_claimed_tasks(manager=manager, team_id=team_id, session_id=session_id)
        await self._resume_summary_executions(manager=manager, team_id=team_id, session_id=session_id)
        for message in await manager.message_service.list_leader_messages(
            team_id=team_id,
            unread_only=True,
        ):
            if message["from_team_id"] == "__organization__":
                # The deadline scanner replays these with phase-aware prompts.
                continue
            metadata = message.get("metadata") or {}
            if metadata.get("kind") == "summary_completed":
                self._schedule_summary_completion_delivery_turn(
                    team_id=team_id,
                    session_id=session_id,
                    message_id=message["message_id"],
                    organization_id=manager.organization_id,
                    metadata=metadata,
                )
                continue
            self._schedule_leader_message_turn(
                team_id=team_id,
                session_id=session_id,
                message_id=message["message_id"],
                from_team_id=message["from_team_id"],
                organization_id=manager.organization_id,
            )
        await self._schedule_matching_open_claims(
            manager=manager,
            team_id=team_id,
            session_id=session_id,
            capabilities=capabilities,
            completed_task_id=None,
        )
        await self._resume_parent_followups(
            manager=manager,
            team_id=team_id,
            session_id=session_id,
        )

    async def _resume_summary_executions(self, *, manager: Any, team_id: str, session_id: str) -> None:
        """Recover unfinished Summary Team work from durable execution state on a team rebind."""

        executions = await manager.task_pool.list_incomplete_summary_executions()
        for execution in executions:
            root = await manager.task_pool.get_task(execution.root_task_id)
            if root is None:
                continue
            if execution.status == OrgSummaryExecutionStatus.PROVISIONING.value:
                if root.assignment.team_id != team_id or root.aggregation is None:
                    continue
                controller_leader_id = root.aggregation.controller_leader_id
                if not controller_leader_id:
                    continue
                logger.info(
                    "summary resume: re-provisioning execution %s (task=%s root=%s owner=%s)",
                    execution.execution_id,
                    execution.summary_task_id,
                    execution.root_task_id,
                    team_id,
                )
                try:
                    summary_team_id, _ = await self.ensure_summary_team(
                        organization_id=manager.organization_id,
                        root_team_id=team_id,
                        session_id=session_id,
                    )
                    bound = await manager.task_pool.bind_summary_execution(
                        summary_task_id=execution.summary_task_id,
                        summary_team_id=summary_team_id,
                    )
                    if not bound.ok:
                        raise RuntimeError(bound.reason or "summary execution binding failed")
                except Exception as exc:
                    reason = f"summary team provisioning failed during recovery: {exc}"
                    logger.error(
                        "summary resume: recover failed for execution %s: %s",
                        execution.execution_id,
                        exc,
                        exc_info=True,
                    )
                    await manager.task_pool.fail_summary_execution(
                        summary_task_id=execution.summary_task_id,
                        failure_reason=reason,
                    )
                    await manager.task_pool.mark_summary_team_failed()
                    await self.notify_summary_provision_failure(
                        organization_id=manager.organization_id,
                        root_team_id=team_id,
                        root_leader_id=controller_leader_id,
                        summary_task_id=execution.summary_task_id,
                        reason=reason,
                        session_id=session_id,
                    )
                continue
            if execution.summary_team_id != team_id:
                continue
            summary_task = await manager.task_pool.get_task(execution.summary_task_id)
            if (
                execution.status == OrgSummaryExecutionStatus.RUNNING.value
                and summary_task is not None
                and summary_task.status in {OrgTaskStatus.DELEGATED, OrgTaskStatus.IN_PROGRESS}
            ):
                logger.info(
                    "summary resume: scheduling turn for running summary %s on team %s",
                    summary_task.task_id,
                    team_id,
                )
                self.schedule_summary_execution(
                    team_id=team_id,
                    session_id=session_id,
                    task_id=summary_task.task_id,
                    organization_id=manager.organization_id,
                    execution_id=execution.execution_id,
                    root_task_id=execution.root_task_id,
                )

        # This covers a crash after sources became accepted but before their
        # TASK_DELEGATED event reached the Summary Team.
        await manager.task_pool.activate_ready_summary_tasks()

    async def _resume_claimed_tasks(self, *, manager: Any, team_id: str, session_id: str) -> None:
        """Resume work claimed before a process or harness recovery."""

        for task in await manager.task_pool.list_tasks_for_team(team_id, include_open=False):
            if task.status is OrgTaskStatus.CLAIMED:
                self._schedule_claimed_task_execution_turn(
                    team_id=team_id,
                    session_id=session_id,
                    task_id=task.task_id,
                    organization_id=manager.organization_id,
                )

    async def _resume_parent_followups(
        self,
        *,
        manager: Any,
        team_id: str,
        session_id: str,
    ) -> None:
        """Rebuild §7.3 leader turns from durable task/review state after rebind.

        Event delivery is best-effort; PENDING reviews, unrepaired FAILED/REJECTED
        children, and completeable parents must be rediscovered from the task pool.
        """
        organization_id = manager.organization_id
        parent_ids: set[str] = set()

        for item in await manager.task_pool.list_pending_reviews(team_id=team_id):
            task_brief = item.get("task") or {}
            child_task_id = task_brief.get("task_id")
            parent_task_id = task_brief.get("parent_task_id")
            if not child_task_id or not parent_task_id:
                continue
            parent_ids.add(parent_task_id)
            self._schedule_parent_review_turn(
                team_id=team_id,
                session_id=session_id,
                child_task_id=child_task_id,
                parent_task_id=parent_task_id,
                organization_id=organization_id,
            )

        for task in await manager.task_pool.list_tasks_created_by_team(team_id=team_id):
            if task.task_type == "organization.summary":
                # Summary Tasks are root siblings with bound sources, not
                # hierarchical parents with direct child tasks.
                continue
            if (
                task.unclaimed is not None
                and task.failure_code is OrgTaskFailureCode.EXPIRED
                and task.unclaimed.closed_reason in {"description_update_timeout", "post_update_claim_timeout"}
            ):
                continue
            if not task.parent_task_id:
                if task.status not in _PARENT_RESUME_TERMINAL_STATUSES:
                    parent_ids.add(task.task_id)
                continue
            parent_ids.add(task.parent_task_id)
            review = await manager.task_pool.get_task_review(task.task_id)
            if not _is_supersedable_task(task.status.value, review):
                continue
            if await manager.task_pool.has_accepted_or_active_repair(
                parent_task_id=task.parent_task_id,
                repairs_target=task.task_id,
            ):
                continue
            if task.status is OrgTaskStatus.FAILED:
                self._schedule_parent_child_failed_turn(
                    team_id=team_id,
                    session_id=session_id,
                    child_task_id=task.task_id,
                    parent_task_id=task.parent_task_id,
                    organization_id=organization_id,
                    failure_code=(
                        task.failure_code.value
                        if task.failure_code is not None
                        else OrgTaskFailureCode.EXECUTION_FAILED.value
                    ),
                    failure_reason=task.failure_reason or "recovered failed child",
                    repairs_task_id=self._original_repairs_target(task),
                )
                continue
            review_status = review.review_status.value if review is not None else None
            if review_status in {
                OrgTaskReviewStatus.REJECTED.value,
                OrgTaskReviewStatus.NEEDS_REVISION.value,
            }:
                self._schedule_parent_repair_turn(
                    team_id=team_id,
                    session_id=session_id,
                    child_task_id=task.task_id,
                    parent_task_id=task.parent_task_id,
                    organization_id=organization_id,
                    review_status=review_status,
                    repairs_task_id=self._original_repairs_target(task),
                )

        for parent_task_id in parent_ids:
            parent = await manager.task_pool.get_task(parent_task_id)
            if parent is None or parent.status in _PARENT_RESUME_TERMINAL_STATUSES:
                continue
            aggregation = parent.aggregation
            is_root = _is_root_task_row(parent)
            is_summary_aggregation = aggregation is not None and aggregation.mode is OrgTaskAggregationMode.SUMMARY_TEAM
            if is_root and is_summary_aggregation and aggregation.summary_task_id:
                # A Summary Execution already owns final delivery for this root.
                continue
            if not await manager.task_pool.can_complete_parent_task(
                parent_task_id=parent_task_id,
                team_id=team_id,
            ):
                continue
            self._schedule_parent_ready_turn(
                team_id=team_id,
                session_id=session_id,
                parent_task_id=parent_task_id,
                organization_id=organization_id,
            )

    async def _subscribe_team_events(
        self,
        backend: TeamBackend,
        manager: Any,
        session_id: str,
        *,
        capabilities: set[str],
    ) -> None:
        backend_messager = backend.messager
        if backend_messager is None:
            return
        subscriber_key = (session_id, manager.organization_id, backend.team_name)
        if self._org_subscriber_sources.get(subscriber_key) not in (None, id(backend_messager)):
            await self._release_org_subscriber(manager.organization_id, session_id, backend.team_name)
        messager = self._org_subscribers.get(subscriber_key)
        if messager is None:
            # InProcessMessager keys topic subscribers by node_id. Team leaders
            # commonly share the same member name, so organization listeners
            # need their own organization/team-scoped subscriber identity.
            messager = (
                InProcessMessager(
                    config=MessagerTransportConfig(
                        node_id=f"org:{session_id}:{manager.organization_id}:{backend.team_name}"
                    )
                )
                if isinstance(backend_messager, InProcessMessager)
                else backend_messager
            )
            self._org_subscribers[subscriber_key] = messager
            self._org_subscriber_sources[subscriber_key] = id(backend_messager)

        async def _on_task_event(message: Any) -> None:
            event = OrgEventMessage.model_validate(message.model_dump()).get_payload()
            if isinstance(event, (OrgTaskCreatedEvent, OrgTaskDescriptionRevisedEvent)):
                if event.team_id == backend.team_name:
                    return
                task = await manager.task_pool.get_task(event.task_id)
                if task is not None and task.task_type == "organization.summary":
                    return
                required = set(task.required_capabilities) if task is not None else set()
                if not required or not required.issubset(capabilities):
                    return
                self._schedule_claim_turn(
                    team_id=backend.team_name,
                    session_id=session_id,
                    task_id=event.task_id,
                    organization_id=manager.organization_id,
                )
                return
            if isinstance(event, OrgTaskClaimedEvent):
                if event.claimed_by_team_id != backend.team_name:
                    return
                self._schedule_claimed_task_execution_turn(
                    team_id=backend.team_name,
                    session_id=session_id,
                    task_id=event.task_id,
                    organization_id=manager.organization_id,
                )
                return
            if isinstance(event, OrgTaskCompletedEvent):
                # Completion is a second durable opportunity to claim matching
                # OPEN tasks and wake a parent review if its separate review
                # event was not delivered.
                await self._schedule_matching_open_claims(
                    manager=manager,
                    team_id=backend.team_name,
                    session_id=session_id,
                    capabilities=capabilities,
                    completed_task_id=event.task_id,
                )
                task = await manager.task_pool.get_task(event.task_id)
                if task is None or not task.parent_task_id:
                    return
                if task.created_by.team_id != backend.team_name:
                    return
                review = await manager.task_pool.get_task_review(event.task_id)
                if review is None or review.review_status is not OrgTaskReviewStatus.PENDING:
                    return
                self._schedule_parent_review_turn(
                    team_id=backend.team_name,
                    session_id=session_id,
                    child_task_id=event.task_id,
                    parent_task_id=task.parent_task_id,
                    organization_id=manager.organization_id,
                )
                return
            if isinstance(event, OrgTaskFailedEvent):
                task = await manager.task_pool.get_task(event.task_id)
                if self._is_unclaimed_expiration(task, event):
                    # The durable expiration inbox request also covers root tasks.
                    return
                if task is None or not task.parent_task_id:
                    return
                if task.created_by.team_id != backend.team_name:
                    return
                self._schedule_parent_child_failed_turn(
                    team_id=backend.team_name,
                    session_id=session_id,
                    child_task_id=event.task_id,
                    parent_task_id=task.parent_task_id,
                    organization_id=manager.organization_id,
                    failure_code=event.failure_code,
                    failure_reason=event.failure_reason,
                    repairs_task_id=self._original_repairs_target(task),
                )
                return
            if isinstance(event, OrgTaskReviewRequestedEvent):
                if event.reviewer_team_id != backend.team_name:
                    return
                self._schedule_parent_review_turn(
                    team_id=backend.team_name,
                    session_id=session_id,
                    child_task_id=event.task_id,
                    parent_task_id=event.parent_task_id,
                    organization_id=manager.organization_id,
                )
                return
            if not isinstance(event, OrgTaskReviewedEvent):
                return
            if event.team_id != backend.team_name:
                return
            task = await manager.task_pool.get_task(event.task_id)
            if task is None or not task.parent_task_id:
                return
            if event.review_status in {
                OrgTaskReviewStatus.REJECTED.value,
                OrgTaskReviewStatus.NEEDS_REVISION.value,
            }:
                self._schedule_parent_repair_turn(
                    team_id=backend.team_name,
                    session_id=session_id,
                    child_task_id=event.task_id,
                    parent_task_id=task.parent_task_id,
                    organization_id=manager.organization_id,
                    review_status=event.review_status,
                    repairs_task_id=self._original_repairs_target(task),
                )
                return
            if event.review_status != OrgTaskReviewStatus.ACCEPTED.value:
                return
            if not await manager.task_pool.can_complete_parent_task(
                parent_task_id=task.parent_task_id,
                team_id=backend.team_name,
            ):
                return
            self._schedule_parent_ready_turn(
                team_id=backend.team_name,
                session_id=session_id,
                parent_task_id=task.parent_task_id,
                organization_id=manager.organization_id,
            )

        async def _on_inbox_event(message: Any) -> None:
            event_type = getattr(message, "event_type", None)
            if event_type == OrgEvent.TASK_DELEGATED:
                event = OrgEventMessage.model_validate(message.model_dump()).get_payload()
                if not isinstance(event, OrgTaskDelegatedEvent):
                    return
                task = await manager.task_pool.get_task(event.task_id)
                if task is not None and task.task_type == "organization.summary":
                    execution = await manager.task_pool.get_summary_execution(summary_task_id=event.task_id)
                    if execution is None:
                        return
                    self.schedule_summary_execution(
                        team_id=backend.team_name,
                        session_id=session_id,
                        task_id=event.task_id,
                        organization_id=manager.organization_id,
                        execution_id=execution.execution_id,
                        root_task_id=execution.root_task_id,
                    )
                    return
                self._schedule_delegated_turn(
                    team_id=backend.team_name,
                    session_id=session_id,
                    task_id=event.task_id,
                    organization_id=manager.organization_id,
                )
                return
            if event_type == OrgEvent.LEADER_MESSAGE:
                payload = getattr(message, "payload", None) or {}
                message_id = payload.get("message_id")
                if not message_id:
                    return
                if (session_id, backend.team_name, message_id) in self._scheduled_leader_messages:
                    self._ensure_leader_turn_worker(backend.team_name, session_id)
                    return
                persisted = await manager.message_service.get_leader_message(
                    message_id=message_id,
                    team_id=backend.team_name,
                )
                if persisted is None or persisted["handled_at"] is not None:
                    return
                metadata = persisted.get("metadata") or {}
                if metadata.get("kind") == "summary_submission_blocked":
                    message_key = (session_id, backend.team_name, message_id)
                    self._scheduled_leader_messages.add(message_key)
                    self._schedule_leader_turn(
                        team_id=backend.team_name,
                        session_id=session_id,
                        prompt=(f"Summary submission blocker notice {message_id} arrived. "
                                "Read it with org_get_leader_message, acknowledge it with org_ack_leader_message, "
                                "and report the concrete blocker to the user now. Do not claim completion, "
                                "poll, restart the Summary Team or launch new research."),
                        message_key=message_key,
                        relay_source="org_root_delivery",
                    )
                    return
                if metadata.get("kind") == "summary_completed":
                    self._schedule_summary_completion_delivery_turn(
                        team_id=backend.team_name,
                        session_id=session_id,
                        message_id=message_id,
                        organization_id=manager.organization_id,
                        metadata=metadata,
                    )
                    return
                self._schedule_leader_message_turn(
                    team_id=backend.team_name,
                    session_id=session_id,
                    message_id=message_id,
                    from_team_id=str(payload.get("from_team_id") or message.sender_id or ""),
                    organization_id=manager.organization_id,
                )

        await self._subscribe_once(
            messager=messager,
            topic=OrgTopic.TASK,
            session_id=session_id,
            organization_id=manager.organization_id,
            team_id=backend.team_name,
            handler=_on_task_event,
        )
        await self._subscribe_once(
            messager=messager,
            topic=OrgTopic.TEAM_INBOX,
            session_id=session_id,
            organization_id=manager.organization_id,
            team_id=backend.team_name,
            handler=_on_inbox_event,
        )

    async def _release_org_subscriber(self, organization_id: str, session_id: str, team_id: str) -> None:
        """Unsubscribe one team's organization-only listener without touching its Team transport."""
        messager = self._org_subscribers.pop((session_id, organization_id, team_id), None)
        self._org_subscriber_sources.pop((session_id, organization_id, team_id), None)
        for subscribed in tuple(self._subscribed_topics):
            subscribed_org, subscribed_session, subscribed_team, topic, messager_id = subscribed
            if (subscribed_org, subscribed_session, subscribed_team) != (organization_id, session_id, team_id):
                continue
            unsubscribe = getattr(messager, "unsubscribe", None)
            if callable(unsubscribe) and messager_id == id(messager):
                await unsubscribe(
                    topic.build(session_id, organization_id, team_id if topic is OrgTopic.TEAM_INBOX else None)
                )
            self._subscribed_topics.discard(subscribed)

    @staticmethod
    def _is_unclaimed_expiration(task: Any, event: OrgTaskFailedEvent) -> bool:
        """Unclaimed expiry has its own durable creator notification path."""

        if task is None or task.unclaimed is None or event.failure_code != "EXPIRED":
            return False
        return task.unclaimed.closed_reason in {
            "description_update_timeout",
            "post_update_claim_timeout",
        }

    async def _subscribe_once(
        self,
        *,
        messager: Any,
        topic: OrgTopic,
        session_id: str,
        organization_id: str,
        team_id: str,
        handler: Any,
    ) -> None:
        key = (organization_id, session_id, team_id, topic, id(messager))
        if key in self._subscribed_topics:
            return
        topic_id = topic.build(session_id, organization_id, team_id if topic is OrgTopic.TEAM_INBOX else None)
        await messager.subscribe(topic_id, handler)
        self._subscribed_topics.add(key)

    async def _schedule_matching_open_claims(
        self,
        *,
        manager: Any,
        team_id: str,
        session_id: str,
        capabilities: set[str],
        completed_task_id: str | None,
    ) -> None:
        for task in await manager.task_pool.list_open_tasks():
            if completed_task_id is not None and task.task_id == completed_task_id:
                continue
            if task.task_type == "organization.summary":
                continue
            required = set(task.required_capabilities)
            if required and required.issubset(capabilities):
                self._schedule_claim_turn(
                    team_id=team_id,
                    session_id=session_id,
                    task_id=task.task_id,
                    organization_id=manager.organization_id,
                    trigger_task_id=completed_task_id,
                )

    def _schedule_claim_turn(
        self,
        *,
        team_id: str,
        session_id: str,
        task_id: str,
        organization_id: str,
        trigger_task_id: str | None = None,
    ) -> None:
        trigger_context = (
            f" Task {trigger_task_id} just completed, so re-evaluate this open task now." if trigger_task_id else ""
        )
        prompt = (
            f"Organization task {task_id} is available in {organization_id}.{trigger_context} "
            "Inspect it with org_view_tasks(action='get'). If every required capability is present "
            "in your team, you MUST call org_claim_task for this task in this turn. Do not leave a "
            "capability-matched task OPEN merely because another team's artifact is not ready: claim "
            "it first, prepare any independent work, and use org_view_tasks to wait for dependencies "
            "before starting dependent validation. When the defined scope has been executed, produce "
            "one final result or report and call org_update_task(action='complete') in the same "
            "workflow, including failures and blockers in its output. Do not wait for another team to "
            "fix a reported issue, and do not create an open-ended sequence of extra verification tasks "
            "unless the parent task explicitly requests it. Only skip the claim when a required capability "
            "is actually absent or the claim fails because another team already claimed it."
        )
        self._schedule_leader_turn(
            team_id=team_id,
            session_id=session_id,
            prompt=prompt,
            open_claim_task_id=task_id,
        )

    def _schedule_delegated_turn(self, *, team_id: str, session_id: str, task_id: str, organization_id: str) -> None:
        prompt = (
            f"Organization task {task_id} in {organization_id} was delegated to your team. "
            "Inspect it with org_view_tasks(action='get'), then use org_update_task(action='start') "
            "when you are ready. If an independent part requires another organization team's "
            "capabilities, keep this parent task assigned to your team and create a focused OPEN child "
            f"with org_create_task(parent_task_id='{task_id}'). Give each child a clear scope, "
            "acceptance criteria, and only the capabilities it needs; do not set delegated_to_team_id. "
            "Track children with org_view_child_tasks and do not complete the parent until its direct "
            "children are completed and accepted. Otherwise execute the task through your team workflow "
            "and complete it with the resulting output context and output abstract."
        )
        self._schedule_leader_turn(team_id=team_id, session_id=session_id, prompt=prompt)

    @staticmethod
    def _is_unassigned_open_task(task: Any) -> bool:
        """Return whether a queued claim wake still targets a claimable task."""
        if task is None:
            return False
        if task.status is not OrgTaskStatus.OPEN:
            return False
        if task.assignment.assignment_type != OrgAssignmentType.UNASSIGNED:
            return False
        return task.assignment.team_id is None

    def schedule_summary_execution(
        self,
        *,
        team_id: str,
        session_id: str,
        task_id: str,
        organization_id: str,
        execution_id: str,
        root_task_id: str,
    ) -> None:
        """Queue one final-aggregation turn and suppress duplicate event deliveries."""

        if self._summary_closeout_attempts.get((session_id, team_id, execution_id), 0) > 1:
            return
        summary_key = (session_id, team_id, task_id)
        if summary_key in self._scheduled_summary_executions:
            self._ensure_leader_turn_worker(team_id, session_id)
            return
        self._scheduled_summary_executions.add(summary_key)
        logger.info("Summary turn queued: task={} team={} execution={}", task_id, team_id, execution_id)

        prompt = (
            f"Summary Task {task_id} (execution_id={execution_id}, root_task_id={root_task_id}) in "
            f"organization {organization_id} is ready for final aggregation. "
            f"Call org_summary_get_inputs(summary_task_id='{task_id}') before doing any synthesis. "
            "Use only those bound, accepted source outputs. Do NOT create child tasks, delegate, "
            "claim, review, or modify any source task. Send the bound source facts to the two fixed "
            "Summary Team teammates through internal Team messages for source integration and drafting; "
            "use the execution_id in their messages and intermediate artifact names. "
            "Do not explore unrelated workspace directories. After both teammates report, verify their "
            "work against the bound sources and then call "
            "org_summary_complete in the same leader turn. Internal task completion, Team idle, or Team pause is "
            "not Summary Task completion: do not start another internal task cycle, wait, or poll instead. "
            "A Root Leader message may add delivery requirements, but it does not change this Team's two-tool "
            "protocol or authorize access to other organization tasks. "
            "Complete this Summary Task with org_summary_complete, placing the deliverable in "
            "output_context.description "
            "and a concise summary in output_abstract; completing it also completes the root task."
        )
        # MVP permits one active root task only. The execution id is carried in
        # the prompt so a future concurrent implementation must introduce a
        # separate harness session/workspace rather than reuse this context.
        self._schedule_leader_turn(
            team_id=team_id,
            session_id=session_id,
            prompt=prompt,
            summary_key=summary_key,
        )

    def _schedule_leader_message_turn(
        self,
        *,
        team_id: str,
        session_id: str,
        message_id: str,
        from_team_id: str,
        organization_id: str,
    ) -> None:
        message_key = (session_id, team_id, message_id)
        if message_key in self._scheduled_leader_messages:
            self._ensure_leader_turn_worker(team_id, session_id)
            return
        self._scheduled_leader_messages.add(message_key)
        prompt = (
            f"Leader message {message_id} arrived in organization {organization_id} "
            f"from team {from_team_id}. Read it with org_get_leader_message, perform any required "
            "cross-team coordination or task-pool updates, then call org_ack_leader_message only "
            "after the message has been handled."
        )
        self._schedule_leader_turn(
            team_id=team_id,
            session_id=session_id,
            prompt=prompt,
            message_key=message_key,
            relay_source="org_root_background",
        )

    def _schedule_summary_completion_delivery_turn(
        self,
        *,
        team_id: str,
        session_id: str,
        message_id: str,
        organization_id: str,
        metadata: dict[str, Any],
    ) -> None:
        """Schedule the Root Leader to verify and deliver a completed Summary Task."""
        message_key = (session_id, team_id, message_id)
        if message_key in self._scheduled_leader_messages:
            self._ensure_leader_turn_worker(team_id, session_id)
            return
        self._scheduled_leader_messages.add(message_key)
        root_task_id = str(metadata.get("root_task_id") or "")
        summary_task_id = str(metadata.get("summary_task_id") or "")
        prompt = (
            f"Summary Team completion notice {message_id} arrived in organization {organization_id}. "
            f"Read it with org_get_leader_message, then inspect completed root task {root_task_id} with "
            "org_view_tasks(action='get'). Verify that its output_context.description contains the final "
            f"report produced by Summary Task {summary_task_id}. Do not create, delegate, modify, review, "
            "or complete any task; do not call org_summary_complete and do not start another summary. "
            "After verification, call org_ack_leader_message, then directly deliver the verified final report "
            "to the user in this turn. Do not poll or say that you are waiting."
        )
        self._schedule_leader_turn(
            team_id=team_id,
            session_id=session_id,
            prompt=prompt,
            message_key=message_key,
            relay_source="org_root_delivery",
        )

    def schedule_summary_completion_delivery(
        self,
        *,
        team_id: str,
        session_id: str,
        message_id: str,
        organization_id: str,
        metadata: dict[str, Any],
    ) -> None:
        """Wake the Root Leader after its durable completion notice is saved."""
        self._schedule_summary_completion_delivery_turn(
            team_id=team_id,
            session_id=session_id,
            message_id=message_id,
            organization_id=organization_id,
            metadata=metadata,
        )

    def _schedule_claimed_task_execution_turn(
        self,
        *,
        team_id: str,
        session_id: str,
        task_id: str,
        organization_id: str,
    ) -> None:
        """Continue an automatic claim with a separate execution turn.

        A claim is persisted during a leader's tool call, but that LLM turn can
        legitimately finish immediately afterwards.  Queue a second turn so a
        successfully auto-claimed task never remains stranded in ``CLAIMED``.
        """

        prompt = (
            f"Your team claimed organization task {task_id} in {organization_id}. "
            "Inspect it with org_view_tasks(action='get'). If it is a root task whose mode has not yet been "
            "explicitly selected, choose its aggregation mode before decomposition; SUMMARY_TEAM is the "
            "default preference. Choose "
            "HIERARCHICAL only if your Team performs the substantial core of the root task, can independently "
            "make the final decision, and other Teams' child tasks provide only small, local supporting "
            "pieces. Choose SUMMARY_TEAM when multiple Teams own distinct parts or specialist domains "
            "whose results need a cross-domain final judgment, including parallel finance, legal, technical, "
            "and market due diligence, or when your Team can complete only one part. Coordination alone does "
            "not make your Team the final integrator. Call "
            "org_update_task(action='set_aggregation_mode') with that choice. "
            "Then call org_update_task(action='start') and execute the "
            "defined scope through your Team workflow. If an independent part requires another organization "
            "team's capabilities, keep this parent task assigned to your team and create a focused OPEN child "
            f"with org_create_task(parent_task_id='{task_id}'). Give each child a clear scope, acceptance "
            "criteria, and only the capabilities it needs; do not set delegated_to_team_id. Track children "
            "with org_view_child_tasks and wait until every direct child is completed and accepted. If the "
            "child is delegated to another Team and is DELEGATED, CLAIMED, or IN_PROGRESS, it is still being "
            "executed: do not re-delegate it or create a duplicate replacement; end this turn and wait for "
            "its completion event. "
            "If the root uses HIERARCHICAL, integrate those accepted outputs and complete the root yourself with "
            "org_update_task(action='complete'). If the root uses SUMMARY_TEAM, include every contribution "
            "(including work your own Team performs) as a direct child, then call "
            "org_create_summary_execution with all direct child ids after they are accepted. Do not directly "
            "complete a SUMMARY_TEAM root; its Summary Task completes it. If the task is already IN_PROGRESS "
            "or COMPLETED, do not duplicate work."
        )
        self._schedule_leader_turn(
            team_id=team_id,
            session_id=session_id,
            prompt=prompt,
            claimed_task_id=task_id,
            relay_source="org_root_background",
        )

    def _schedule_parent_review_turn(
        self,
        *,
        team_id: str,
        session_id: str,
        child_task_id: str,
        parent_task_id: str,
        organization_id: str,
    ) -> None:
        review_key = (session_id, team_id, child_task_id)
        if review_key in self._scheduled_parent_reviews:
            self._ensure_leader_turn_worker(team_id, session_id)
            return
        self._scheduled_parent_reviews.add(review_key)
        prompt = (
            f"Child organization task {child_task_id} completed in {organization_id}. "
            f"Inspect its result with org_review_task, then accept or reject it. "
            f"If accepted, use the child output to continue parent task {parent_task_id}. "
            "If rejected, create a repair with org_create_task "
            f"(set repairs_task_id={child_task_id} on the original sibling; never repair-of-repair; "
            "do not org_delegate_task the rejected child). "
            "When all direct children are accepted or superseded by an accepted repair, inspect the parent "
            "task's aggregation mode. Complete it only for HIERARCHICAL (or a non-root parent). For a "
            "SUMMARY_TEAM root, create its Summary Execution instead; do not call complete on that root. "
            "For a root completion, put the user-facing delivery in org_update_task output_context.description "
            "and provide output_abstract."
        )
        self._schedule_leader_turn(
            team_id=team_id,
            session_id=session_id,
            prompt=prompt,
            review_key=review_key,
            review_task_id=child_task_id,
            relay_source="org_root_background",
        )

    def _schedule_parent_repair_turn(
        self,
        *,
        team_id: str,
        session_id: str,
        child_task_id: str,
        parent_task_id: str,
        organization_id: str,
        review_status: str,
        repairs_task_id: str | None = None,
    ) -> None:
        review_key = (session_id, team_id, f"repair:{child_task_id}")
        if review_key in self._scheduled_parent_reviews:
            self._ensure_leader_turn_worker(team_id, session_id)
            return
        self._scheduled_parent_reviews.add(review_key)
        target_id = repairs_task_id or child_task_id
        prompt = (
            f"Child organization task {child_task_id} was reviewed as {review_status} "
            f"in {organization_id}. Parent task {parent_task_id} cannot advance on that child. "
            "Read the child result and review verdict/required_changes. "
            + self._repair_create_instructions(
                target_id=target_id,
                report_phrase="defect report",
                terminal_label="rejected/completed",
            )
        )
        self._schedule_leader_turn(
            team_id=team_id,
            session_id=session_id,
            prompt=prompt,
            review_key=review_key,
            relay_source="org_root_background",
        )

    def _schedule_parent_ready_turn(
        self,
        *,
        team_id: str,
        session_id: str,
        parent_task_id: str,
        organization_id: str,
    ) -> None:
        review_key = (session_id, team_id, f"complete:{parent_task_id}")
        if review_key in self._scheduled_parent_reviews:
            self._ensure_leader_turn_worker(team_id, session_id)
            return
        self._scheduled_parent_reviews.add(review_key)
        prompt = (
            f"All direct child tasks for parent organization task {parent_task_id} "
            f"in {organization_id} are accepted or superseded by an accepted repair. "
            "Inspect the parent's aggregation mode. For HIERARCHICAL (or a non-root parent), integrate the "
            "child outputs and call org_update_task(action='complete') on the parent with the final "
            "output_context and output_abstract. For a SUMMARY_TEAM root, call "
            "org_create_summary_execution with the accepted direct child ids instead; do not complete the "
            "root yourself. For a root completion, put the user-facing delivery in output_context.description."
        )
        self._schedule_leader_turn(
            team_id=team_id,
            session_id=session_id,
            prompt=prompt,
            review_key=review_key,
            ready_parent_task_id=parent_task_id,
            relay_source="org_root_background",
        )

    def _schedule_parent_child_failed_turn(
        self,
        *,
        team_id: str,
        session_id: str,
        child_task_id: str,
        parent_task_id: str,
        organization_id: str,
        failure_code: str,
        failure_reason: str,
        repairs_task_id: str | None = None,
    ) -> None:
        review_key = (session_id, team_id, f"failed:{child_task_id}")
        if review_key in self._scheduled_parent_reviews:
            self._ensure_leader_turn_worker(team_id, session_id)
            return
        self._scheduled_parent_reviews.add(review_key)
        target_id = repairs_task_id or child_task_id
        prompt = (
            f"Child organization task {child_task_id} failed in {organization_id} "
            f"(failure_code={failure_code}, failure_reason={failure_reason}). "
            f"Parent task {parent_task_id} cannot advance on that child. "
            "This is not a pending review — do not call org_review_task on the failed child. "
            + self._repair_create_instructions(
                target_id=target_id,
                report_phrase="the failure report",
                terminal_label="failed",
            )
        )
        self._schedule_leader_turn(
            team_id=team_id,
            session_id=session_id,
            prompt=prompt,
            review_key=review_key,
        )

    @staticmethod
    def _repair_create_instructions(
        *,
        target_id: str,
        report_phrase: str,
        terminal_label: str,
    ) -> str:
        """Shared wake guidance for creating a repair sibling of a terminal child."""
        return (
            "Create a focused repair task with org_create_task "
            f"(set repairs_task_id={target_id} pointing at the original sibling, never another "
            f"repair; include {report_phrase} and acceptance criteria; prefer capabilities that "
            "match the defect; if the original has retry_limit, do not exceed it). "
            "If org_create_task fails because retry_limit is reached, do not retry create in a "
            "loop: call org_update_task(action='failed') on the parent with failure_reason "
            "explaining that the repair budget is exhausted, so the owning/parent team can "
            "decide the next step or fail/terminate toward the root. Same team may "
            "execute the repair; switching teams is optional—only if switching teams, set "
            "delegated_to_team_id on that new repair (or org_delegate_task the new OPEN repair "
            "only). Do not call org_delegate_task on the "
            f"{terminal_label} child, which is terminal. "
            "Do not leave the parent waiting without creating that repair, and do not silently "
            f"reopen the {terminal_label} child task."
        )

    @staticmethod
    def _original_repairs_target(task: Any) -> str:
        """Return the original sibling id a new repair must target (never a repair-of-repair)."""
        meta = getattr(task, "metadata", None) or {}
        nested = meta.get(ORG_TASK_REPAIRS_TASK_ID_KEY) if isinstance(meta, dict) else None
        if isinstance(nested, str) and nested.strip():
            return nested.strip()
        return str(task.task_id)

    def _schedule_leader_turn(
        self,
        *,
        team_id: str,
        session_id: str,
        prompt: str,
        message_key: tuple[str, str, str] | None = None,
        review_key: tuple[str, str, str] | None = None,
        summary_key: tuple[str, str, str] | None = None,
        claimed_task_id: str | None = None,
        open_claim_task_id: str | None = None,
        review_task_id: str | None = None,
        ready_parent_task_id: str | None = None,
        relay_source: str | None = None,
        unclaimed_notification: tuple[tuple[str, str], dict[str, Any]] | None = None,
    ) -> None:
        key = (session_id, team_id)
        queue = self._leader_turn_queues.setdefault(key, deque())
        queue.append(
            {
                "query": prompt,
                "_org_message_key": message_key,
                "_org_review_key": review_key,
                "_org_summary_key": summary_key,
                "_org_claimed_task_id": claimed_task_id,
                "_org_open_claim_task_id": open_claim_task_id,
                "_org_review_task_id": review_task_id,
                "_org_ready_parent_task_id": ready_parent_task_id,
                "_org_queued_at": time.monotonic() if summary_key is not None else None,
                "_org_relay_source": relay_source,
                "_org_unclaimed_notification": unclaimed_notification,
            }
        )
        self._ensure_leader_turn_worker(team_id, session_id)

    def _ensure_leader_turn_worker(self, team_id: str, session_id: str) -> None:
        """Restart a retained organization turn when another event reaches this team."""
        key = (session_id, team_id)
        if not self._leader_turn_queues.get(key):
            return
        worker = self._leader_turn_workers.get(key)
        if worker is None or worker.done():
            worker = asyncio.create_task(self._drain_leader_turns(team_id, session_id))
            self._leader_turn_workers[key] = worker

    async def _drain_leader_turns(self, team_id: str, session_id: str) -> None:
        """Run one background leader turn at a time and retain events while busy.

        A ``PAUSED`` leader gets a dedicated organization turn. A ``RUNNING``
        leader that is already idle/settled (open stream, no in-flight round)
        receives the prompt via ``interact`` so the existing stream handles it
        — no finalize/re-activate reentrancy. Busy ``RUNNING`` leaders keep
        polling until they pause or settle.
        """

        key = (session_id, team_id)
        try:
            queue = self._leader_turn_queues.setdefault(key, deque())
            while queue:
                entry = await self._team_runtime_manager.pool.get(team_id)
                if entry is None or entry.current_session_id != session_id:
                    self._clear_leader_turn_queue(queue)
                    return
                if entry.state is RuntimeState.PAUSED:
                    pass
                elif entry.state is RuntimeState.RUNNING and await self._team_is_idle_settled_for_org_wake(entry):
                    pass
                else:
                    await asyncio.sleep(_LEADER_TURN_PAUSE_POLL_INTERVAL_SECONDS)
                    continue
                inputs = queue.popleft()
                original_inputs = dict(inputs) if isinstance(inputs, dict) else inputs
                message_key = None
                review_key = None
                summary_key = None
                claimed_task_id = None
                open_claim_task_id = None
                review_task_id = None
                ready_parent_task_id = None
                queued_at = None
                turn_failed = False
                summary_requeued = False
                if isinstance(inputs, dict):
                    message_key = inputs.pop("_org_message_key", None)
                    review_key = inputs.pop("_org_review_key", None)
                    summary_key = inputs.pop("_org_summary_key", None)
                    claimed_task_id = inputs.pop("_org_claimed_task_id", None)
                    open_claim_task_id = inputs.pop("_org_open_claim_task_id", None)
                    review_task_id = inputs.pop("_org_review_task_id", None)
                    ready_parent_task_id = inputs.pop("_org_ready_parent_task_id", None)
                    queued_at = inputs.pop("_org_queued_at", None)
                try:
                    task_manager = getattr(getattr(entry.agent, "team_backend", None), "org_task_manager", None)
                    if open_claim_task_id is not None and task_manager is not None:
                        open_task = await task_manager.get_task(open_claim_task_id)
                        if not self._is_unassigned_open_task(open_task):
                            continue
                    if summary_key is not None and task_manager is not None:
                        summary_task = await task_manager.get_task(summary_key[2])
                        execution = await task_manager.get_summary_execution(summary_task_id=summary_key[2])
                        summary_task_active = summary_task is not None and summary_task.status in {
                            OrgTaskStatus.DELEGATED,
                            OrgTaskStatus.IN_PROGRESS,
                        }
                        execution_running = (
                            execution is not None and execution.status == OrgSummaryExecutionStatus.RUNNING.value
                        )
                        if not summary_task_active or not execution_running:
                            continue
                        if summary_task.status is OrgTaskStatus.DELEGATED:
                            started = await task_manager.start_task(task_id=summary_task.task_id, team_id=team_id)
                            if not started.ok:
                                raise RuntimeError(started.reason or "summary task start failed")
                    if claimed_task_id is not None and task_manager is not None:
                        claimed_task = await task_manager.get_task(claimed_task_id)
                        if claimed_task is None or claimed_task.status in _PARENT_RESUME_TERMINAL_STATUSES:
                            continue
                        if self._summary_root_handed_off(claimed_task):
                            continue
                    if review_task_id is not None and task_manager is not None:
                        review = await task_manager.get_task_review(review_task_id)
                        if review is not None and review.review_status is not OrgTaskReviewStatus.PENDING:
                            continue
                    if ready_parent_task_id is not None and task_manager is not None:
                        parent = await task_manager.get_task(ready_parent_task_id)
                        if parent is not None and (
                            parent.status in _PARENT_RESUME_TERMINAL_STATUSES or self._summary_root_handed_off(parent)
                        ):
                            continue
                    notification = inputs.pop("_org_unclaimed_notification", None) if isinstance(inputs, dict) else None
                    if notification is not None:
                        service_key, message = notification
                        service = self._unclaimed_services.get(service_key)
                        if service is None:
                            continue
                        persisted = await service.manager.message_service.get_leader_message(
                            message_id=message["message_id"],
                            team_id=team_id,
                        )
                        if (
                            persisted is None
                            or persisted["handled_at"] is not None
                            or not await service.is_actionable(persisted)
                        ):
                            continue
                        from openjiuwen.agent_teams.prompts.loader import load_template

                        language = getattr(entry.agent.spec, "language", None) or "cn"
                        inputs["query"] = (
                            load_template(
                                f"org_unclaimed_{message['metadata']['unclaimed_kind']}",
                                language,
                            )
                            .format(
                                {
                                    **message["metadata"],
                                    "message_id": message["message_id"],
                                    "organization_id": service.manager.organization_id,
                                }
                            )
                            .content
                        )
                    started_at = time.monotonic()
                    if summary_key is not None:
                        logger.info(
                            "Summary turn starting: task={} team={} queue_wait_s={:.2f}",
                            summary_key[2],
                            team_id,
                            started_at - queued_at if queued_at is not None else 0.0,
                        )
                    if not await self._run_leader_turn(team_id, session_id, inputs):
                        turn_failed = True
                        queue.appendleft(original_inputs)
                        logger.warning(
                            "Organization leader turn was not run for team {} session {}",
                            team_id,
                            session_id,
                        )
                        return
                    if summary_key is not None:
                        logger.info(
                            "Summary turn returned: task={} team={} duration_s={:.2f}",
                            summary_key[2],
                            team_id,
                            time.monotonic() - started_at,
                        )
                        summary_requeued = await self._check_summary_closeout(
                            team_id, session_id, summary_key, queue, original_inputs
                        )
                except Exception:
                    turn_failed = True
                    queue.appendleft(original_inputs)
                    logger.warning(
                        "Organization leader turn failed for team {} session {}", team_id, session_id, exc_info=True
                    )
                    return
                finally:
                    if not turn_failed and message_key is not None:
                        self._scheduled_leader_messages.discard(message_key)
                    if not turn_failed and review_key is not None:
                        self._scheduled_parent_reviews.discard(review_key)
                    if not turn_failed and not summary_requeued and summary_key is not None:
                        self._scheduled_summary_executions.discard(summary_key)
        finally:
            self._leader_turn_workers.pop(key, None)
            if not self._leader_turn_queues.get(key):
                self._leader_turn_queues.pop(key, None)

    async def notify_summary_member_failure(
        self, *, team_id: str, session_id: str, member_name: str, reason: str, turn_id: str,
        summary_task_id: str | None = None,
    ) -> None:
        """Wake Summary's leader once on failure, without waiting for a settled task board."""
        entry = await self._team_runtime_manager.pool.get(team_id)
        if entry is None or entry.current_session_id != session_id or not self._is_summary_team(entry.agent):
            return
        if entry.state not in (RuntimeState.RUNNING, RuntimeState.PAUSED):
            return
        shutdown = getattr(entry.agent, "is_shutdown_requested", None)
        if callable(shutdown) and await shutdown():
            return
        backend = entry.agent.team_backend
        manager = getattr(backend, "org_task_manager", None)
        if manager is None:
            return
        from openjiuwen.agent_teams.prompts.loader import load_template

        active = []
        for execution in await manager.list_incomplete_summary_executions():
            if execution.summary_team_id != team_id:
                continue
            if execution.status != OrgSummaryExecutionStatus.RUNNING.value:
                continue
            active.append(execution)
        if summary_task_id is not None:
            active = [execution for execution in active if execution.summary_task_id == summary_task_id]
        elif len(active) != 1:
            # A shared Summary Team may serve several roots. Never guess which failed.
            return
        for execution in active:
            key = (session_id, team_id, execution.execution_id)
            failures = self._summary_member_failures.setdefault(key, set())
            if turn_id in failures or len(failures) >= 2:
                continue
            failures.add(turn_id)
            leader_id = self._leader_id(entry.agent, backend)
            blocked = len(failures) > 1 or member_name == leader_id
            if blocked:
                # Exhaustion must also suppress the later natural-pause recovery.
                self._summary_closeout_attempts[key] = 2
                find_rails = getattr(getattr(entry.agent, "harness", None), "find_rails_by_type", None)
                if callable(find_rails):
                    for rail in find_rails((_SummaryCloseoutRail,)):
                        rail.stop_drafting(execution.summary_task_id)
            language = getattr(entry.agent.spec, "language", None) or "cn"
            prompt = cast(str, load_template("org_summary_member_failure", language).format({
                "summary_task_id": execution.summary_task_id, "execution_id": execution.execution_id,
                "member_name": member_name, "reason": reason, "blocked": str(blocked),
            }).content)
            if member_name != leader_id:
                await backend.message_manager.send_message(content=prompt, to_member_name=leader_id)
            if blocked:
                task = await manager.get_task(execution.summary_task_id)
                if task is not None:
                    await self._notify_summary_blocker(backend, execution, task, prompt)

    async def _check_summary_closeout(
        self,
        team_id: str,
        session_id: str,
        summary_key: tuple[str, str, str],
        queue: deque[object],
        original_inputs: object,
    ) -> bool:
        """Give a naturally paused Summary Execution one bounded submission-only turn."""
        if not isinstance(original_inputs, dict):
            return False
        entry = await self._team_runtime_manager.pool.get(team_id)
        if entry is None or entry.current_session_id != session_id or entry.state is not RuntimeState.PAUSED:
            return False
        shutdown_requested = getattr(entry.agent, "is_shutdown_requested", None)
        if callable(shutdown_requested) and await shutdown_requested():
            return False
        backend = entry.agent.team_backend
        task_manager = getattr(backend, "org_task_manager", None)
        if task_manager is None:
            return False
        execution = await task_manager.get_summary_execution(summary_task_id=summary_key[2])
        if execution is None or execution.status != OrgSummaryExecutionStatus.RUNNING.value:
            return False
        task = await task_manager.get_task(summary_key[2])
        if task is None or task.status is not OrgTaskStatus.IN_PROGRESS:
            return False
        attempt_key = (session_id, team_id, execution.execution_id)
        attempts = self._summary_closeout_attempts.get(attempt_key, 0)
        if attempts == 0:
            self._summary_closeout_attempts[attempt_key] = 1
            closeout_inputs = dict(original_inputs)
            closeout_inputs["_org_summary_closeout"] = True
            from openjiuwen.agent_teams.prompts.loader import load_template

            language = getattr(getattr(entry.agent, "spec", None), "language", None) or "cn"
            workspace = getattr(getattr(entry.agent, "harness", None), "workspace", None)
            workspace_path = getattr(workspace, "root_path", None) or "(unavailable)"
            closeout_inputs["query"] = (
                load_template("org_summary_closeout", language)
                .format({
                    "summary_task_id": summary_key[2],
                    "execution_id": execution.execution_id,
                    "workspace_path": str(workspace_path),
                })
                .content
            )
            closeout_inputs["_org_queued_at"] = time.monotonic()
            queue.appendleft(closeout_inputs)
            logger.warning(
                "Summary closeout recovery queued: task={} execution={}", task.task_id, execution.execution_id
            )
            return True
        if attempts > 1:
            return False
        self._summary_closeout_attempts[attempt_key] = 2
        reason = f"Summary Task {task.task_id} remains unsubmitted after its single closeout recovery turn."
        logger.error("{} execution={}", reason, execution.execution_id)
        await self._notify_summary_blocker(backend, execution, task, reason)
        return False

    async def _notify_summary_blocker(self, backend: Any, execution: Any, task: Any, reason: str) -> None:
        root = await backend.org_task_manager.get_task(execution.root_task_id)
        messages = getattr(backend, "org_message_service", None)
        if root is None or messages is None or root.assignment is None:
            return
        try:
            # The message service resolves the registered Leader of the assigned Team.
            # The creator is not necessarily the Team that claimed this root.
            notice = await messages.send_leader_message(
                from_team_id="__organization__",
                from_leader_id="__organization__",
                to_team_id=root.assignment.team_id,
                content=reason + " Report the blocker to the user; do not automatically restart the Summary Team.",
                metadata={
                    "kind": "summary_submission_blocked",
                    "task_id": task.task_id,
                    "execution_id": execution.execution_id,
                },
            )
        except Exception:
            logger.exception("Summary closeout notice failed: task={}", task.task_id)
            return
        if not notice.ok:
            logger.warning("Summary closeout notice delivery failed: task={}", task.task_id)

    @staticmethod
    def _summary_root_handed_off(task: Any) -> bool:
        """Return whether a root already has a Summary Task owning its final step."""
        if getattr(task, "parent_task_id", None):
            return False
        aggregation = getattr(task, "aggregation", None)
        if aggregation is None or aggregation.mode != OrgTaskAggregationMode.SUMMARY_TEAM:
            return False
        return bool(aggregation.summary_task_id)

    def _clear_leader_turn_queue(self, queue: deque[object]) -> None:
        for inputs in queue:
            if isinstance(inputs, dict):
                message_key = inputs.get("_org_message_key")
                if message_key is not None:
                    self._scheduled_leader_messages.discard(message_key)
                review_key = inputs.get("_org_review_key")
                if review_key is not None:
                    self._scheduled_parent_reviews.discard(review_key)
                summary_key = inputs.get("_org_summary_key")
                if summary_key is not None:
                    self._scheduled_summary_executions.discard(summary_key)
        queue.clear()

    @staticmethod
    async def _team_is_idle_settled_for_org_wake(entry: Any) -> bool:
        """Whether a RUNNING team can take an org wake on its open stream.

        Mirrors ``team.idle``: no in-flight DeepAgent round, every member
        quiescent, and the local task board settled. Missing probes mean
        "not settled" so drains keep waiting for ``PAUSED`` (safe default).
        """
        agent = getattr(entry, "agent", None)
        if agent is None:
            return False
        has_in_flight = getattr(agent, "has_in_flight_round", None)
        if callable(has_in_flight) and has_in_flight():
            return False
        state = getattr(agent, "_state", None)
        registry = getattr(state, "member_registry", None) if state is not None else None
        if registry is None or not registry.is_idle():
            return False
        board_probe = getattr(agent, "is_task_board_settled", None)
        if not callable(board_probe):
            return False
        try:
            return bool(await board_probe())
        except Exception:
            return False

    async def _deliver_org_turn_to_running_leader(
        self,
        team_id: str,
        session_id: str,
        inputs: object,
    ) -> bool:
        """Hand an org prompt to a RUNNING idle leader via the interact path."""
        query = inputs.get("query") if isinstance(inputs, dict) else None
        if not str(query or "").strip():
            return False
        result = await self._team_runtime_manager.interact(
            str(query),
            team_name=team_id,
            session_id=session_id,
        )
        if not result:
            team_logger.warning(
                "Organization interact wake failed for team {} session {}: {}",
                team_id,
                session_id,
                getattr(result, "reason", None),
            )
            return False
        return True

    async def _run_leader_turn(self, team_id: str, session_id: str, inputs: object) -> bool:
        closeout = isinstance(inputs, dict) and inputs.get("_org_summary_closeout") is True
        with _summary_closeout_scope(team_id if closeout else None):
            return await self._run_scoped_leader_turn(team_id, session_id, inputs)

    async def _run_scoped_leader_turn(self, team_id: str, session_id: str, inputs: object) -> bool:
        entry = await self._team_runtime_manager.pool.get(team_id)
        if entry is None or entry.current_session_id != session_id:
            return False
        # An interact wake runs in an existing task context, so it cannot inherit
        # the submission-only policy. Keep recovery queued until a paused turn.
        if isinstance(inputs, dict) and inputs.get("_org_summary_closeout") and entry.state is not RuntimeState.PAUSED:
            return False
        if entry.state is RuntimeState.PAUSED:
            if self._is_summary_team(entry.agent) and self._summary_turn_runner is not None:
                return await self._summary_turn_runner(team_id, session_id, inputs)
            if self._leader_turn_runner is not None:
                return await self._leader_turn_runner(team_id, session_id, inputs)
            return await self._team_runtime_manager.run_organization_turn(
                team_name=team_id,
                session_id=session_id,
                inputs=inputs,
            )
        if entry.state is RuntimeState.RUNNING and await self._team_is_idle_settled_for_org_wake(entry):
            # Open-stream delivery: never start a second organization turn.
            return await self._deliver_org_turn_to_running_leader(team_id, session_id, inputs)
        return False

    async def _resolve_leader(self, team_id: str, session_id: str) -> tuple["TeamAgent", TeamBackend]:
        entry = await self._team_runtime_manager.pool.get(team_id)
        if entry is None or entry.current_session_id != session_id:
            raise ValueError(f"team is not active in session: {team_id}")
        backend = entry.agent.team_backend
        if backend is None or not getattr(backend, "is_leader", False):
            raise ValueError(f"active team has no leader backend: {team_id}")
        return entry.agent, backend

    @staticmethod
    def _leader_id(agent: "TeamAgent", backend: TeamBackend) -> str:
        return backend.leader_member_name or agent.member_name or backend.member_name

    @staticmethod
    def _capabilities(agent: "TeamAgent") -> list[str]:
        metadata = getattr(agent.spec, "metadata", None) or {}
        capabilities = metadata.get("capabilities", [])
        return [str(capability) for capability in capabilities] if isinstance(capabilities, list) else []


__all__ = ["OrganizationRuntimeManager"]
