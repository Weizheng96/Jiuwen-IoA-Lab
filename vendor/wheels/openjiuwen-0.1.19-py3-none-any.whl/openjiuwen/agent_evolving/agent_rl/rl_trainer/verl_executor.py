# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.

"""
VerlTrainingExecutor
--------------------

Extends verl's RayPPOTrainer to provide the full PPO/GRPO training step
pipeline including:

- baseline computation (REMAX)
- reward computation
- old log prob / reference log prob / value computation
- advantage estimation
- actor / critic updates
- metrics logging and checkpointing

The ``train_step`` delegates to the shared ``run_ppo_step`` pipeline.

Class hierarchy::

    RayPPOTrainer              (verl)
      └─ BaseVerlTrainingExecutor   (abstract – shared training logic)
           ├─ OfflineVerlTrainingExecutor  (async_rollout_manager lifecycle)
           └─ OnlineVerlTrainingExecutor   (checkpoint_manager lifecycle)

``VerlTrainingExecutor`` is a backward-compatible alias for
``OfflineVerlTrainingExecutor``.
"""

import importlib
import inspect
from abc import abstractmethod
from copy import deepcopy

import torch
from omegaconf import OmegaConf
from tensordict import TensorDict
from verl import DataProto
from verl.protocol import pad_dataproto_to_divisor, unpad_dataproto
from verl.trainer.ppo.core_algos import agg_loss
from verl.trainer.ppo.metric_utils import compute_data_metrics, compute_throughout_metrics
from verl.trainer.ppo.ray_trainer import (
    AdvantageEstimator,
    RayPPOTrainer,
    apply_kl_penalty,
    compute_advantage,
    compute_response_mask,
)
from verl.utils.metric import reduce_metrics
try:
    from verl.utils.py_functional import rename_dict
except ImportError:
    def rename_dict(data: dict, prefix: str) -> dict:
        return {f"{prefix}{key}": value for key, value in data.items()}
from verl.utils.tracking import Tracking

from openjiuwen.core.common.exception.codes import StatusCode
from openjiuwen.core.common.exception.errors import build_error
from openjiuwen.core.common.logging import logger
from openjiuwen.agent_evolving.agent_rl.rl_trainer.ppo_step import run_ppo_step
from openjiuwen.agent_evolving.agent_rl.offline.store.metrics_tracker import TrainingDiagnostics


class BaseVerlTrainingExecutor(RayPPOTrainer):
    """Base class for verl-based training executors.

    Provides all shared PPO/GRPO training sub-steps.  Subclasses must
    implement ``sleep_rollout`` and ``wake_up_rollout`` to manage the
    rollout lifecycle according to their deployment mode (offline vs online).
    """

    def __init__(
        self,
        config,
        tokenizer,
        processor,
        role_worker_mapping,
        resource_pool_manager,
        ray_worker_group_cls,
        reward_fn,
        val_reward_fn,
        train_dataset,
        val_dataset,
        collate_fn,
        train_sampler,
    ):
        parent_params = inspect.signature(super().__init__).parameters
        init_kwargs = dict(
            config=config,
            tokenizer=tokenizer,
            processor=processor,
            role_worker_mapping=role_worker_mapping,
            resource_pool_manager=resource_pool_manager,
            ray_worker_group_cls=ray_worker_group_cls,
            train_dataset=train_dataset,
            val_dataset=val_dataset,
            collate_fn=collate_fn,
            train_sampler=train_sampler,
        )
        if "reward_fn" in parent_params:
            init_kwargs["reward_fn"] = reward_fn
            init_kwargs["val_reward_fn"] = val_reward_fn
        super().__init__(**init_kwargs)
        if not hasattr(self, "reward_fn"):
            self.reward_fn = reward_fn
        if not hasattr(self, "val_reward_fn"):
            self.val_reward_fn = val_reward_fn

        self.mini_batch_size = config.actor_rollout_ref.actor.ppo_mini_batch_size
        self.global_steps = 0
        if self.use_reference_policy:
            logger.info("Reference policy ENABLED for KL computation")
        else:
            logger.warning(
                "Reference policy NOT available. KL penalty will be ineffective. "
                "Model may drift far from initial policy during training."
            )
        self.pad_size = None
        self.preserve_provided_old_log_probs = False
        self._diagnostics = TrainingDiagnostics(tokenizer) if config.trainer.get("develop_mode", False) else None
        self._tensordict_worker_api = self._detect_tensordict_worker_api()

    @staticmethod
    def _detect_tensordict_worker_api() -> bool:
        try:
            padding = importlib.import_module("verl.workers.utils.padding")
            return (
                hasattr(DataProto, "to_tensordict")
                and hasattr(DataProto, "from_tensordict")
                and hasattr(padding, "left_right_2_no_padding")
                and hasattr(padding, "no_padding_2_padding")
            )
        except Exception:
            return False

    @staticmethod
    def _padding_helpers():
        from verl.utils import tensordict_utils as tu
        from verl.workers.utils.padding import left_right_2_no_padding, no_padding_2_padding

        return tu, left_right_2_no_padding, no_padding_2_padding

    # -- rollout lifecycle (abstract) ----------------------------------------

    @abstractmethod
    def sleep_rollout(self):
        """Release rollout GPU resources so training can use them."""

    @abstractmethod
    def wake_up_rollout(self) -> list:
        """Re-acquire rollout resources and return vLLM server addresses."""

    # -- logging / checkpointing --------------------------------------------

    def setup_logger(self):
        """Initializes the experiment logger."""
        self.logger = Tracking(
            project_name=self.config.trainer.project_name,
            experiment_name=self.config.trainer.experiment_name,
            default_backend=self.config.trainer.logger,
            config=OmegaConf.to_container(self.config, resolve=True),
        )
        return self.logger

    def log_metrics(self, metrics, step):
        """Logs the given metrics at the specified global step."""
        if self.logger:
            self.logger.log(data=metrics, step=step)

    def save_checkpoint(self):
        """Saves the current training state."""
        super()._save_checkpoint()

    def load_checkpoint(self):
        """Restores training state from latest checkpoint."""
        super()._load_checkpoint()

    # -- training sub-steps -------------------------------------------------

    def compute_baseline(self, origin_batch, batch):
        """Optionally computes a REMAX-style baseline."""
        if self.config.algorithm.adv_estimator == AdvantageEstimator.REMAX:
            remax_input = deepcopy(origin_batch)
            remax_input.meta_info["do_sample"] = False
            remax_output = self.actor_rollout_wg.generate_sequences(remax_input)
            batch = batch.union(remax_output)
            r_baseline = self.reward_fn(batch)
            r_baseline = r_baseline.sum(dim=-1)
            batch.pop(batch_keys=list(remax_output.batch.keys()))
            batch.batch["reward_baselines"] = r_baseline
            del remax_input, remax_output
        return batch

    def compute_reward(self, batch, metrics):
        """Prepares response masks and optionally computes RM scores."""
        batch.non_tensor_batch["uid"] = batch.non_tensor_batch["data_id_list"]
        resp_mask = compute_response_mask(batch)

        if "actor_loss_mask" in batch.batch:
            resp_mask = resp_mask * batch.batch["actor_loss_mask"]
            logger.debug(
                "actor_loss_mask applied: %d -> %d active tokens",
                int(compute_response_mask(batch).sum()),
                int(resp_mask.sum()),
            )

        batch.batch["response_mask"] = resp_mask
        batch.meta_info["global_token_num"] = torch.sum(
            batch.batch["attention_mask"], dim=-1
        ).tolist()
        if self.use_rm:
            rm_scores = self.rm_wg.compute_rm_score(batch)
            batch = batch.union(rm_scores)
        if self._diagnostics:
            self._diagnostics.diagnose_batch(batch, self.global_steps)
            self._diagnostics.diag_after_reward(batch)
        return batch

    def compute_old_log_prob(self, batch, metrics):
        """Computes the actor's log probabilities and entropy."""
        batch, unpad_at = pad_dataproto_to_divisor(
            batch, self.actor_rollout_wg.world_size
        )
        self.pad_size = unpad_at

        if getattr(self, "preserve_provided_old_log_probs", False) and "old_log_probs" in batch.batch:
            metrics["actor/using_captured_old_log_probs"] = 1
            return batch

        if self._tensordict_worker_api:
            tu, left_right_2_no_padding, no_padding_2_padding = self._padding_helpers()
            batch_td = left_right_2_no_padding(batch.to_tensordict())
            calculate_sum_pi_squared = self.config.actor_rollout_ref.actor.get(
                "calculate_sum_pi_squared", False
            )
            tu.assign_non_tensor(
                batch_td,
                calculate_entropy=True,
                calculate_sum_pi_squared=calculate_sum_pi_squared,
                compute_loss=False,
                temperature=self.config.actor_rollout_ref.rollout.temperature,
            )
            output = self.actor_rollout_wg.compute_log_prob(batch_td)
            entropy = no_padding_2_padding(tu.get(output, "entropy"), batch_td)
            log_probs = no_padding_2_padding(tu.get(output, "log_probs"), batch_td)

            result = {
                "old_log_probs": log_probs.float(),
                "entropys": entropy.float(),
            }
            routed_experts = tu.get(output, "routed_experts")
            if routed_experts is not None:
                result["routed_experts"] = routed_experts
            if calculate_sum_pi_squared:
                sum_pi_squared = tu.get(output, "sum_pi_squared")
                if sum_pi_squared is not None:
                    result["sum_pi_squared"] = no_padding_2_padding(
                        sum_pi_squared, batch_td
                    ).float()
            worker_metrics = tu.get(output, "metrics", default={}) or {}
            if "mfu" in worker_metrics:
                metrics["perf/mfu/actor_log_prob"] = worker_metrics["mfu"]
            prior_log_prob = DataProto.from_tensordict(tu.get_tensordict(result))
        else:
            prior_log_prob = self.actor_rollout_wg.compute_log_prob(batch)
        entropy_mat = prior_log_prob.batch["entropys"]
        resp_mask = batch.batch["response_mask"]

        if "actor_loss_mask" in batch.batch:
            inv_mask = (resp_mask == 0).float()
            prior_log_prob.batch["old_log_probs"] = torch.where(
                inv_mask.bool(),
                torch.zeros_like(prior_log_prob.batch["old_log_probs"]),
                prior_log_prob.batch["old_log_probs"],
            )
            entropy_mat = torch.where(
                inv_mask.bool(),
                torch.zeros_like(entropy_mat),
                entropy_mat,
            )

        agg_mode = self.config.actor_rollout_ref.actor.loss_agg_mode
        ent_loss = agg_loss(
            loss_mat=entropy_mat,
            loss_mask=resp_mask,
            loss_agg_mode=agg_mode,
        )
        prior_metrics = {"actor/entropy_loss": ent_loss.detach().item()}
        metrics.update(prior_metrics)

        prior_log_prob.batch.pop("entropys")
        batch = batch.union(prior_log_prob)
        if self._diagnostics:
            self._diagnostics.diag_after_old_log_prob(batch)
        return batch

    def compute_reference_log_prob(self, batch):
        """Computes reference policy log probabilities."""
        if self.use_reference_policy:
            if self._tensordict_worker_api:
                tu, left_right_2_no_padding, no_padding_2_padding = self._padding_helpers()
                batch_td = left_right_2_no_padding(batch.to_tensordict())
                metadata = {"calculate_entropy": False, "compute_loss": False}
                if getattr(self, "ref_in_actor", False):
                    metadata["no_lora_adapter"] = True
                metadata["temperature"] = self.config.actor_rollout_ref.rollout.temperature
                tu.assign_non_tensor(batch_td, **metadata)
                if getattr(self, "ref_in_actor", False):
                    output = self.actor_rollout_wg.compute_log_prob(batch_td)
                else:
                    output = self.ref_policy_wg.compute_ref_log_prob(batch_td)
                log_probs = no_padding_2_padding(tu.get(output, "log_probs"), batch_td)
                ref_probs = DataProto.from_tensordict(
                    tu.get_tensordict({"ref_log_prob": log_probs.float()})
                )
            else:
                if getattr(self, "ref_in_actor", False):
                    ref_probs = self.actor_rollout_wg.compute_ref_log_prob(batch)
                else:
                    ref_probs = self.ref_policy_wg.compute_ref_log_prob(batch)
            batch = batch.union(ref_probs)
        return batch

    def compute_values(self, batch):
        """Computes critic value estimates."""
        if self.use_critic:
            v_estimates = self.critic_wg.compute_values(batch)
            batch = batch.union(v_estimates)
        return batch

    def compute_advantages(self, batch, metrics):
        """Unpads batch, optionally applies KL penalty, computes advantages."""
        batch = unpad_dataproto(batch, pad_size=self.pad_size)
        use_kl = (
            hasattr(self.config.algorithm, "use_kl_in_reward")
            and self.config.algorithm.use_kl_in_reward
        )
        if use_kl and "ref_log_prob" not in batch.batch:
            logger.warning(
                "use_kl_in_reward is True but 'ref_log_prob' is missing from batch "
                "(reference policy may not be configured). Falling back to no KL penalty."
            )
            use_kl = False

        if use_kl:
            batch, kl_metrics = apply_kl_penalty(
                batch,
                kl_ctrl=getattr(self, "kl_ctrl_in_reward", None),
                kl_penalty=self.config.algorithm.kl_penalty,
            )
            metrics.update(kl_metrics)
        else:
            batch.batch["token_level_rewards"] = batch.batch["token_level_scores"]

        response_mask = batch.batch["response_mask"]
        active_response_tokens = int(response_mask.sum().item())
        if (
            str(self.config.algorithm.adv_estimator) == "reinforce_plus_plus"
            and active_response_tokens <= 1
        ):
            token_level_rewards = batch.batch["token_level_rewards"]
            gamma = self.config.algorithm.gamma
            with torch.no_grad():
                returns = torch.zeros_like(token_level_rewards)
                running_return = 0
                for t in reversed(range(token_level_rewards.shape[1])):
                    running_return = token_level_rewards[:, t] + gamma * running_return
                    returns[:, t] = running_return
                    running_return = running_return * response_mask[:, t]
                returns = returns * response_mask
                batch.batch["advantages"] = returns
                batch.batch["returns"] = returns
            metrics["training/advantage_single_token_fallback"] = 1
            logger.info(
                "Using unwhitened REINFORCE++ advantage because active response tokens=%d",
                active_response_tokens,
            )
            return batch

        batch = compute_advantage(
            batch,
            adv_estimator=self.config.algorithm.adv_estimator,
            gamma=self.config.algorithm.gamma,
            lam=self.config.algorithm.lam,
            num_repeat=self.config.actor_rollout_ref.rollout.n,
            norm_adv_by_std_in_grpo=self.config.algorithm.get(
                "norm_adv_by_std_in_grpo", True
            ),
            config=self.config.algorithm,
        )

        if "advantages" in batch.batch:
            adv_tensor = batch.batch["advantages"]
            nan_count = torch.isnan(adv_tensor).sum().item()
            inf_count = torch.isinf(adv_tensor).sum().item()
            if nan_count > 0 or inf_count > 0:
                logger.warning(
                    "Advantages contain %d NaN and %d Inf values, clamping to 0",
                    nan_count, inf_count,
                )
                batch.batch["advantages"] = torch.where(
                    torch.isfinite(adv_tensor), adv_tensor, torch.zeros_like(adv_tensor)
                )
                metrics["training/advantage_nan_count"] = nan_count
                metrics["training/advantage_inf_count"] = inf_count

        if self._diagnostics:
            self._diagnostics.diag_after_advantages(batch)
        return batch

    def filter_effective_groups(self, batch, metrics):
        """Filter GRPO groups: keep only groups that have reward variance AND
        contain at least one positive sample that used tool calling (n_turns >= 2).

        Groups are identified by ``uid`` (non_tensor_batch) so that incomplete
        rollout sets (fewer than rollout_n samples for a prompt) are handled
        correctly.
        """
        if not self.config.algorithm.get("filter_groups", False):
            return batch

        data_ids = batch.non_tensor_batch.get("uid")
        if data_ids is None:
            logger.warning("filter_effective_groups: 'uid' not found, skipping filter")
            return batch

        turn_counts = batch.non_tensor_batch.get("n_turns_list")

        score_mat = batch.batch["token_level_scores"]
        resp_mask = batch.batch["response_mask"]
        per_sample_reward = (score_mat * resp_mask).sum(dim=-1)

        id_to_idx: dict = {}
        for idx, did in enumerate(data_ids):
            id_to_idx.setdefault(did, []).append(idx)

        kept_idx = []
        n_groups = len(id_to_idx)
        n_no_variance = 0
        n_singleton = 0
        n_no_positive_with_tool = 0

        for did, idx_list in id_to_idx.items():
            group_rewards = per_sample_reward[idx_list]
            if len(idx_list) < 2:
                n_singleton += 1
                continue
            if group_rewards.std().item() < 1e-6:
                n_no_variance += 1
                continue
            has_positive_with_tool = False
            if turn_counts is not None:
                for i in idx_list:
                    if per_sample_reward[i].item() >= 1.0 - 1e-6 and int(turn_counts[i]) >= 2:
                        has_positive_with_tool = True
                        break
            if not has_positive_with_tool:
                n_no_positive_with_tool += 1
                continue
            kept_idx.extend(idx_list)

        n_kept = n_groups - n_no_variance - n_singleton - n_no_positive_with_tool
        metrics["training/filter_groups_total"] = n_groups
        metrics["training/filter_groups_kept"] = n_kept
        metrics["training/filter_groups_no_variance"] = n_no_variance
        metrics["training/filter_groups_singleton"] = n_singleton
        metrics["training/filter_groups_no_positive_with_tool"] = n_no_positive_with_tool

        if len(kept_idx) < len(batch):
            kept_idx.sort()
            batch = batch[kept_idx]
            logger.info(
                "Group filter: kept %d/%d groups, %d samples "
                "(dropped %d no-variance, %d no-positive-with-tool, %d singleton)",
                n_kept, n_groups, len(kept_idx),
                n_no_variance, n_no_positive_with_tool, n_singleton,
            )
        else:
            logger.info("Group filter: all %d groups effective, none dropped", n_groups)

        return batch

    def update_critic(self, batch, metrics):
        """Updates the critic network."""
        if self.use_critic:
            critic_result = self.critic_wg.update_critic(batch)
            critic_metrics = reduce_metrics(critic_result.meta_info["metrics"])
            metrics.update(critic_metrics)
        return metrics

    def update_actor(self, batch, metrics):
        """Updates the actor policy after critic warmup."""
        if self.config.trainer.critic_warmup <= self.global_steps:
            if self._tensordict_worker_api:
                tu, left_right_2_no_padding, _ = self._padding_helpers()
                batch_td = left_right_2_no_padding(batch.to_tensordict())
                actor_cfg = self.config.actor_rollout_ref.actor
                ppo_mini_batch_size = (
                    actor_cfg.ppo_mini_batch_size
                    * self.config.actor_rollout_ref.rollout.n
                )
                calculate_entropy = actor_cfg.calculate_entropy or (
                    actor_cfg.entropy_coeff != 0.0
                )
                tu.assign_non_tensor(
                    batch_td,
                    calculate_entropy=calculate_entropy,
                    distillation_use_topk=False,
                    global_batch_size=ppo_mini_batch_size,
                    mini_batch_size=ppo_mini_batch_size,
                    epochs=actor_cfg.ppo_epochs,
                    seed=actor_cfg.data_loader_seed,
                    dataloader_kwargs={"shuffle": actor_cfg.shuffle},
                    compute_loss=True,
                    temperature=self.config.actor_rollout_ref.rollout.temperature,
                )
                actor_output = self.actor_rollout_wg.update_actor(batch_td)
                actor_metrics = rename_dict(tu.get(actor_output, "metrics"), "actor/")
                if "actor/mfu" in actor_metrics:
                    actor_metrics["perf/mfu/actor"] = actor_metrics.pop("actor/mfu")
            else:
                actor_result = self.actor_rollout_wg.update_actor(batch)
                actor_metrics = reduce_metrics(actor_result.meta_info["metrics"])
            metrics.update(actor_metrics)
            if self._diagnostics:
                self._diagnostics.diag_after_actor_update(metrics)
        return metrics

    def process_metrics(self, batch, metrics, timing_raw):
        """Augments metrics with data statistics and throughput."""
        metrics.update(
            compute_data_metrics(batch=batch, use_critic=self.use_critic)
        )
        gpu_count = self.resource_pool_manager.get_n_gpus()
        metrics.update(
            compute_throughout_metrics(
                batch=batch, timing_raw=timing_raw, n_gpus=gpu_count
            )
        )
        return metrics

    def balance_batch(self, batch, metrics):
        """Optionally rebalances the batch."""
        if (
            hasattr(self.config.trainer, "balance_batch")
            and self.config.trainer.balance_batch
        ):
            super()._balance_batch(batch, metrics=metrics)

    # -- data format conversion ---------------------------------------------

    def get_rl_format_data(self, batch_dict):
        """Convert batch data to DataProto format for verl training."""
        if isinstance(batch_dict, TensorDict):
            return DataProto(batch=batch_dict)
        elif isinstance(batch_dict, dict):
            return DataProto.from_single_dict(batch_dict)
        else:
            raise build_error(
                StatusCode.AGENT_RL_BATCH_DATA_TYPE_INVALID,
                data_type=str(type(batch_dict)),
            )

    # -- main training step -------------------------------------------------

    def train_step(self, origin_batch, batch):
        """Main training step delegated to shared PPO pipeline."""
        return run_ppo_step(self, origin_batch, batch)


class OfflineVerlTrainingExecutor(BaseVerlTrainingExecutor):
    """Offline training executor using async_rollout_manager for rollout lifecycle.

    In offline mode, the rollout manager handles vLLM inference server
    sleep/wake cycles to enable GPU memory sharing between training and
    inference on the same devices.
    """

    def sleep_rollout(self):
        """Puts the async rollout manager into a sleep state to free GPU memory."""
        if self.async_rollout_manager is not None:
            self.async_rollout_manager.sleep()

    def wake_up_rollout(self) -> list:
        """Wakes up the rollout manager and returns vLLM server addresses."""
        if self.async_rollout_manager is not None:
            self.async_rollout_manager.wake_up()
            return self.async_rollout_manager.server_addresses
        return []


class OnlineVerlTrainingExecutor(BaseVerlTrainingExecutor):
    """Online training executor using checkpoint_manager for rollout lifecycle.

    In online mode, the checkpoint_manager handles weight synchronisation
    and replica sleep/wake cycles.  The async_rollout_manager provides
    the server addresses for the active vLLM backends.
    """

    def sleep_rollout(self):
        """Puts rollout replicas to sleep via checkpoint_manager to free GPU memory."""
        if hasattr(self, "checkpoint_manager") and self.checkpoint_manager is not None:
            self.checkpoint_manager.sleep_replicas()

    def wake_up_rollout(self) -> list:
        """Syncs latest weights and returns vLLM server addresses."""
        if hasattr(self, "checkpoint_manager") and self.checkpoint_manager is not None:
            self.checkpoint_manager.update_weights(self.global_steps)
        if self.async_rollout_manager is not None:
            return self.async_rollout_manager.server_addresses
        return []


VerlTrainingExecutor = OfflineVerlTrainingExecutor
