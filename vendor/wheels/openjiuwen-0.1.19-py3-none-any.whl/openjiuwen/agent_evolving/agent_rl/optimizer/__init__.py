# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.

"""
High-level user-facing optimizer entrypoints.
"""
